<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Role;
use App\Models\Permission;
use App\Models\Admin;
use App\Models\Company;
use App\Models\Setting;
use App\Models\Unit;
use App\Models\Warehouse;
use App\Models\Account;
use App\Models\ExpenseCategory;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // ── Roles ──────────────────────────────
        $superAdmin = Role::create(['name' => 'Super Admin', 'description' => 'Full system access', 'is_system' => true]);
        $manager    = Role::create(['name' => 'Manager', 'description' => 'Manager access', 'is_system' => false]);
        $staff      = Role::create(['name' => 'Staff', 'description' => 'Basic staff access', 'is_system' => false]);

        // ── Permissions ────────────────────────
        $modules = [
            'dashboard'  => ['view'],
            'admins'     => ['view', 'create', 'edit', 'delete'],
            'roles'      => ['view', 'create', 'edit', 'delete'],
            'company'    => ['view', 'edit'],
            'customers'  => ['view', 'create', 'edit', 'delete'],
            'contacts'   => ['view', 'create', 'edit', 'delete'],
            'leads'      => ['view', 'create', 'edit', 'delete'],
            'followups'  => ['view', 'create', 'edit', 'delete'],
            'products'   => ['view', 'create', 'edit', 'delete'],
            'categories' => ['view', 'create', 'edit', 'delete'],
            'brands'     => ['view', 'create', 'edit', 'delete'],
            'units'      => ['view', 'create', 'edit', 'delete'],
            'warehouses' => ['view', 'create', 'edit', 'delete'],
            'stock'      => ['view', 'adjust'],
            'quotations' => ['view', 'create', 'edit', 'delete'],
            'invoices'   => ['view', 'create', 'edit', 'delete'],
            'payments'   => ['view', 'create', 'edit', 'delete'],
            'vendors'    => ['view', 'create', 'edit', 'delete'],
            'purchase_orders' => ['view', 'create', 'edit', 'delete'],
            'purchase_bills'  => ['view', 'create', 'edit', 'delete'],
            'expenses'        => ['view', 'create', 'edit', 'delete'],
            'accounts'        => ['view', 'create', 'edit', 'delete'],
            'journal'         => ['view', 'create', 'edit', 'delete'],
            'projects'        => ['view', 'create', 'edit', 'delete'],
            'tasks'           => ['view', 'create', 'edit', 'delete'],
            'employees'       => ['view', 'create', 'edit', 'delete'],
            'attendance'      => ['view', 'create', 'edit'],
            'salary'          => ['view', 'create', 'edit'],
            'reports'         => ['view'],
            'settings'        => ['view', 'edit'],
            'activity_logs'   => ['view'],
            'notifications'   => ['view'],
        ];

        $allPermissions = [];
        foreach ($modules as $module => $actions) {
            foreach ($actions as $action) {
                $perm = Permission::create([
                    'name'   => "{$module}.{$action}",
                    'module' => $module,
                    'action' => $action,
                ]);
                $allPermissions[] = $perm->id;
            }
        }

        $superAdmin->permissions()->sync($allPermissions);
        $managerPerms = Permission::whereNotIn('module', ['admins', 'roles', 'settings', 'activity_logs'])->pluck('id');
        $manager->permissions()->sync($managerPerms);
        $staffPerms = Permission::whereIn('action', ['view', 'create'])->whereNotIn('module', ['admins', 'roles', 'settings', 'activity_logs'])->pluck('id');
        $staff->permissions()->sync($staffPerms);

        // ── Company ────────────────────────────
        $company = Company::create([
            'name'     => 'NewBusiness Corp',
            'slug'     => 'newbusiness-corp',
            'owner'    => 'Admin',
            'email'    => 'info@newbusiness.com',
            'phone'    => '+92 300 1234567',
            'country'  => 'Pakistan',
            'currency' => 'PKR',
            'currency_symbol' => '₨',
            'timezone' => 'Asia/Karachi',
        ]);

        // ── Super Admin User ───────────────────
        $admin = Admin::create([
            'role_id'  => $superAdmin->id,
            'name'     => 'Super Admin',
            'email'    => 'admin@newbusiness.com',
            'phone'    => '+92 300 1234567',
            'password' => 'password',
            'status'   => 'active',
        ]);

        // Assign admin to company
        $admin->companies()->attach($company->id, ['is_default' => true]);

        // Bind company for seeding
        app()->instance('current_company', $company);

        // ── Default Units ──────────────────────
        $units = [
            ['name' => 'Piece', 'short_name' => 'pc'],
            ['name' => 'Kilogram', 'short_name' => 'kg'],
            ['name' => 'Gram', 'short_name' => 'g'],
            ['name' => 'Liter', 'short_name' => 'ltr'],
            ['name' => 'Meter', 'short_name' => 'm'],
            ['name' => 'Box', 'short_name' => 'box'],
            ['name' => 'Dozen', 'short_name' => 'dz'],
            ['name' => 'Carton', 'short_name' => 'ctn'],
            ['name' => 'Pair', 'short_name' => 'pr'],
            ['name' => 'Set', 'short_name' => 'set'],
        ];
        foreach ($units as $u) { Unit::create($u); }

        // ── Default Warehouse ──────────────────
        Warehouse::create([
            'name' => 'Main Warehouse',
            'location' => 'Head Office',
            'is_default' => true,
            'status' => true,
        ]);

        // ── Default Chart of Accounts ──────────
        $accounts = [
            ['account_code' => '1000', 'account_name' => 'Assets', 'account_type' => 'asset', 'is_system' => true],
            ['account_code' => '1100', 'account_name' => 'Cash', 'account_type' => 'asset', 'is_system' => true, 'parent' => '1000'],
            ['account_code' => '1200', 'account_name' => 'Bank', 'account_type' => 'asset', 'is_system' => true, 'parent' => '1000'],
            ['account_code' => '1300', 'account_name' => 'Accounts Receivable', 'account_type' => 'asset', 'is_system' => true, 'parent' => '1000'],
            ['account_code' => '1400', 'account_name' => 'Inventory', 'account_type' => 'asset', 'is_system' => true, 'parent' => '1000'],
            ['account_code' => '2000', 'account_name' => 'Liabilities', 'account_type' => 'liability', 'is_system' => true],
            ['account_code' => '2100', 'account_name' => 'Accounts Payable', 'account_type' => 'liability', 'is_system' => true, 'parent' => '2000'],
            ['account_code' => '2200', 'account_name' => 'Tax Payable', 'account_type' => 'liability', 'is_system' => true, 'parent' => '2000'],
            ['account_code' => '3000', 'account_name' => 'Equity', 'account_type' => 'equity', 'is_system' => true],
            ['account_code' => '3100', 'account_name' => 'Owner Equity', 'account_type' => 'equity', 'is_system' => true, 'parent' => '3000'],
            ['account_code' => '3200', 'account_name' => 'Retained Earnings', 'account_type' => 'equity', 'is_system' => true, 'parent' => '3000'],
            ['account_code' => '4000', 'account_name' => 'Revenue', 'account_type' => 'revenue', 'is_system' => true],
            ['account_code' => '4100', 'account_name' => 'Sales Revenue', 'account_type' => 'revenue', 'is_system' => true, 'parent' => '4000'],
            ['account_code' => '4200', 'account_name' => 'Service Revenue', 'account_type' => 'revenue', 'is_system' => true, 'parent' => '4000'],
            ['account_code' => '5000', 'account_name' => 'Expenses', 'account_type' => 'expense', 'is_system' => true],
            ['account_code' => '5100', 'account_name' => 'Cost of Goods Sold', 'account_type' => 'expense', 'is_system' => true, 'parent' => '5000'],
            ['account_code' => '5200', 'account_name' => 'Salaries Expense', 'account_type' => 'expense', 'is_system' => true, 'parent' => '5000'],
            ['account_code' => '5300', 'account_name' => 'Rent Expense', 'account_type' => 'expense', 'is_system' => true, 'parent' => '5000'],
            ['account_code' => '5400', 'account_name' => 'Utilities Expense', 'account_type' => 'expense', 'is_system' => true, 'parent' => '5000'],
            ['account_code' => '5500', 'account_name' => 'Office Supplies', 'account_type' => 'expense', 'is_system' => true, 'parent' => '5000'],
        ];

        $accountMap = [];
        foreach ($accounts as $acc) {
            $parentId = null;
            if (isset($acc['parent'])) {
                $parentId = $accountMap[$acc['parent']] ?? null;
                unset($acc['parent']);
            }
            $acc['parent_id'] = $parentId;
            $created = Account::create($acc);
            $accountMap[$created->account_code] = $created->id;
        }

        // ── Default Expense Categories ─────────
        $expenseCategories = [
            'Office Supplies', 'Travel', 'Meals & Entertainment', 'Utilities',
            'Rent', 'Insurance', 'Marketing', 'Professional Services',
            'Repairs & Maintenance', 'Miscellaneous',
        ];
        foreach ($expenseCategories as $cat) {
            ExpenseCategory::create(['name' => $cat]);
        }

        // ── Default Settings ───────────────────
        $settings = [
            ['key' => 'invoice_prefix', 'value' => 'INV', 'group' => 'sales'],
            ['key' => 'quotation_prefix', 'value' => 'QUO', 'group' => 'sales'],
            ['key' => 'payment_prefix', 'value' => 'PAY', 'group' => 'sales'],
            ['key' => 'po_prefix', 'value' => 'PO', 'group' => 'purchase'],
            ['key' => 'bill_prefix', 'value' => 'BILL', 'group' => 'purchase'],
            ['key' => 'invoice_terms', 'value' => 'Payment is due within 30 days.', 'group' => 'sales'],
            ['key' => 'invoice_notes', 'value' => 'Thank you for your business!', 'group' => 'sales'],
            ['key' => 'low_stock_alert', 'value' => '10', 'group' => 'inventory'],
            ['key' => 'date_format', 'value' => 'd M Y', 'group' => 'general'],
            ['key' => 'tax_name', 'value' => 'GST', 'group' => 'general'],
            ['key' => 'default_tax_rate', 'value' => '17', 'group' => 'general'],
            ['key' => 'email_notifications', 'value' => 'off', 'group' => 'email'],
            ['key' => 'email_on_invoice', 'value' => 'off', 'group' => 'email'],
            ['key' => 'email_on_payment', 'value' => 'off', 'group' => 'email'],
        ];
        foreach ($settings as $s) { Setting::create($s); }
    }
}
