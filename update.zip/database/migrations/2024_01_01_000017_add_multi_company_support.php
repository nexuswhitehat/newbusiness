<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        // Add slug to companies
        Schema::table('companies', function (Blueprint $table) {
            $table->string('slug')->unique()->after('name');
        });

        // Pivot: admin can belong to multiple companies
        Schema::create('admin_company', function (Blueprint $table) {
            $table->id();
            $table->foreignId('admin_id')->constrained()->onDelete('cascade');
            $table->foreignId('company_id')->constrained()->onDelete('cascade');
            $table->boolean('is_default')->default(false);
            $table->unique(['admin_id', 'company_id']);
            $table->timestamps();
        });

        // Add company_id to all business tables
        $tables = [
            'customers', 'vendors', 'leads', 'products', 'categories', 'brands', 'units',
            'warehouses', 'quotations', 'invoices', 'payments', 'purchase_orders',
            'purchase_bills', 'vendor_payments', 'expenses', 'expense_categories',
            'accounts', 'journal_entries', 'bank_accounts', 'projects', 'employees',
            'notifications', 'activity_logs', 'settings',
        ];

        foreach ($tables as $tableName) {
            Schema::table($tableName, function (Blueprint $table) {
                $table->foreignId('company_id')->nullable()->after('id')->constrained()->onDelete('cascade');
            });
        }
    }

    public function down(): void
    {
        $tables = [
            'customers', 'vendors', 'leads', 'products', 'categories', 'brands', 'units',
            'warehouses', 'quotations', 'invoices', 'payments', 'purchase_orders',
            'purchase_bills', 'vendor_payments', 'expenses', 'expense_categories',
            'accounts', 'journal_entries', 'bank_accounts', 'projects', 'employees',
            'notifications', 'activity_logs', 'settings',
        ];

        foreach ($tables as $tableName) {
            Schema::table($tableName, function (Blueprint $table) {
                $table->dropForeign(['company_id']);
                $table->dropColumn('company_id');
            });
        }

        Schema::dropIfExists('admin_company');

        Schema::table('companies', function (Blueprint $table) {
            $table->dropColumn('slug');
        });
    }
};
