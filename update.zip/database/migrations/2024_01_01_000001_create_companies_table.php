<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('companies', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('owner')->nullable();
            $table->string('email')->nullable();
            $table->string('phone')->nullable();
            $table->string('website')->nullable();
            $table->string('vat_number')->nullable();
            $table->string('registration_number')->nullable();
            $table->text('address')->nullable();
            $table->string('country')->default('Pakistan');
            $table->string('currency')->default('PKR');
            $table->string('currency_symbol')->default('₨');
            $table->string('timezone')->default('Asia/Karachi');
            $table->string('logo')->nullable();
            $table->string('fiscal_year_start')->default('01-01');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('companies');
    }
};
