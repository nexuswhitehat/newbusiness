<?php

namespace Tests\Feature;

use Tests\TestCase;
use Livewire\Livewire;
use App\Models\Admin;
use App\Models\Role;
use Illuminate\Foundation\Testing\RefreshDatabase;

class LoginTest extends TestCase
{
    use RefreshDatabase;

    public function test_login_redirect()
    {
        $role = Role::create(['name' => 'Super Admin', 'is_system' => true]);
        $admin = Admin::create([
            'role_id' => $role->id,
            'name' => 'Admin',
            'email' => 'admin@test.com',
            'password' => 'password',
            'status' => 'active'
        ]);

        Livewire::test(\App\Livewire\Auth\Login::class)
            ->set('email', 'admin@test.com')
            ->set('password', 'password')
            ->call('login')
            ->assertHasNoErrors()
            ->assertRedirect();
    }
}
