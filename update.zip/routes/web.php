<?php

use Illuminate\Support\Facades\Route;
use App\Http\Middleware\AdminAuth;
use App\Http\Middleware\AdminGuest;
use App\Http\Middleware\SetCurrentCompany;

use App\Livewire\Auth\Login;
use App\Http\Controllers\Auth\LogoutController;
use App\Http\Controllers\CompanySwitcherController;

/*
|--------------------------------------------------------------------------
| Guest Routes (No Auth)
|--------------------------------------------------------------------------
*/
Route::middleware(AdminGuest::class)->group(function () {
    Route::get('/', fn() => redirect()->route('admin.login'));
    Route::get('/login', Login::class)->name('admin.login');
});

/*
|--------------------------------------------------------------------------
| Auth Routes (No Company Context)
|--------------------------------------------------------------------------
*/
Route::middleware(AdminAuth::class)->group(function () {
    Route::post('/logout', [LogoutController::class, 'logout'])->name('admin.logout');
    Route::get('/select-company', [CompanySwitcherController::class, 'index'])->name('company.select');
    Route::get('/switch/{company}', [CompanySwitcherController::class, 'switch'])->name('company.switch');
    Route::get('/create-company', \App\Livewire\Admin\CompanyCreate::class)->name('company.create');
});

/*
|--------------------------------------------------------------------------
| Company-Scoped Routes (Authenticated + Company Context)
|--------------------------------------------------------------------------
| All routes below are prefixed with /{company:slug}/
|
*/
Route::prefix('{company}')
    ->middleware([AdminAuth::class, SetCurrentCompany::class])
    ->group(function () {

    // ── Dashboard ──────────────────────────
    Route::get('/', \App\Livewire\Dashboard\Index::class)->name('dashboard');

    // ── CRM ────────────────────────────────
    Route::get('/leads',             \App\Livewire\CRM\LeadList::class)->name('leads.index');
    Route::get('/leads/create',      \App\Livewire\CRM\LeadForm::class)->name('leads.create');
    Route::get('/leads/{lead}/edit', \App\Livewire\CRM\LeadForm::class)->name('leads.edit');
    Route::get('/customers',              \App\Livewire\CRM\CustomerList::class)->name('customers.index');
    Route::get('/customers/create',       \App\Livewire\CRM\CustomerForm::class)->name('customers.create');
    Route::get('/customers/{customer}',   \App\Livewire\CRM\CustomerShow::class)->name('customers.show');
    Route::get('/customers/{customer}/edit', \App\Livewire\CRM\CustomerForm::class)->name('customers.edit');

    // ── Sales ──────────────────────────────
    Route::get('/quotations',                  \App\Livewire\Sales\QuotationList::class)->name('quotations.index');
    Route::get('/quotations/create',           \App\Livewire\Sales\QuotationForm::class)->name('quotations.create');
    Route::get('/quotations/{quotation}/edit', \App\Livewire\Sales\QuotationForm::class)->name('quotations.edit');

    Route::get('/invoices',                \App\Livewire\Sales\InvoiceList::class)->name('invoices.index');
    Route::get('/invoices/create',         \App\Livewire\Sales\InvoiceForm::class)->name('invoices.create');
    Route::get('/invoices/{invoice}',      \App\Livewire\Sales\InvoiceShow::class)->name('invoices.show');
    Route::get('/invoices/{invoice}/edit',  \App\Livewire\Sales\InvoiceForm::class)->name('invoices.edit');
    Route::get('/invoices/{invoice}/pdf',   [\App\Http\Controllers\InvoicePdfController::class, 'download'])->name('invoices.pdf');
    Route::get('/invoices/{invoice}/print', [\App\Http\Controllers\InvoicePdfController::class, 'print'])->name('invoices.print');

    Route::get('/payments',           \App\Livewire\Sales\PaymentList::class)->name('payments.index');
    Route::get('/payments/create',    \App\Livewire\Sales\PaymentForm::class)->name('payments.create');

    // ── Purchase ───────────────────────────
    Route::get('/vendors',                 \App\Livewire\Purchase\VendorList::class)->name('vendors.index');
    Route::get('/vendors/create',          \App\Livewire\Purchase\VendorForm::class)->name('vendors.create');
    Route::get('/vendors/{vendor}/edit',   \App\Livewire\Purchase\VendorForm::class)->name('vendors.edit');
    Route::get('/vendors/{vendor}',        \App\Livewire\Purchase\VendorShow::class)->name('vendors.show');

    Route::get('/purchase-orders',                 \App\Livewire\Purchase\PurchaseOrderList::class)->name('purchase-orders.index');
    Route::get('/purchase-orders/create',          \App\Livewire\Purchase\PurchaseOrderForm::class)->name('purchase-orders.create');
    Route::get('/purchase-orders/{purchaseOrder}/edit', \App\Livewire\Purchase\PurchaseOrderForm::class)->name('purchase-orders.edit');

    Route::get('/purchase-bills',                    \App\Livewire\Purchase\PurchaseBillList::class)->name('purchase-bills.index');
    Route::get('/purchase-bills/create',             \App\Livewire\Purchase\PurchaseBillForm::class)->name('purchase-bills.create');
    Route::get('/purchase-bills/{purchaseBill}/edit', \App\Livewire\Purchase\PurchaseBillForm::class)->name('purchase-bills.edit');

    Route::get('/expenses',           \App\Livewire\Purchase\ExpenseList::class)->name('expenses.index');
    Route::get('/expenses/create',    \App\Livewire\Purchase\ExpenseForm::class)->name('expenses.create');
    Route::get('/expenses/{expense}/edit', \App\Livewire\Purchase\ExpenseForm::class)->name('expenses.edit');

    // ── Inventory ──────────────────────────
    Route::get('/products',                \App\Livewire\Inventory\ProductList::class)->name('products.index');
    Route::get('/products/create',         \App\Livewire\Inventory\ProductForm::class)->name('products.create');
    Route::get('/products/{product}/edit', \App\Livewire\Inventory\ProductForm::class)->name('products.edit');

    Route::get('/categories', \App\Livewire\Inventory\CategoryList::class)->name('categories.index');
    Route::get('/warehouses', \App\Livewire\Inventory\WarehouseList::class)->name('warehouses.index');

    // ── Accounting ─────────────────────────
    Route::get('/accounts',         \App\Livewire\Accounting\AccountList::class)->name('accounts.index');
    Route::get('/journal-entries',  \App\Livewire\Accounting\JournalEntryList::class)->name('journal-entries.index');
    Route::get('/journal-entries/create', \App\Livewire\Accounting\JournalEntryForm::class)->name('journal-entries.create');

    // ── Projects ───────────────────────────
    Route::get('/projects',              \App\Livewire\Projects\ProjectList::class)->name('projects.index');
    Route::get('/projects/create',       \App\Livewire\Projects\ProjectForm::class)->name('projects.create');
    Route::get('/projects/{project}',    \App\Livewire\Projects\ProjectShow::class)->name('projects.show');
    Route::get('/projects/{project}/edit', \App\Livewire\Projects\ProjectForm::class)->name('projects.edit');

    // ── HR ──────────────────────────────────
    Route::get('/employees',                \App\Livewire\HR\EmployeeList::class)->name('employees.index');
    Route::get('/employees/create',         \App\Livewire\HR\EmployeeForm::class)->name('employees.create');
    Route::get('/employees/{employee}/edit', \App\Livewire\HR\EmployeeForm::class)->name('employees.edit');
    Route::get('/attendance',  \App\Livewire\HR\AttendanceIndex::class)->name('attendance.index');

    // ── Reports ────────────────────────────
    Route::get('/reports',       \App\Livewire\Reports\ReportIndex::class)->name('reports.index');
    Route::get('/reports/sales', \App\Livewire\Reports\SalesReport::class)->name('reports.sales');
    Route::get('/reports/purchase', \App\Livewire\Reports\PurchaseReport::class)->name('reports.purchase');
    Route::get('/reports/profit', \App\Livewire\Reports\ProfitReport::class)->name('reports.profit');
    Route::get('/reports/stock', \App\Livewire\Reports\StockReport::class)->name('reports.stock');
    Route::get('/reports/customer-ledger', \App\Livewire\Reports\CustomerLedgerReport::class)->name('reports.customer-ledger');
    Route::get('/reports/vendor-ledger', \App\Livewire\Reports\VendorLedgerReport::class)->name('reports.vendor-ledger');

    // ── System / Admin ─────────────────────
    Route::get('/roles',                \App\Livewire\Admin\RoleList::class)->name('admin.roles.index');
    Route::get('/roles/create',         \App\Livewire\Admin\RoleForm::class)->name('admin.roles.create');
    Route::get('/roles/{role}/edit',    \App\Livewire\Admin\RoleForm::class)->name('admin.roles.edit');
    Route::get('/admins',               \App\Livewire\Admin\AdminList::class)->name('admin.admins.index');
    Route::get('/admins/create',        \App\Livewire\Admin\AdminForm::class)->name('admin.admins.create');
    Route::get('/admins/{admin}/edit',  \App\Livewire\Admin\AdminForm::class)->name('admin.admins.edit');
    Route::get('/company-settings',     \App\Livewire\Admin\CompanySettings::class)->name('admin.company');
    Route::get('/activity-logs',        \App\Livewire\Admin\ActivityLogList::class)->name('admin.activity-logs');
    Route::get('/update', [\App\Http\Controllers\Admin\UpdateController::class, 'index'])->name('admin.update');
    Route::post('/update/run', [\App\Http\Controllers\Admin\UpdateController::class, 'run'])->name('admin.update.run');
});
