document.addEventListener('alpine:init', () => {
    // Theme Management
    window.Alpine.store('theme', {
        mode: localStorage.getItem('theme') || 'dark',

        init() {
            document.documentElement.setAttribute('data-theme', this.mode);
        },

        toggle() {
            this.mode = this.mode === 'dark' ? 'light' : 'dark';
            localStorage.setItem('theme', this.mode);
            document.documentElement.setAttribute('data-theme', this.mode);
        }
    });

    // Sidebar state
    window.Alpine.store('sidebar', {
        open: false,
        collapsed: localStorage.getItem('sidebarCollapsed') === 'true',

        toggle() {
            this.open = !this.open;
        },

        toggleCollapse() {
            this.collapsed = !this.collapsed;
            localStorage.setItem('sidebarCollapsed', this.collapsed);
        },

        close() {
            this.open = false;
        }
    });
});

// Apply theme on page load (before Alpine starts to avoid flash)
(function() {
    const theme = localStorage.getItem('theme') || 'dark';
    document.documentElement.setAttribute('data-theme', theme);
})();
