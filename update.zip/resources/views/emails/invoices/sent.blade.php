<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8fafc;
            color: #334155;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }
        .header {
            text-align: center;
            border-bottom: 2px solid #e2e8f0;
            padding-bottom: 20px;
            margin-bottom: 20px;
        }
        .header h1 {
            color: #4f46e5;
            margin: 0;
            font-size: 24px;
        }
        .content {
            margin-bottom: 30px;
        }
        .details {
            background-color: #f1f5f9;
            padding: 15px;
            border-radius: 6px;
            margin-top: 20px;
        }
        .footer {
            text-align: center;
            font-size: 12px;
            color: #94a3b8;
            border-top: 1px solid #e2e8f0;
            padding-top: 20px;
            margin-top: 20px;
        }
        .btn {
            display: inline-block;
            background-color: #4f46e5;
            color: #ffffff;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 6px;
            font-weight: bold;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>{{ $company->name }}</h1>
        </div>
        
        <div class="content">
            <p>Dear {{ $invoice->customer->customer_name }},</p>
            
            <p>I hope this email finds you well.</p>
            
            <p>Please find attached invoice <strong>{{ $invoice->invoice_no }}</strong> for {{ $company->currency_symbol }} {{ number_format($invoice->grand_total, 2) }}.</p>
            
            <div class="details">
                <p><strong>Invoice Number:</strong> {{ $invoice->invoice_no }}</p>
                <p><strong>Invoice Date:</strong> {{ $invoice->invoice_date->format('d M Y') }}</p>
                @if($invoice->due_date)
                <p><strong>Due Date:</strong> {{ $invoice->due_date->format('d M Y') }}</p>
                @endif
                <p><strong>Amount Due:</strong> {{ $company->currency_symbol }} {{ number_format($invoice->due_amount, 2) }}</p>
            </div>
            
            <p>If you have any questions, please do not hesitate to contact us.</p>
            
            <p>Thank you for your business!</p>
        </div>
        
        <div class="footer">
            <p>&copy; {{ date('Y') }} {{ $company->name }}. All rights reserved.</p>
            @if($company->address)<p>{{ $company->address }}</p>@endif
        </div>
    </div>
</body>
</html>
