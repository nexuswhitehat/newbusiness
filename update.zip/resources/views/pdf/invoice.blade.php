<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice {{ $invoice->invoice_no }}</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'DejaVu Sans', Arial, sans-serif; font-size: 12px; color: #1e293b; background: #fff; }
        .container { padding: 30px; max-width: 800px; margin: 0 auto; }

        /* Header */
        .header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 30px; border-bottom: 2px solid #6366f1; padding-bottom: 20px; }
        .company-name { font-size: 22px; font-weight: 700; color: #4f46e5; }
        .company-info { font-size: 10px; color: #64748b; margin-top: 4px; line-height: 1.5; }
        .invoice-title { text-align: right; }
        .invoice-title h1 { font-size: 28px; font-weight: 800; color: #6366f1; letter-spacing: 2px; }
        .invoice-no { font-size: 14px; font-weight: 600; color: #1e293b; margin-top: 4px; }
        .invoice-status { display: inline-block; padding: 3px 10px; border-radius: 20px; font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; margin-top: 6px; }
        .status-paid { background: #d1fae5; color: #065f46; }
        .status-sent { background: #dbeafe; color: #1e40af; }
        .status-partial { background: #ffedd5; color: #9a3412; }
        .status-draft { background: #f1f5f9; color: #475569; }
        .status-overdue { background: #fee2e2; color: #991b1b; }

        /* Bill To Section */
        .meta { display: flex; justify-content: space-between; margin-bottom: 25px; }
        .bill-to { flex: 1; }
        .bill-to h4 { font-size: 9px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; color: #94a3b8; margin-bottom: 6px; }
        .bill-to .name { font-size: 14px; font-weight: 600; color: #0f172a; }
        .bill-to .detail { font-size: 10px; color: #64748b; line-height: 1.6; margin-top: 3px; }
        .invoice-details { text-align: right; }
        .invoice-details table { margin-left: auto; }
        .invoice-details td { padding: 2px 0 2px 15px; font-size: 11px; }
        .invoice-details td:first-child { color: #94a3b8; }
        .invoice-details td:last-child { font-weight: 600; color: #1e293b; }

        /* Items Table */
        .items-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        .items-table thead th { background: #6366f1; color: white; padding: 10px 12px; text-align: left; font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; }
        .items-table thead th.right { text-align: right; }
        .items-table thead th.center { text-align: center; }
        .items-table tbody tr:nth-child(even) { background: #f8fafc; }
        .items-table tbody td { padding: 9px 12px; font-size: 11px; color: #334155; border-bottom: 1px solid #e2e8f0; vertical-align: top; }
        .items-table tbody td.right { text-align: right; }
        .items-table tbody td.center { text-align: center; }
        .item-name { font-weight: 600; color: #1e293b; }
        .item-sku { font-size: 9px; color: #94a3b8; margin-top: 2px; }

        /* Totals */
        .totals-section { display: flex; justify-content: flex-end; margin-bottom: 25px; }
        .totals-table { width: 280px; }
        .totals-table td { padding: 5px 0; font-size: 11px; }
        .totals-table td:first-child { color: #64748b; }
        .totals-table td:last-child { text-align: right; font-weight: 600; color: #1e293b; }
        .totals-table .grand-total td { font-size: 14px; font-weight: 800; color: #4f46e5; border-top: 2px solid #6366f1; padding-top: 8px; margin-top: 5px; }
        .totals-table .discount td { color: #ef4444; }

        /* Footer */
        .footer-section { display: flex; gap: 30px; margin-top: 20px; }
        .notes-box { flex: 1; }
        .notes-box h4 { font-size: 10px; font-weight: 700; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 6px; }
        .notes-box p { font-size: 10px; color: #64748b; line-height: 1.6; }

        /* Payments */
        .payments-section { margin-top: 20px; border-top: 1px solid #e2e8f0; padding-top: 15px; }
        .payments-section h4 { font-size: 10px; font-weight: 700; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 8px; }
        .payments-table { width: 100%; }
        .payments-table td { font-size: 10px; padding: 4px 8px 4px 0; color: #334155; }

        /* Watermark for paid */
        .paid-watermark { position: fixed; top: 40%; left: 50%; transform: translate(-50%, -50%) rotate(-30deg); font-size: 100px; font-weight: 900; color: rgba(16, 185, 129, 0.08); letter-spacing: 10px; z-index: 0; pointer-events: none; }

        /* Print button (for browser view only) */
        .print-btn { position: fixed; top: 20px; right: 20px; background: #6366f1; color: white; border: none; padding: 10px 20px; border-radius: 8px; cursor: pointer; font-size: 14px; font-weight: 600; box-shadow: 0 4px 12px rgba(99,102,241,0.3); z-index: 100; }
        @media print { .print-btn { display: none; } .paid-watermark { display: none; } }
    </style>
</head>
<body>
    <button class="print-btn" onclick="window.print()">🖨️ Print</button>

    @if($invoice->status === 'paid')
    <div class="paid-watermark">PAID</div>
    @endif

    <div class="container">
        {{-- Header --}}
        <div class="header">
            <div>
                <div class="company-name">{{ $currentCompany->name }}</div>
                <div class="company-info">
                    @if($currentCompany->address){{ $currentCompany->address }}<br>@endif
                    @if($currentCompany->phone){{ $currentCompany->phone }}<br>@endif
                    @if($currentCompany->email){{ $currentCompany->email }}<br>@endif
                    @if($currentCompany->vat_number)VAT: {{ $currentCompany->vat_number }}@endif
                </div>
            </div>
            <div class="invoice-title">
                <h1>INVOICE</h1>
                <div class="invoice-no">{{ $invoice->invoice_no }}</div>
                @php $sc = ['draft'=>'status-draft','sent'=>'status-sent','partial'=>'status-partial','paid'=>'status-paid','overdue'=>'status-overdue']; @endphp
                <div class="invoice-status {{ $sc[$invoice->status] ?? 'status-draft' }}">{{ strtoupper($invoice->status) }}</div>
            </div>
        </div>

        {{-- Bill To / Dates --}}
        <div class="meta">
            <div class="bill-to">
                <h4>Bill To</h4>
                <div class="name">{{ $invoice->customer->customer_name ?? 'N/A' }}</div>
                @if($invoice->customer->company_name)<div class="detail">{{ $invoice->customer->company_name }}</div>@endif
                @if($invoice->customer->billing_address)<div class="detail">{{ $invoice->customer->billing_address }}</div>@endif
                @if($invoice->customer->phone)<div class="detail">{{ $invoice->customer->phone }}</div>@endif
                @if($invoice->customer->email)<div class="detail">{{ $invoice->customer->email }}</div>@endif
                @if($invoice->customer->vat_number)<div class="detail">VAT: {{ $invoice->customer->vat_number }}</div>@endif
            </div>
            <div class="invoice-details">
                <table>
                    <tr><td>Invoice Date:</td><td>{{ $invoice->invoice_date->format('d M Y') }}</td></tr>
                    @if($invoice->due_date)<tr><td>Due Date:</td><td>{{ $invoice->due_date->format('d M Y') }}</td></tr>@endif
                    @if($invoice->reference)<tr><td>Reference:</td><td>{{ $invoice->reference }}</td></tr>@endif
                    @if($invoice->payment_terms)<tr><td>Terms:</td><td>{{ ucfirst(str_replace('_',' ',$invoice->payment_terms)) }}</td></tr>@endif
                    <tr><td>Currency:</td><td>{{ $currentCompany->currency }}</td></tr>
                </table>
            </div>
        </div>

        {{-- Line Items --}}
        <table class="items-table">
            <thead>
                <tr>
                    <th style="width:30px">#</th>
                    <th>Description</th>
                    <th class="center" style="width:60px">Qty</th>
                    <th class="right" style="width:100px">Unit Price</th>
                    <th class="center" style="width:60px">Disc%</th>
                    <th class="right" style="width:100px">Total</th>
                </tr>
            </thead>
            <tbody>
                @foreach($invoice->items as $i => $item)
                <tr>
                    <td>{{ $i+1 }}</td>
                    <td>
                        <div class="item-name">{{ $item->description }}</div>
                        @if($item->product)<div class="item-sku">SKU: {{ $item->product->sku }}</div>@endif
                    </td>
                    <td class="center">{{ $item->qty }}</td>
                    <td class="right">{{ $currentCompany->currency_symbol }} {{ number_format($item->unit_price, 2) }}</td>
                    <td class="center">{{ $item->discount > 0 ? $item->discount.'%' : '-' }}</td>
                    <td class="right">{{ $currentCompany->currency_symbol }} {{ number_format($item->total, 2) }}</td>
                </tr>
                @endforeach
            </tbody>
        </table>

        {{-- Totals --}}
        <div class="totals-section">
            <table class="totals-table">
                <tr><td>Subtotal</td><td>{{ $currentCompany->currency_symbol }} {{ number_format($invoice->subtotal, 2) }}</td></tr>
                @if($invoice->discount_amount > 0)
                <tr class="discount"><td>Discount ({{ $invoice->discount_value }}%)</td><td>- {{ $currentCompany->currency_symbol }} {{ number_format($invoice->discount_amount, 2) }}</td></tr>
                @endif
                @if($invoice->tax_amount > 0)
                <tr><td>Tax ({{ $invoice->tax_rate }}%)</td><td>+ {{ $currentCompany->currency_symbol }} {{ number_format($invoice->tax_amount, 2) }}</td></tr>
                @endif
                <tr class="grand-total"><td>Grand Total</td><td>{{ $currentCompany->currency_symbol }} {{ number_format($invoice->grand_total, 2) }}</td></tr>
                @if($invoice->paid_amount > 0)
                <tr><td>Paid</td><td style="color:#10b981;">{{ $currentCompany->currency_symbol }} {{ number_format($invoice->paid_amount, 2) }}</td></tr>
                <tr><td><strong>Balance Due</strong></td><td style="color:#ef4444;font-weight:800;">{{ $currentCompany->currency_symbol }} {{ number_format($invoice->due_amount, 2) }}</td></tr>
                @endif
            </table>
        </div>

        {{-- Notes & Terms --}}
        @if($invoice->notes || $invoice->terms)
        <div class="footer-section">
            @if($invoice->notes)<div class="notes-box"><h4>Notes</h4><p>{{ $invoice->notes }}</p></div>@endif
            @if($invoice->terms)<div class="notes-box"><h4>Terms & Conditions</h4><p>{{ $invoice->terms }}</p></div>@endif
        </div>
        @endif

        {{-- Payments --}}
        @if($invoice->payments->count() > 0)
        <div class="payments-section">
            <h4>Payment History</h4>
            <table class="payments-table">
                @foreach($invoice->payments as $pay)
                <tr>
                    <td>{{ $pay->payment_no }}</td>
                    <td>{{ $pay->payment_date->format('d M Y') }}</td>
                    <td>{{ ucfirst(str_replace('_',' ',$pay->payment_method)) }}</td>
                    <td style="text-align:right; font-weight:600; color:#10b981;">{{ $currentCompany->currency_symbol }} {{ number_format($pay->amount, 2) }}</td>
                </tr>
                @endforeach
            </table>
        </div>
        @endif

        {{-- Footer --}}
        <div style="margin-top: 30px; padding-top: 15px; border-top: 1px solid #e2e8f0; text-align: center; font-size: 10px; color: #94a3b8;">
            <p>Thank you for your business! · {{ $currentCompany->name }} · {{ $currentCompany->email }}</p>
        </div>
    </div>
</body>
</html>
