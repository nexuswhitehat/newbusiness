<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Select Company — NewBusiness ERP</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <script>document.documentElement.setAttribute('data-theme', localStorage.getItem('theme') || 'dark');</script>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="antialiased">
<div class="login-bg">
    <div class="w-full max-w-lg px-4" x-data>
        <div class="text-center mb-8">
            <div class="w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 mx-auto flex items-center justify-center text-white text-2xl font-bold shadow-lg mb-4">NB</div>
            <h1 class="text-2xl font-bold text-white">Select Company</h1>
            <p class="text-sm text-slate-400 mt-1">Choose a company to continue</p>
        </div>

        <div class="space-y-3">
            @foreach($companies as $company)
                <a href="{{ route('dashboard', $company->slug) }}"
                   class="login-card block !p-5 hover:border-indigo-400/50 hover:bg-slate-800/90 transition-all group cursor-pointer">
                    <div class="flex items-center gap-4">
                        <div class="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500/20 to-purple-500/20 border border-indigo-500/30 flex items-center justify-center">
                            @if($company->logo)
                                <img src="{{ $company->logo_url }}" class="w-8 h-8 rounded object-cover">
                            @else
                                <span class="text-lg font-bold text-indigo-400">{{ substr($company->name, 0, 1) }}</span>
                            @endif
                        </div>
                        <div class="flex-1">
                            <h3 class="text-white font-semibold group-hover:text-indigo-300 transition">{{ $company->name }}</h3>
                            <p class="text-xs text-slate-400">{{ $company->currency }} · {{ $company->country }}</p>
                        </div>
                        <svg class="w-5 h-5 text-slate-500 group-hover:text-indigo-400 transition" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
                    </div>
                </a>
            @endforeach
        </div>

        @if(auth('admin')->user()->isSuperAdmin())
        <div class="mt-4">
            <a href="{{ route('company.create') }}"
               class="login-card block !p-4 hover:border-indigo-400/50 hover:bg-slate-800/90 transition-all group cursor-pointer text-center border-2 border-dashed !border-slate-600 hover:!border-indigo-500">
                <div class="flex items-center justify-center gap-3">
                    <div class="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center">
                        <svg class="w-5 h-5 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                    </div>
                    <span class="text-sm font-semibold text-indigo-400 group-hover:text-indigo-300 transition">Create New Company</span>
                </div>
            </a>
        </div>
        @endif

        <div class="mt-6 text-center">
            <form method="POST" action="{{ route('admin.logout') }}">
                @csrf
                <button type="submit" class="text-sm text-slate-500 hover:text-red-400 transition">Sign out</button>
            </form>
        </div>
    </div>
</div>
</body>
</html>
