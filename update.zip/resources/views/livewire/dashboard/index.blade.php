<div>
    {{-- Page Header --}}
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
        <div>
            <h1 class="text-2xl font-bold" style="color: var(--text-primary);">Dashboard</h1>
            <p class="text-sm mt-1" style="color: var(--text-muted);">Welcome back, {{ auth('admin')->user()->name }}!</p>
        </div>
        <div class="mt-3 sm:mt-0 flex items-center gap-2">
            <span class="text-xs px-3 py-1 rounded-full" style="background: var(--bg-active); color: var(--color-primary);">
                {{ now()->format('d M Y, l') }}
            </span>
        </div>
    </div>

    {{-- KPI Cards --}}
    <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">
        <div class="stat-card stat-card-purple">
            <div class="flex items-center justify-between mb-3">
                <div class="w-10 h-10 rounded-lg bg-indigo-500/10 flex items-center justify-center">
                    <svg class="w-5 h-5 text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                </div>
            </div>
            <p class="text-xl font-bold" style="color: var(--text-primary);">{{ $currentCompany->currency_symbol ?? '₨' }} {{ number_format($monthlyRevenue) }}</p>
            <p class="text-xs mt-1" style="color: var(--text-muted);">Monthly Revenue</p>
        </div>

        <div class="stat-card stat-card-green">
            <div class="flex items-center justify-between mb-3">
                <div class="w-10 h-10 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                    <svg class="w-5 h-5 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
                </div>
            </div>
            <p class="text-xl font-bold" style="color: var(--text-primary);">{{ $currentCompany->currency_symbol ?? '₨' }} {{ number_format($monthlyPayments) }}</p>
            <p class="text-xs mt-1" style="color: var(--text-muted);">Payments Received</p>
        </div>

        <div class="stat-card stat-card-red">
            <div class="flex items-center justify-between mb-3">
                <div class="w-10 h-10 rounded-lg bg-red-500/10 flex items-center justify-center">
                    <svg class="w-5 h-5 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 17h8m0 0V9m0 8l-8-8-4 4-6-6"/></svg>
                </div>
            </div>
            <p class="text-xl font-bold" style="color: var(--text-primary);">{{ $currentCompany->currency_symbol ?? '₨' }} {{ number_format($monthlyExpenses + $monthlyPurchases) }}</p>
            <p class="text-xs mt-1" style="color: var(--text-muted);">Total Expenses</p>
        </div>

        <div class="stat-card stat-card-blue">
            <div class="flex items-center justify-between mb-3">
                <div class="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
                    <svg class="w-5 h-5 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                </div>
            </div>
            <p class="text-xl font-bold" style="color: var(--text-primary);">{{ number_format($totalCustomers) }}</p>
            <p class="text-xs mt-1" style="color: var(--text-muted);">Customers</p>
        </div>

        <div class="stat-card stat-card-orange">
            <div class="flex items-center justify-between mb-3">
                <div class="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center">
                    <svg class="w-5 h-5 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
                </div>
            </div>
            <p class="text-xl font-bold" style="color: var(--text-primary);">{{ number_format($totalProducts) }}</p>
            <p class="text-xs mt-1" style="color: var(--text-muted);">Products</p>
        </div>

        <div class="stat-card stat-card-cyan">
            <div class="flex items-center justify-between mb-3">
                <div class="w-10 h-10 rounded-lg bg-cyan-500/10 flex items-center justify-center">
                    <svg class="w-5 h-5 text-cyan-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 18.657A8 8 0 016.343 7.343S7 9 9 10c0-2 .5-5 2.986-7C14 5 16.09 5.777 17.656 7.343A7.975 7.975 0 0120 13a7.975 7.975 0 01-2.343 5.657z"/></svg>
                </div>
            </div>
            <p class="text-xl font-bold" style="color: var(--text-primary);">{{ number_format($activeLeads) }}</p>
            <p class="text-xs mt-1" style="color: var(--text-muted);">Active Leads</p>
        </div>
    </div>

    {{-- Financial Summary + Receivable/Payable --}}
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        {{-- Revenue Chart --}}
        <div class="card p-5 lg:col-span-2">
            <h3 class="text-sm font-semibold mb-4" style="color: var(--text-primary);">Revenue vs Expenses (Last 6 Months)</h3>
            <canvas id="revenueChart" height="120"></canvas>
        </div>

        {{-- Receivable / Payable --}}
        <div class="space-y-4">
            <div class="card p-5">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-xs font-medium" style="color: var(--text-muted);">Total Receivable</p>
                        <p class="text-2xl font-bold mt-1 text-emerald-500">{{ $currentCompany->currency_symbol ?? '₨' }} {{ number_format($totalReceivable) }}</p>
                    </div>
                    <div class="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center">
                        <svg class="w-6 h-6 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 11l5-5m0 0l5 5m-5-5v12"/></svg>
                    </div>
                </div>
            </div>
            <div class="card p-5">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-xs font-medium" style="color: var(--text-muted);">Total Payable</p>
                        <p class="text-2xl font-bold mt-1 text-red-500">{{ $currentCompany->currency_symbol ?? '₨' }} {{ number_format($totalPayable) }}</p>
                    </div>
                    <div class="w-12 h-12 rounded-xl bg-red-500/10 flex items-center justify-center">
                        <svg class="w-6 h-6 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 13l-5 5m0 0l-5-5m5 5V6"/></svg>
                    </div>
                </div>
            </div>
            <div class="card p-5">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-xs font-medium" style="color: var(--text-muted);">Active Projects</p>
                        <p class="text-2xl font-bold mt-1 text-indigo-500">{{ $activeProjects }}</p>
                    </div>
                    <div class="w-12 h-12 rounded-xl bg-indigo-500/10 flex items-center justify-center">
                        <svg class="w-6 h-6 text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- Recent Invoices + Recent Payments --}}
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
        {{-- Recent Invoices --}}
        <div class="card">
            <div class="px-5 py-4 border-b flex items-center justify-between" style="border-color: var(--border-color);">
                <h3 class="text-sm font-semibold" style="color: var(--text-primary);">Recent Invoices</h3>
                <a href="{{ route('invoices.index', $currentCompany->slug) }}" class="text-xs text-indigo-500 hover:text-indigo-400">View All →</a>
            </div>
            <div class="divide-y" style="border-color: var(--border-light);">
                @forelse($recentInvoices as $inv)
                <div class="px-5 py-3 flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium" style="color: var(--text-primary);">{{ $inv->invoice_no }}</p>
                        <p class="text-xs" style="color: var(--text-muted);">{{ $inv->customer->customer_name ?? 'N/A' }}</p>
                    </div>
                    <div class="text-right">
                        <p class="text-sm font-semibold" style="color: var(--text-primary);">{{ $currentCompany->currency_symbol ?? '₨' }} {{ number_format($inv->grand_total, 2) }}</p>
                        <span class="badge badge-{{ $inv->status_color }}">{{ ucfirst($inv->status) }}</span>
                    </div>
                </div>
                @empty
                <div class="px-5 py-8 text-center text-sm" style="color: var(--text-muted);">No invoices yet</div>
                @endforelse
            </div>
        </div>

        {{-- Recent Payments --}}
        <div class="card">
            <div class="px-5 py-4 border-b flex items-center justify-between" style="border-color: var(--border-color);">
                <h3 class="text-sm font-semibold" style="color: var(--text-primary);">Recent Payments</h3>
                <a href="{{ route('payments.index', $currentCompany->slug) }}" class="text-xs text-indigo-500 hover:text-indigo-400">View All →</a>
            </div>
            <div class="divide-y" style="border-color: var(--border-light);">
                @forelse($recentPayments as $pay)
                <div class="px-5 py-3 flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium" style="color: var(--text-primary);">{{ $pay->payment_no }}</p>
                        <p class="text-xs" style="color: var(--text-muted);">{{ $pay->customer->customer_name ?? 'N/A' }} · {{ $pay->payment_date->format('d M Y') }}</p>
                    </div>
                    <div class="text-right">
                        <p class="text-sm font-semibold text-emerald-500">{{ $currentCompany->currency_symbol ?? '₨' }} {{ number_format($pay->amount, 2) }}</p>
                        <span class="badge badge-blue">{{ ucfirst(str_replace('_', ' ', $pay->payment_method)) }}</span>
                    </div>
                </div>
                @empty
                <div class="px-5 py-8 text-center text-sm" style="color: var(--text-muted);">No payments yet</div>
                @endforelse
            </div>
        </div>
    </div>
</div>

{{-- Chart.js --}}
@script
<script>
    const ctx = document.getElementById('revenueChart');
    if (ctx) {
        new Chart(ctx.getContext('2d'), {
            type: 'bar',
            data: {
                labels: @json($chartLabels),
                datasets: [
                    {
                        label: 'Revenue',
                        data: @json($chartRevenue),
                        backgroundColor: 'rgba(99, 102, 241, 0.7)',
                        borderColor: 'rgba(99, 102, 241, 1)',
                        borderWidth: 1,
                        borderRadius: 6,
                    },
                    {
                        label: 'Expenses',
                        data: @json($chartExpenses),
                        backgroundColor: 'rgba(239, 68, 68, 0.5)',
                        borderColor: 'rgba(239, 68, 68, 1)',
                        borderWidth: 1,
                        borderRadius: 6,
                    }
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        labels: { color: getComputedStyle(document.documentElement).getPropertyValue('--text-secondary').trim(), font: { size: 11 } }
                    }
                },
                scales: {
                    x: { ticks: { color: getComputedStyle(document.documentElement).getPropertyValue('--text-muted').trim(), font: { size: 10 } }, grid: { display: false } },
                    y: { ticks: { color: getComputedStyle(document.documentElement).getPropertyValue('--text-muted').trim(), font: { size: 10 } }, grid: { color: 'rgba(148, 163, 184, 0.1)' } }
                }
            }
        });
    }
</script>
@endscript
