<div>
    <div class="flex items-center gap-3 mb-6">
        <a href="{{ route('reports.index', $company->slug) }}" class="btn btn-ghost btn-sm"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg></a>
        <h1 class="text-2xl font-bold" style="color: var(--text-primary);">Customer Ledger</h1>
    </div>
    <div class="card p-4 mb-5"><div class="flex flex-wrap gap-3"><div class="flex-1 min-w-[200px]"><label class="form-label">Customer</label><select wire:model.live="customer_id" class="form-select"><option value="">Select customer...</option>@foreach($customers as $c)<option value="{{ $c->id }}">{{ $c->customer_name }}</option>@endforeach</select></div><div><label class="form-label">From</label><input wire:model.live="from" type="date" class="form-input w-auto"></div><div><label class="form-label">To</label><input wire:model.live="to" type="date" class="form-input w-auto"></div></div></div>
    @if($customer)
    <div class="card p-4 mb-4 flex justify-between items-center"><div><p class="font-semibold" style="color: var(--text-primary);">{{ $customer->customer_name }}</p><p class="text-xs" style="color: var(--text-muted);">{{ $customer->phone }}</p></div><div class="text-right"><p class="text-xs" style="color: var(--text-muted);">Current Balance</p><p class="text-xl font-bold {{ $customer->current_balance>0?'text-red-500':'text-emerald-500' }}">{{ $company->currency_symbol }} {{ number_format($customer->current_balance,2) }}</p></div></div>
    <div class="card overflow-x-auto">
        <table class="data-table"><thead><tr><th>Date</th><th>Reference</th><th>Type</th><th class="text-right">Debit</th><th class="text-right">Credit</th><th class="text-right">Balance</th><th>Remarks</th></tr></thead>
        <tbody>
            @forelse($ledger as $entry)
            <tr><td>{{ $entry->date->format('d M Y') }}</td><td class="font-mono text-xs">{{ $entry->reference??'-' }}</td><td><span class="badge badge-gray">{{ ucfirst(str_replace('_',' ',$entry->type)) }}</span></td><td class="text-right {{ $entry->debit>0?'text-red-500':'' }}">{{ $entry->debit>0?$company->currency_symbol.' '.number_format($entry->debit,2):'-' }}</td><td class="text-right {{ $entry->credit>0?'text-emerald-500':'' }}">{{ $entry->credit>0?$company->currency_symbol.' '.number_format($entry->credit,2):'-' }}</td><td class="text-right font-semibold" style="color: var(--text-primary);">{{ $company->currency_symbol }} {{ number_format($entry->balance,2) }}</td><td class="text-xs" style="color: var(--text-muted);">{{ $entry->remarks??'-' }}</td></tr>
            @empty<tr><td colspan="7" class="text-center py-8" style="color: var(--text-muted);">No ledger entries in selected period.</td></tr>@endforelse
        </tbody></table>
    </div>
    @else
    <div class="card p-12 text-center" style="color: var(--text-muted);"><p>Select a customer to view their ledger.</p></div>
    @endif
</div>
