<div>
    <div class="flex items-center gap-3 mb-6">
        <a href="{{ route('reports.index', $company->slug) }}" class="btn btn-ghost btn-sm"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg></a>
        <div><h1 class="text-2xl font-bold" style="color: var(--text-primary);">Stock Report</h1><p class="text-sm mt-1" style="color: var(--text-muted);">Total inventory value: {{ $company->currency_symbol }} {{ number_format($totalValue, 2) }}</p></div>
    </div>
    <div class="card p-4 mb-4">
        <div class="flex gap-3">
            <select wire:model.live="filter" class="form-select w-auto"><option value="all">All Products</option><option value="low">Low Stock</option><option value="out">Out of Stock</option></select>
        </div>
    </div>
    <div class="card overflow-x-auto">
        <table class="data-table">
            <thead><tr><th>SKU</th><th>Product</th><th>Category</th><th class="text-center">Stock</th><th>Unit</th><th class="text-right">Cost</th><th class="text-right">Value</th><th>Alert</th></tr></thead>
            <tbody>
                @forelse($products as $p)
                <tr>
                    <td class="font-mono text-xs text-indigo-400">{{ $p->sku }}</td>
                    <td class="font-medium" style="color: var(--text-primary);">{{ $p->name }}</td>
                    <td><span class="badge badge-gray">{{ $p->category->name??'-' }}</span></td>
                    <td class="text-center font-bold {{ $p->total_stock<=0?'text-red-500':($p->total_stock<=$p->minimum_stock?'text-amber-500':'text-emerald-500') }}">{{ number_format($p->total_stock) }}</td>
                    <td class="text-xs" style="color: var(--text-muted);">{{ $p->unit->short_name??'-' }}</td>
                    <td class="text-right">{{ $company->currency_symbol }} {{ number_format($p->purchase_price,2) }}</td>
                    <td class="text-right font-semibold" style="color: var(--text-primary);">{{ $company->currency_symbol }} {{ number_format($p->total_stock * $p->purchase_price,2) }}</td>
                    <td>@if($p->total_stock<=0)<span class="badge badge-red">Out</span>@elseif($p->total_stock<=$p->minimum_stock)<span class="badge badge-orange">Low</span>@else<span class="badge badge-green">OK</span>@endif</td>
                </tr>
                @empty<tr><td colspan="8" class="text-center py-8" style="color: var(--text-muted);">No products.</td></tr>@endforelse
            </tbody>
        </table>
    </div>
</div>
