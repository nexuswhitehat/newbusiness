<div>
    <div class="flex items-center gap-3 mb-6">
        <a href="{{ route('reports.index', $company->slug) }}" class="btn btn-ghost btn-sm"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg></a>
        <h1 class="text-2xl font-bold" style="color: var(--text-primary);">Sales Report</h1>
    </div>
    <div class="card p-4 mb-5"><div class="flex flex-wrap gap-3 items-end"><div><label class="form-label">From</label><input wire:model.live="from" type="date" class="form-input w-auto"></div><div><label class="form-label">To</label><input wire:model.live="to" type="date" class="form-input w-auto"></div></div></div>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-5">
        <div class="stat-card stat-card-purple"><p class="text-xs" style="color: var(--text-muted);">Total Revenue</p><p class="text-2xl font-bold mt-1" style="color: var(--text-primary);">{{ $company->currency_symbol }} {{ number_format($totalRevenue,2) }}</p></div>
        <div class="stat-card stat-card-green"><p class="text-xs" style="color: var(--text-muted);">Total Collected</p><p class="text-2xl font-bold text-emerald-500 mt-1">{{ $company->currency_symbol }} {{ number_format($totalPaid,2) }}</p></div>
        <div class="stat-card stat-card-red"><p class="text-xs" style="color: var(--text-muted);">Outstanding</p><p class="text-2xl font-bold text-red-500 mt-1">{{ $company->currency_symbol }} {{ number_format($totalDue,2) }}</p></div>
    </div>
    <div class="card overflow-x-auto">
        <table class="data-table">
            <thead><tr><th>Invoice#</th><th>Customer</th><th>Date</th><th>Total</th><th>Paid</th><th>Due</th><th>Status</th></tr></thead>
            <tbody>
                @forelse($invoices as $inv)
                @php $sc=['draft'=>'badge-gray','sent'=>'badge-blue','partial'=>'badge-orange','paid'=>'badge-green','overdue'=>'badge-red','cancelled'=>'badge-gray']; @endphp
                <tr><td><a href="{{ route('invoices.show',[$company->slug,$inv->id]) }}" class="text-indigo-500 hover:underline">{{ $inv->invoice_no }}</a></td><td>{{ $inv->customer->customer_name??'-' }}</td><td>{{ $inv->invoice_date->format('d M Y') }}</td><td class="font-semibold">{{ $company->currency_symbol }} {{ number_format($inv->grand_total,2) }}</td><td class="text-emerald-500">{{ $company->currency_symbol }} {{ number_format($inv->paid_amount,2) }}</td><td class="{{ $inv->due_amount>0?'text-red-500 font-semibold':'' }}">{{ $company->currency_symbol }} {{ number_format($inv->due_amount,2) }}</td><td><span class="badge {{ $sc[$inv->status]??'badge-gray' }}">{{ ucfirst($inv->status) }}</span></td></tr>
                @empty<tr><td colspan="7" class="text-center py-8" style="color: var(--text-muted);">No invoices in selected period.</td></tr>@endforelse
            </tbody>
        </table>
    </div>
</div>
