<div>
    <div class="flex items-center gap-3 mb-6">
        <a href="{{ route('reports.index', $company->slug) }}" class="btn btn-ghost btn-sm"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg></a>
        <h1 class="text-2xl font-bold" style="color: var(--text-primary);">Purchase Report</h1>
    </div>
    <div class="card p-4 mb-5"><div class="flex gap-3"><div><label class="form-label">From</label><input wire:model.live="from" type="date" class="form-input w-auto"></div><div><label class="form-label">To</label><input wire:model.live="to" type="date" class="form-input w-auto"></div></div></div>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-5">
        <div class="stat-card stat-card-red"><p class="text-xs" style="color: var(--text-muted);">Total Bills</p><p class="text-2xl font-bold text-red-500 mt-1">{{ $company->currency_symbol }} {{ number_format($totalBills,2) }}</p></div>
        <div class="stat-card stat-card-orange"><p class="text-xs" style="color: var(--text-muted);">Total Expenses</p><p class="text-2xl font-bold text-amber-500 mt-1">{{ $company->currency_symbol }} {{ number_format($totalExpenses,2) }}</p></div>
    </div>
    <div class="card overflow-x-auto mb-4">
        <div class="px-5 py-3 border-b font-semibold text-sm" style="border-color: var(--border-color); color: var(--text-primary);">Purchase Bills</div>
        <table class="data-table"><thead><tr><th>Bill#</th><th>Vendor</th><th>Date</th><th>Total</th><th>Due</th><th>Status</th></tr></thead>
        <tbody>@forelse($bills as $b)<tr><td>{{ $b->bill_no }}</td><td>{{ $b->vendor->contact_name??'-' }}</td><td>{{ $b->bill_date->format('d M Y') }}</td><td>{{ $company->currency_symbol }} {{ number_format($b->grand_total,2) }}</td><td class="{{ $b->due_amount>0?'text-red-500':'' }}">{{ $company->currency_symbol }} {{ number_format($b->due_amount,2) }}</td><td><span class="badge badge-gray">{{ ucfirst($b->status) }}</span></td></tr>@empty<tr><td colspan="6" class="text-center py-4" style="color: var(--text-muted);">No bills.</td></tr>@endforelse</tbody>
        </table>
    </div>
    <div class="card overflow-x-auto">
        <div class="px-5 py-3 border-b font-semibold text-sm" style="border-color: var(--border-color); color: var(--text-primary);">Expenses</div>
        <table class="data-table"><thead><tr><th>Expense#</th><th>Category</th><th>Date</th><th>Amount</th></tr></thead>
        <tbody>@forelse($expenses as $e)<tr><td>{{ $e->expense_no }}</td><td>{{ $e->category->name??'-' }}</td><td>{{ $e->date->format('d M Y') }}</td><td class="text-amber-500 font-semibold">{{ $company->currency_symbol }} {{ number_format($e->amount,2) }}</td></tr>@empty<tr><td colspan="4" class="text-center py-4" style="color: var(--text-muted);">No expenses.</td></tr>@endforelse</tbody>
        </table>
    </div>
</div>
