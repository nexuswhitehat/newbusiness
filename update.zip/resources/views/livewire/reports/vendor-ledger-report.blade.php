<div>
    <div class="flex items-center gap-3 mb-6">
        <a href="{{ route('reports.index', $company->slug) }}" class="btn btn-ghost btn-sm"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg></a>
        <h1 class="text-2xl font-bold" style="color: var(--text-primary);">Vendor Ledger</h1>
    </div>
    <div class="card p-4 mb-5"><div class="flex flex-wrap gap-3"><div class="flex-1"><label class="form-label">Vendor</label><select wire:model.live="vendor_id" class="form-select"><option value="">Select vendor...</option>@foreach($vendors as $v)<option value="{{ $v->id }}">{{ $v->contact_name }}</option>@endforeach</select></div><div><label class="form-label">From</label><input wire:model.live="from" type="date" class="form-input w-auto"></div><div><label class="form-label">To</label><input wire:model.live="to" type="date" class="form-input w-auto"></div></div></div>
    @if($vendor)
    <div class="card p-4 mb-4 flex justify-between items-center"><div><p class="font-semibold" style="color: var(--text-primary);">{{ $vendor->contact_name }}</p></div><div><p class="text-xs" style="color: var(--text-muted);">Balance</p><p class="text-xl font-bold text-red-500">{{ $company->currency_symbol }} {{ number_format($vendor->current_balance??0,2) }}</p></div></div>
    <div class="card overflow-x-auto">
        <table class="data-table"><thead><tr><th>Date</th><th>Reference</th><th>Type</th><th class="text-right">Debit</th><th class="text-right">Credit</th><th class="text-right">Balance</th></tr></thead>
        <tbody>@forelse($ledger as $entry)<tr><td>{{ $entry->date->format('d M Y') }}</td><td class="font-mono text-xs">{{ $entry->reference??'-' }}</td><td><span class="badge badge-gray">{{ ucfirst(str_replace('_',' ',$entry->type)) }}</span></td><td class="text-right {{ $entry->debit>0?'text-red-500':'' }}">{{ $entry->debit>0?$company->currency_symbol.' '.number_format($entry->debit,2):'-' }}</td><td class="text-right {{ $entry->credit>0?'text-emerald-500':'' }}">{{ $entry->credit>0?$company->currency_symbol.' '.number_format($entry->credit,2):'-' }}</td><td class="text-right font-semibold">{{ $company->currency_symbol }} {{ number_format($entry->balance,2) }}</td></tr>@empty<tr><td colspan="6" class="text-center py-8" style="color: var(--text-muted);">No entries.</td></tr>@endforelse</tbody>
        </table>
    </div>
    @else<div class="card p-12 text-center" style="color: var(--text-muted);"><p>Select a vendor to view their ledger.</p></div>@endif
</div>
