<div>
    <div class="mb-6"><h1 class="text-2xl font-bold" style="color: var(--text-primary);">Reports</h1><p class="text-sm mt-1" style="color: var(--text-muted);">Business intelligence and analytics</p></div>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        @php $reports = [
            ['title'=>'Sales Report','desc'=>'Revenue, invoices, and customer sales analysis','icon'=>'📊','route'=>'reports.sales','color'=>'from-indigo-500/20 to-purple-500/20','border'=>'border-indigo-500/30'],
            ['title'=>'Purchase Report','desc'=>'Bills, expenses, and vendor purchases','icon'=>'🛒','route'=>'reports.purchase','color'=>'from-blue-500/20 to-cyan-500/20','border'=>'border-blue-500/30'],
            ['title'=>'Profit & Loss','desc'=>'Revenue vs expenses, gross and net profit','icon'=>'💹','route'=>'reports.profit','color'=>'from-emerald-500/20 to-green-500/20','border'=>'border-emerald-500/30'],
            ['title'=>'Stock Report','desc'=>'Current inventory levels and valuation','icon'=>'📦','route'=>'reports.stock','color'=>'from-orange-500/20 to-amber-500/20','border'=>'border-orange-500/30'],
            ['title'=>'Customer Ledger','desc'=>'Customer account statement and history','icon'=>'👤','route'=>'reports.customer-ledger','color'=>'from-pink-500/20 to-rose-500/20','border'=>'border-pink-500/30'],
            ['title'=>'Vendor Ledger','desc'=>'Vendor account statement and history','icon'=>'🏢','route'=>'reports.vendor-ledger','color'=>'from-violet-500/20 to-purple-500/20','border'=>'border-violet-500/30'],
        ]; @endphp
        @foreach($reports as $r)
        <a href="{{ route($r['route'], $company->slug) }}" class="card p-5 hover:scale-105 transition-transform cursor-pointer border {{ $r['border'] }}">
            <div class="w-12 h-12 rounded-xl bg-gradient-to-br {{ $r['color'] }} flex items-center justify-center text-2xl mb-4">{{ $r['icon'] }}</div>
            <h3 class="font-semibold" style="color: var(--text-primary);">{{ $r['title'] }}</h3>
            <p class="text-sm mt-1" style="color: var(--text-muted);">{{ $r['desc'] }}</p>
        </a>
        @endforeach
    </div>
</div>
