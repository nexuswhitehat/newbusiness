<div>
    <div class="flex items-center gap-3 mb-6">
        <a href="{{ route('reports.index', $company->slug) }}" class="btn btn-ghost btn-sm"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg></a>
        <h1 class="text-2xl font-bold" style="color: var(--text-primary);">Profit & Loss Statement</h1>
    </div>
    <div class="card p-4 mb-5"><div class="flex gap-3"><div><label class="form-label">From</label><input wire:model.live="from" type="date" class="form-input w-auto"></div><div><label class="form-label">To</label><input wire:model.live="to" type="date" class="form-input w-auto"></div></div></div>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div class="card p-6">
            <h3 class="font-semibold mb-5 pb-2 border-b" style="color: var(--text-primary); border-color: var(--border-color);">P&L Summary</h3>
            <div class="space-y-4">
                <div class="flex justify-between items-center"><span style="color: var(--text-secondary);">Total Revenue</span><span class="text-lg font-bold text-emerald-500">{{ $company->currency_symbol }} {{ number_format($revenue,2) }}</span></div>
                <div class="flex justify-between items-center"><span style="color: var(--text-secondary);">Cost of Purchases</span><span class="text-lg font-semibold text-red-500">- {{ $company->currency_symbol }} {{ number_format($purchases,2) }}</span></div>
                <div class="flex justify-between items-center border-t pt-3" style="border-color: var(--border-color);"><span class="font-semibold" style="color: var(--text-primary);">Gross Profit</span><span class="text-xl font-bold {{ $grossProfit>=0?'text-emerald-500':'text-red-500' }}">{{ $company->currency_symbol }} {{ number_format($grossProfit,2) }}</span></div>
                <div class="flex justify-between items-center"><span style="color: var(--text-secondary);">Operating Expenses</span><span class="text-lg font-semibold text-red-500">- {{ $company->currency_symbol }} {{ number_format($expenses,2) }}</span></div>
                <div class="flex justify-between items-center border-t pt-3" style="border-color: var(--border-color);"><span class="font-bold text-lg" style="color: var(--text-primary);">Net Profit</span><span class="text-2xl font-black {{ $netProfit>=0?'text-emerald-500':'text-red-500' }}">{{ $company->currency_symbol }} {{ number_format($netProfit,2) }}</span></div>
            </div>
        </div>
        <div class="card p-6">
            <h3 class="font-semibold mb-5 pb-2 border-b" style="color: var(--text-primary); border-color: var(--border-color);">Profit Margin</h3>
            @php $margin = $revenue > 0 ? ($netProfit / $revenue) * 100 : 0; @endphp
            <div class="text-center py-8">
                <p class="text-6xl font-black {{ $margin>=0?'text-emerald-500':'text-red-500' }}">{{ number_format($margin, 1) }}%</p>
                <p class="text-sm mt-3" style="color: var(--text-muted);">Net Profit Margin</p>
            </div>
            <div class="bg-gray-200 dark:bg-slate-700 rounded-full h-3 mt-4">
                <div class="h-3 rounded-full {{ $margin>=0?'bg-emerald-500':'bg-red-500' }}" style="width: {{ min(abs($margin), 100) }}%"></div>
            </div>
        </div>
    </div>
</div>
