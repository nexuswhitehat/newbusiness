<div>
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold" style="color: var(--text-primary);">Product Categories</h1>
        <button wire:click="$set('showForm', true)" class="btn btn-primary">+ Add Category</button>
    </div>

    @if($showForm)
    <div class="card p-5 mb-5">
        <h3 class="text-sm font-semibold mb-4" style="color: var(--text-primary);">{{ $editingId ? 'Edit Category' : 'New Category' }}</h3>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div><label class="form-label">Category Name *</label><input wire:model="name" type="text" class="form-input">@error('name')<span class="text-red-500 text-xs">{{ $message }}</span>@enderror</div>
            <div><label class="form-label">Description</label><input wire:model="description" type="text" class="form-input"></div>
            <div class="flex items-end gap-2">
                <button wire:click="save" class="btn btn-primary">{{ $editingId ? 'Update' : 'Add' }}</button>
                <button wire:click="$set('showForm', false)" class="btn btn-secondary">Cancel</button>
            </div>
        </div>
    </div>
    @endif

    <div class="card overflow-x-auto">
        <table class="data-table">
            <thead><tr><th>Category Name</th><th>Description</th><th class="text-center">Products</th><th class="text-right">Actions</th></tr></thead>
            <tbody>
                @forelse($cats as $cat)
                <tr>
                    <td class="font-medium" style="color: var(--text-primary);">{{ $cat->name }}</td>
                    <td style="color: var(--text-muted);">{{ $cat->description ?? '-' }}</td>
                    <td class="text-center"><span class="badge badge-blue">{{ $cat->products_count }}</span></td>
                    <td class="text-right">
                        <div class="flex justify-end gap-1">
                            <button wire:click="startEdit({{ $cat->id }})" class="btn btn-ghost btn-xs">Edit</button>
                            <button wire:click="delete({{ $cat->id }})" class="btn btn-ghost btn-xs text-red-500">Delete</button>
                        </div>
                    </td>
                </tr>
                @empty
                <tr><td colspan="4" class="text-center py-8" style="color: var(--text-muted);">No categories yet. Add your first one!</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
