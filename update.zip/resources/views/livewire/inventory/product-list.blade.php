<div>
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
        <div>
            <h1 class="text-2xl font-bold" style="color: var(--text-primary);">Products</h1>
            <p class="text-sm mt-1" style="color: var(--text-muted);">Manage your product catalog and inventory</p>
        </div>
        <a href="{{ route('products.create', $company->slug) }}" class="btn btn-primary mt-3 sm:mt-0">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
            Add Product
        </a>
    </div>

    <div class="card p-4 mb-4">
        <div class="flex flex-wrap gap-3">
            <div class="flex-1 min-w-[200px]">
                <input wire:model.live.debounce.300ms="search" type="text" placeholder="Search by name, SKU, barcode..." class="form-input">
            </div>
            <select wire:model.live="category" class="form-select w-auto">
                <option value="">All Categories</option>
                @foreach($categories as $cat)
                <option value="{{ $cat->id }}">{{ $cat->name }}</option>
                @endforeach
            </select>
            <select wire:model.live="stockFilter" class="form-select w-auto">
                <option value="">All Stock</option>
                <option value="low">Low Stock</option>
                <option value="out">Out of Stock</option>
            </select>
        </div>
    </div>

    <div class="card overflow-x-auto">
        <table class="data-table">
            <thead>
                <tr>
                    <th>SKU</th>
                    <th>Product Name</th>
                    <th>Category</th>
                    <th>Type</th>
                    <th class="text-right">Cost</th>
                    <th class="text-right">Selling</th>
                    <th class="text-center">Stock</th>
                    <th>Status</th>
                    <th class="text-right">Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($products as $product)
                <tr>
                    <td class="font-mono text-xs text-indigo-400">{{ $product->sku }}</td>
                    <td>
                        <p class="font-medium" style="color: var(--text-primary);">{{ $product->name }}</p>
                        @if($product->barcode)<p class="text-xs" style="color: var(--text-muted);">📦 {{ $product->barcode }}</p>@endif
                    </td>
                    <td><span class="badge badge-gray">{{ $product->category->name ?? '-' }}</span></td>
                    <td><span class="badge badge-{{ $product->type=='service'?'indigo':'blue' }}">{{ ucfirst($product->type) }}</span></td>
                    <td class="text-right text-sm">{{ $company->currency_symbol }} {{ number_format($product->purchase_price, 2) }}</td>
                    <td class="text-right text-sm font-semibold" style="color: var(--text-primary);">{{ $company->currency_symbol }} {{ number_format($product->selling_price, 2) }}</td>
                    <td class="text-center">
                        @if($product->type === 'service')
                            <span class="text-xs" style="color: var(--text-muted);">N/A</span>
                        @else
                            <span class="font-semibold text-sm {{ $product->total_stock <= 0 ? 'text-red-500' : ($product->total_stock <= $product->minimum_stock ? 'text-amber-500' : 'text-emerald-500') }}">
                                {{ number_format($product->total_stock) }}
                                {{ $product->unit->short_name ?? '' }}
                            </span>
                            @if($product->total_stock <= 0)<span class="badge badge-red ml-1">Out</span>
                            @elseif($product->total_stock <= $product->minimum_stock)<span class="badge badge-orange ml-1">Low</span>@endif
                        @endif
                    </td>
                    <td><span class="badge badge-{{ $product->status=='active'?'green':'gray' }}">{{ ucfirst($product->status) }}</span></td>
                    <td class="text-right">
                        <div class="flex items-center justify-end gap-1">
                            <a href="{{ route('products.edit', [$company->slug, $product->id]) }}" class="btn btn-ghost btn-xs">Edit</a>
                            <button wire:click="confirmDelete({{ $product->id }})" class="btn btn-ghost btn-xs text-red-500">Del</button>
                        </div>
                    </td>
                </tr>
                @empty
                <tr><td colspan="9" class="text-center py-10" style="color: var(--text-muted);">No products found.</td></tr>
                @endforelse
            </tbody>
        </table>
        <div class="px-4 py-3 pagination-wrapper">{{ $products->links() }}</div>
    </div>

    @if($showDeleteModal)
    <div class="modal-backdrop" wire:click.self="$set('showDeleteModal', false)">
        <div class="modal-content max-w-sm p-6">
            <h3 class="text-lg font-semibold mb-2" style="color: var(--text-primary);">Delete Product?</h3>
            <p class="text-sm mb-5" style="color: var(--text-secondary);">This cannot be undone.</p>
            <div class="flex gap-3 justify-end">
                <button wire:click="$set('showDeleteModal', false)" class="btn btn-secondary">Cancel</button>
                <button wire:click="delete" class="btn btn-danger">Delete</button>
            </div>
        </div>
    </div>
    @endif
</div>
