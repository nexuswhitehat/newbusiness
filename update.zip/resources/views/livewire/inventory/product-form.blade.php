<div>
    <div class="flex items-center gap-3 mb-6">
        <a href="{{ route('products.index', $company->slug) }}" class="btn btn-ghost btn-sm"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg></a>
        <h1 class="text-2xl font-bold" style="color: var(--text-primary);">{{ $editing ? 'Edit Product' : 'Add Product' }}</h1>
    </div>
    <form wire:submit="save">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div class="lg:col-span-2 space-y-4">
                <div class="card p-5">
                    <h3 class="text-sm font-semibold mb-4" style="color: var(--text-primary);">Basic Information</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div class="md:col-span-2"><label class="form-label">Product Name *</label><input wire:model="name" type="text" class="form-input" placeholder="Enter product name">@error('name')<span class="text-red-500 text-xs">{{ $message }}</span>@enderror</div>
                        <div><label class="form-label">SKU</label><input wire:model="sku" type="text" class="form-input" placeholder="Auto-generated if empty"></div>
                        <div><label class="form-label">Barcode</label><input wire:model="barcode" type="text" class="form-input"></div>
                        <div><label class="form-label">Category</label><select wire:model="category_id" class="form-select"><option value="">Select...</option>@foreach($categories as $c)<option value="{{ $c->id }}">{{ $c->name }}</option>@endforeach</select></div>
                        <div><label class="form-label">Brand</label><select wire:model="brand_id" class="form-select"><option value="">Select...</option>@foreach($brands as $b)<option value="{{ $b->id }}">{{ $b->name }}</option>@endforeach</select></div>
                        <div><label class="form-label">Unit</label><select wire:model="unit_id" class="form-select"><option value="">Select...</option>@foreach($units as $u)<option value="{{ $u->id }}">{{ $u->name }} ({{ $u->short_name }})</option>@endforeach</select></div>
                        <div><label class="form-label">Type</label><select wire:model="type" class="form-select"><option value="product">Product</option><option value="service">Service</option></select></div>
                        <div><label class="form-label">Status</label><select wire:model="status" class="form-select"><option value="active">Active</option><option value="inactive">Inactive</option></select></div>
                    </div>
                    <div class="mt-4"><label class="form-label">Description</label><textarea wire:model="description" class="form-input" rows="3"></textarea></div>
                </div>
                <div class="card p-5">
                    <h3 class="text-sm font-semibold mb-4" style="color: var(--text-primary);">Pricing & Stock</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div><label class="form-label">Cost Price ({{ $company->currency_symbol }}) *</label><input wire:model="purchase_price" type="number" step="0.01" min="0" class="form-input">@error('purchase_price')<span class="text-red-500 text-xs">{{ $message }}</span>@enderror</div>
                        <div><label class="form-label">Selling Price ({{ $company->currency_symbol }}) *</label><input wire:model="selling_price" type="number" step="0.01" min="0" class="form-input">@error('selling_price')<span class="text-red-500 text-xs">{{ $message }}</span>@enderror</div>
                        <div><label class="form-label">Tax Rate %</label><input wire:model="tax" type="number" step="0.1" min="0" class="form-input"></div>
                        @if(!$editing || $type === 'product')
                        <div><label class="form-label">Opening Stock</label><input wire:model="stock_quantity" type="number" step="0.01" min="0" class="form-input" {{ $editing?'disabled':'' }}></div>
                        <div><label class="form-label">Alert Quantity</label><input wire:model="minimum_stock" type="number" step="0.01" min="0" class="form-input"></div>
                        @endif
                    </div>
                </div>
            </div>
            <div>
                <div class="card p-5">
                    <button type="submit" class="btn btn-primary w-full justify-center btn-lg">
                        <span wire:loading.remove wire:target="save">{{ $editing ? 'Update Product' : 'Add Product' }}</span>
                        <span wire:loading wire:target="save" class="flex items-center gap-2"><div class="spinner !w-4 !h-4 !border-white/30 !border-t-white"></div> Saving...</span>
                    </button>
                </div>
            </div>
        </div>
    </form>
</div>
