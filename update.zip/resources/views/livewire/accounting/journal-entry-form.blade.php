<div>
    <div class="flex items-center gap-3 mb-6">
        <a href="{{ route('journal-entries.index', $company->slug) }}" class="btn btn-ghost btn-sm"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg></a>
        <h1 class="text-2xl font-bold" style="color: var(--text-primary);">New Journal Entry</h1>
    </div>
    <form wire:submit="save">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div class="lg:col-span-2 space-y-4">
                <div class="card p-5">
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                        <div><label class="form-label">Date *</label><input wire:model="date" type="date" class="form-input"></div>
                        <div><label class="form-label">Reference</label><input wire:model="reference" type="text" class="form-input" placeholder="JV-001"></div>
                        <div><label class="form-label">Type</label><select wire:model="type" class="form-select"><option value="general">General</option><option value="opening">Opening</option><option value="adjustment">Adjustment</option></select></div>
                        <div class="md:col-span-3"><label class="form-label">Description</label><input wire:model="description" type="text" class="form-input" placeholder="Entry description"></div>
                    </div>
                    {{-- Lines --}}
                    <div class="flex items-center justify-between mb-3">
                        <h3 class="text-sm font-semibold" style="color: var(--text-primary);">Debit / Credit Lines</h3>
                        <button type="button" wire:click="addLine" class="btn btn-secondary btn-sm">+ Add Line</button>
                    </div>
                    <div class="hidden md:grid grid-cols-12 gap-2 mb-2 px-1 text-xs font-semibold" style="color: var(--text-muted);">
                        <div class="col-span-4">Account</div><div class="col-span-3">Description</div><div class="col-span-2 text-right">Debit</div><div class="col-span-2 text-right">Credit</div><div class="col-span-1"></div>
                    </div>
                    @foreach($lines as $i => $line)
                    <div class="grid grid-cols-12 gap-2 items-start p-2 rounded-lg mb-2" style="background: var(--bg-hover);">
                        <div class="col-span-12 md:col-span-4"><select wire:model.live="lines.{{ $i }}.account_id" class="form-select text-xs"><option value="">Select account...</option>@foreach($accounts->groupBy('account_type') as $type => $accs)<optgroup label="{{ ucfirst($type) }}">@foreach($accs as $a)<option value="{{ $a->id }}">{{ $a->account_code }} — {{ $a->account_name }}</option>@endforeach</optgroup>@endforeach</select>@error("lines.$i.account_id")<span class="text-red-500 text-xs">{{ $message }}</span>@enderror</div>
                        <div class="col-span-12 md:col-span-3"><input wire:model.live="lines.{{ $i }}.description" type="text" class="form-input text-xs" placeholder="Narration"></div>
                        <div class="col-span-5 md:col-span-2"><input wire:model.live="lines.{{ $i }}.debit" type="number" step="0.01" min="0" class="form-input text-xs text-right" placeholder="0.00"></div>
                        <div class="col-span-5 md:col-span-2"><input wire:model.live="lines.{{ $i }}.credit" type="number" step="0.01" min="0" class="form-input text-xs text-right" placeholder="0.00"></div>
                        <div class="col-span-2 md:col-span-1 flex justify-end"><button type="button" wire:click="removeLine({{ $i }})" class="btn btn-ghost btn-xs text-red-500">✕</button></div>
                    </div>
                    @endforeach
                    @error('lines')<p class="text-red-500 text-xs mt-2">{{ $message }}</p>@enderror
                </div>
            </div>
            <div class="space-y-4">
                <div class="card p-5">
                    <h3 class="text-sm font-semibold mb-4" style="color: var(--text-primary);">Totals</h3>
                    <div class="space-y-3">
                        <div class="flex justify-between text-sm"><span style="color: var(--text-muted);">Total Debit</span><span class="font-semibold text-emerald-500">{{ $company->currency_symbol }} {{ number_format($totalDebit, 2) }}</span></div>
                        <div class="flex justify-between text-sm"><span style="color: var(--text-muted);">Total Credit</span><span class="font-semibold text-red-500">{{ $company->currency_symbol }} {{ number_format($totalCredit, 2) }}</span></div>
                        <div class="flex justify-between text-sm border-t pt-3" style="border-color: var(--border-color);">
                            <span style="color: var(--text-muted);">Difference</span>
                            <span class="font-bold {{ $balanced ? 'text-emerald-500' : 'text-red-500' }}">
                                {{ $company->currency_symbol }} {{ number_format(abs($totalDebit - $totalCredit), 2) }}
                            </span>
                        </div>
                        @if($balanced)<div class="flex items-center gap-2 text-xs text-emerald-500 mt-2"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg> Entry is balanced</div>@else<div class="text-xs text-amber-500 mt-2">⚠ Entry must be balanced before posting</div>@endif
                    </div>
                </div>
                <div class="card p-5">
                    <button type="submit" class="btn btn-primary w-full justify-center btn-lg" {{ !$balanced ? 'disabled' : '' }}>
                        <span wire:loading.remove wire:target="save">Post Entry</span>
                        <span wire:loading wire:target="save" class="flex items-center gap-2"><div class="spinner !w-4 !h-4 !border-white/30 !border-t-white"></div></span>
                    </button>
                </div>
            </div>
        </div>
    </form>
</div>
