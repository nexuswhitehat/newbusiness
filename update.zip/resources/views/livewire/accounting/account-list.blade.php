<div>
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold" style="color: var(--text-primary);">Chart of Accounts</h1>
        <a href="{{ route('journal-entries.create', $company->slug) }}" class="btn btn-secondary btn-sm">+ Journal Entry</a>
    </div>
    <div class="card p-4 mb-4">
        <div class="flex flex-wrap gap-3">
            <div class="flex-1"><input wire:model.live.debounce.300ms="search" type="text" placeholder="Search accounts..." class="form-input"></div>
            <select wire:model.live="type" class="form-select w-auto">
                <option value="">All Types</option>
                <option value="asset">Assets</option>
                <option value="liability">Liabilities</option>
                <option value="equity">Equity</option>
                <option value="income">Income</option>
                <option value="expense">Expense</option>
            </select>
        </div>
    </div>
    <div class="card overflow-x-auto">
        <table class="data-table">
            <thead><tr><th>Code</th><th>Account Name</th><th>Type</th><th>Balance</th><th>Status</th></tr></thead>
            <tbody>
                @forelse($accounts as $acc)
                <tr>
                    <td class="font-mono text-xs text-indigo-400">{{ $acc->account_code }}</td>
                    <td>
                        <p class="font-semibold" style="color: var(--text-primary);">{{ $acc->account_name }}</p>
                        @foreach($acc->children as $child)
                        <div class="ml-4 flex gap-2 text-xs py-1" style="color: var(--text-secondary);">
                            <span class="font-mono text-indigo-300">{{ $child->account_code }}</span>
                            <span>{{ $child->account_name }}</span>
                        </div>
                        @endforeach
                    </td>
                    <td><span class="badge badge-{{ ['asset'=>'blue','liability'=>'red','equity'=>'purple','income'=>'green','expense'=>'orange'][$acc->account_type]??'gray' }}">{{ ucfirst($acc->account_type) }}</span></td>
                    <td class="font-semibold" style="color: var(--text-primary);">{{ $company->currency_symbol }} {{ number_format($acc->balance ?? 0, 2) }}</td>
                    <td><span class="badge badge-{{ $acc->is_active ? 'green' : 'gray' }}">{{ $acc->is_active ? 'Active' : 'Inactive' }}</span></td>
                </tr>
                @empty
                <tr><td colspan="5" class="text-center py-8" style="color: var(--text-muted);">No accounts. Run migrations to seed chart of accounts.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
