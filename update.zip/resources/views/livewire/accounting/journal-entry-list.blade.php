<div>
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold" style="color: var(--text-primary);">Journal Entries</h1>
        <a href="{{ route('journal-entries.create', $company->slug) }}" class="btn btn-primary">+ New Entry</a>
    </div>
    <div class="card p-4 mb-4"><input wire:model.live.debounce.300ms="search" type="text" placeholder="Search by reference or description..." class="form-input"></div>
    <div class="card overflow-x-auto">
        <table class="data-table">
            <thead><tr><th>Date</th><th>Reference</th><th>Description</th><th>Type</th><th class="text-right">Debit</th><th>Status</th></tr></thead>
            <tbody>
                @forelse($entries as $entry)
                <tr>
                    <td>{{ $entry->date->format('d M Y') }}</td>
                    <td class="font-mono text-xs text-indigo-400">{{ $entry->reference ?? '-' }}</td>
                    <td style="color: var(--text-primary);">{{ $entry->description }}</td>
                    <td><span class="badge badge-gray">{{ ucfirst($entry->type) }}</span></td>
                    <td class="text-right font-semibold">{{ $company->currency_symbol }} {{ number_format($entry->total_debit, 2) }}</td>
                    <td><span class="badge badge-{{ $entry->status === 'posted' ? 'green' : 'orange' }}">{{ ucfirst($entry->status) }}</span></td>
                </tr>
                @empty
                <tr><td colspan="6" class="text-center py-8" style="color: var(--text-muted);">No journal entries yet.</td></tr>
                @endforelse
            </tbody>
        </table>
        <div class="px-4 py-3 pagination-wrapper">{{ $entries->links() }}</div>
    </div>
</div>
