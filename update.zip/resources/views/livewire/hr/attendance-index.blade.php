<div>
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
        <div>
            <h1 class="text-2xl font-bold" style="color: var(--text-primary);">Attendance</h1>
            <p class="text-sm mt-1" style="color: var(--text-muted);">Mark daily attendance for all employees</p>
        </div>
        <div class="mt-3 sm:mt-0 flex items-center gap-3">
            <input wire:model.live="date" type="date" class="form-input w-auto">
            <button wire:click="save" class="btn btn-success">Save Attendance</button>
        </div>
    </div>

    {{-- Summary --}}
    <div class="grid grid-cols-3 gap-4 mb-5">
        <div class="stat-card stat-card-green text-center"><p class="text-2xl font-bold text-emerald-500">{{ $present }}</p><p class="text-xs mt-1" style="color: var(--text-muted);">Present</p></div>
        <div class="stat-card stat-card-red text-center"><p class="text-2xl font-bold text-red-500">{{ $absent }}</p><p class="text-xs mt-1" style="color: var(--text-muted);">Absent</p></div>
        <div class="stat-card stat-card-orange text-center"><p class="text-2xl font-bold text-amber-500">{{ $leave }}</p><p class="text-xs mt-1" style="color: var(--text-muted);">On Leave</p></div>
    </div>

    <div class="card overflow-x-auto">
        <table class="data-table">
            <thead><tr><th>Code</th><th>Name</th><th>Designation</th><th>Status</th></tr></thead>
            <tbody>
                @forelse($attendanceData as $i => $emp)
                <tr>
                    <td class="font-mono text-xs text-indigo-400">{{ $emp['code'] }}</td>
                    <td class="font-medium" style="color: var(--text-primary);">{{ $emp['name'] }}</td>
                    <td style="color: var(--text-muted);">{{ $emp['designation'] }}</td>
                    <td>
                        <div class="flex gap-2">
                            @foreach(['present'=>'Present','absent'=>'Absent','leave'=>'Leave','half_day'=>'Half Day'] as $val => $label)
                            <label class="flex items-center gap-1 cursor-pointer">
                                <input wire:model.live="attendanceData.{{ $i }}.status" type="radio" value="{{ $val }}" class="text-indigo-500">
                                <span class="text-xs badge {{ ['present'=>'badge-green','absent'=>'badge-red','leave'=>'badge-orange','half_day'=>'badge-blue'][$val] }}">{{ $label }}</span>
                            </label>
                            @endforeach
                        </div>
                    </td>
                </tr>
                @empty
                <tr><td colspan="4" class="text-center py-8" style="color: var(--text-muted);">No active employees found.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
