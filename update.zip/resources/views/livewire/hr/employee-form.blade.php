<div>
    <div class="flex items-center gap-3 mb-6">
        <a href="{{ route('employees.index', $company->slug) }}" class="btn btn-ghost btn-sm"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg></a>
        <h1 class="text-2xl font-bold" style="color: var(--text-primary);">{{ $editing ? 'Edit Employee' : 'Add Employee' }}</h1>
    </div>
    <form wire:submit="save">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div class="lg:col-span-2">
                <div class="card p-5">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div><label class="form-label">Full Name *</label><input wire:model="name" type="text" class="form-input">@error('name')<span class="text-red-500 text-xs">{{ $message }}</span>@enderror</div>
                        <div><label class="form-label">Email</label><input wire:model="email" type="email" class="form-input"></div>
                        <div><label class="form-label">Phone</label><input wire:model="phone" type="text" class="form-input"></div>
                        <div><label class="form-label">Designation</label><input wire:model="designation" type="text" class="form-input"></div>
                        <div><label class="form-label">Department</label><input wire:model="department" type="text" class="form-input"></div>
                        <div><label class="form-label">Join Date *</label><input wire:model="joining_date" type="date" class="form-input"></div>
                        <div><label class="form-label">Basic Salary ({{ $company->currency_symbol }}) *</label><input wire:model="salary" type="number" step="0.01" min="0.01" class="form-input">@error('basic_salary')<span class="text-red-500 text-xs">{{ $message }}</span>@enderror</div>
                        <div><label class="form-label">Status</label><select wire:model="status" class="form-select"><option value="active">Active</option><option value="inactive">Inactive</option></select></div>
                    </div>
                    <div class="mt-4"><label class="form-label">Address</label><textarea wire:model="address" class="form-input" rows="2"></textarea></div>
                </div>
            </div>
            <div><div class="card p-5"><button type="submit" class="btn btn-primary w-full justify-center btn-lg"><span wire:loading.remove wire:target="save">{{ $editing ? 'Update' : 'Add Employee' }}</span><span wire:loading wire:target="save"><div class="spinner !w-4 !h-4 !border-white/30 !border-t-white"></div></span></button></div></div>
        </div>
    </form>
</div>
