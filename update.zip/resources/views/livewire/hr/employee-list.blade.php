<div>
    <div class="flex items-center justify-between mb-6">
        <div><h1 class="text-2xl font-bold" style="color: var(--text-primary);">Employees</h1></div>
        <a href="{{ route('employees.create', $company->slug) }}" class="btn btn-primary">+ Add Employee</a>
    </div>
    <div class="card p-4 mb-4"><div class="flex gap-3"><div class="flex-1"><input wire:model.live.debounce.300ms="search" type="text" placeholder="Search employees..." class="form-input"></div><select wire:model.live="status" class="form-select w-36"><option value="">All</option><option value="active">Active</option><option value="inactive">Inactive</option></select></div></div>
    <div class="card overflow-x-auto">
        <table class="data-table">
            <thead><tr><th>Code</th><th>Name</th><th>Designation</th><th>Department</th><th>Join Date</th><th>Salary</th><th>Status</th><th class="text-right">Actions</th></tr></thead>
            <tbody>
                @forelse($employees as $emp)
                <tr>
                    <td class="font-mono text-xs text-indigo-400">{{ $emp->employee_code }}</td>
                    <td>
                        <p class="font-medium" style="color: var(--text-primary);">{{ $emp->name }}</p>
                        <p class="text-xs" style="color: var(--text-muted);">{{ $emp->email }}</p>
                    </td>
                    <td>{{ $emp->designation ?? '-' }}</td>
                    <td>{{ $emp->department ?? '-' }}</td>
                    <td>{{ $emp->joining_date->format('d M Y') }}</td>
                    <td class="font-semibold">{{ $company->currency_symbol }} {{ number_format($emp->salary, 2) }}</td>
                    <td><span class="badge badge-{{ $emp->status==='active'?'green':'gray' }}">{{ ucfirst($emp->status) }}</span></td>
                    <td class="text-right">
                        <div class="flex justify-end gap-1">
                            <a href="{{ route('employees.edit', [$company->slug, $emp->id]) }}" class="btn btn-ghost btn-xs">Edit</a>
                            @if(auth('admin')->user()->isSuperAdmin())
                                <button wire:click="delete({{ $emp->id }})" wire:confirm="Are you sure you want to delete this employee?" class="btn btn-ghost btn-xs text-red-500 hover:text-red-700">Delete</button>
                            @endif
                        </div>
                    </td>
                </tr>
                @empty
                <tr><td colspan="8" class="text-center py-10" style="color: var(--text-muted);">No employees found.</td></tr>
                @endforelse
            </tbody>
        </table>
        <div class="px-4 py-3 pagination-wrapper">{{ $employees->links() }}</div>
    </div>
</div>
