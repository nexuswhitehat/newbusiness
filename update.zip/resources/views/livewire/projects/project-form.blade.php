<div>
    <div class="flex items-center gap-3 mb-6">
        <a href="{{ route('projects.index', $company->slug) }}" class="btn btn-ghost btn-sm"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg></a>
        <h1 class="text-2xl font-bold" style="color: var(--text-primary);">{{ $editing ? 'Edit Project' : 'New Project' }}</h1>
    </div>
    <form wire:submit="save">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div class="lg:col-span-2">
                <div class="card p-5">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div class="md:col-span-2"><label class="form-label">Project Name *</label><input wire:model="name" type="text" class="form-input">@error('name')<span class="text-red-500 text-xs">{{ $message }}</span>@enderror</div>
                        <div><label class="form-label">Customer</label><select wire:model="customer_id" class="form-select"><option value="">Select...</option>@foreach($customers as $c)<option value="{{ $c->id }}">{{ $c->customer_name }}</option>@endforeach</select></div>
                        <div><label class="form-label">Status</label><select wire:model="status" class="form-select"><option value="active">Active</option><option value="on_hold">On Hold</option><option value="completed">Completed</option><option value="cancelled">Cancelled</option></select></div>
                        <div><label class="form-label">Start Date *</label><input wire:model="start_date" type="date" class="form-input"></div>
                        <div><label class="form-label">End Date</label><input wire:model="end_date" type="date" class="form-input"></div>
                        <div><label class="form-label">Budget ({{ $company->currency_symbol }})</label><input wire:model="budget" type="number" step="0.01" min="0" class="form-input"></div>
                    </div>
                    <div class="mt-4"><label class="form-label">Description</label><textarea wire:model="description" class="form-input" rows="3"></textarea></div>
                </div>
            </div>
            <div><div class="card p-5"><button type="submit" class="btn btn-primary w-full justify-center btn-lg"><span wire:loading.remove wire:target="save">{{ $editing ? 'Update' : 'Create Project' }}</span><span wire:loading wire:target="save"><div class="spinner !w-4 !h-4 !border-white/30 !border-t-white"></div></span></button></div></div>
        </div>
    </form>
</div>
