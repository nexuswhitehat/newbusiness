<div>
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold" style="color: var(--text-primary);">Projects</h1>
        <a href="{{ route('projects.create', $company->slug) }}" class="btn btn-primary">+ New Project</a>
    </div>
    <div class="card p-4 mb-4"><div class="flex gap-3"><div class="flex-1"><input wire:model.live.debounce.300ms="search" type="text" placeholder="Search projects..." class="form-input"></div><select wire:model.live="status" class="form-select w-40"><option value="">All Status</option><option value="active">Active</option><option value="completed">Completed</option><option value="on_hold">On Hold</option><option value="cancelled">Cancelled</option></select></div></div>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        @forelse($projects as $proj)
        @php $sc=['active'=>'badge-green','completed'=>'badge-blue','on_hold'=>'badge-orange','cancelled'=>'badge-red']; @endphp
        <div class="card p-5">
            <div class="flex items-start justify-between mb-3">
                <h3 class="font-semibold text-base" style="color: var(--text-primary);">{{ $proj->name }}</h3>
                <span class="badge {{ $sc[$proj->status]??'badge-gray' }}">{{ ucfirst(str_replace('_',' ',$proj->status)) }}</span>
            </div>
            @if($proj->customer)<p class="text-xs mb-2" style="color: var(--text-muted);">👤 {{ $proj->customer->customer_name }}</p>@endif
            <div class="grid grid-cols-2 gap-2 text-xs mt-3">
                <div><span style="color: var(--text-muted);">Start: </span><span style="color: var(--text-secondary);">{{ $proj->start_date->format('d M Y') }}</span></div>
                @if($proj->end_date)<div><span style="color: var(--text-muted);">End: </span><span style="color: var(--text-secondary);">{{ $proj->end_date->format('d M Y') }}</span></div>@endif
                @if($proj->budget)<div class="col-span-2"><span style="color: var(--text-muted);">Budget: </span><span class="font-semibold" style="color: var(--text-primary);">{{ $company->currency_symbol }} {{ number_format($proj->budget) }}</span></div>@endif
            </div>
            <div class="flex gap-2 mt-4 pt-4 border-t" style="border-color: var(--border-color);">
                <a href="{{ route('projects.show', [$company->slug, $proj->id]) }}" class="btn btn-ghost btn-xs flex-1 justify-center">View</a>
                <a href="{{ route('projects.edit', [$company->slug, $proj->id]) }}" class="btn btn-ghost btn-xs">Edit</a>
            </div>
        </div>
        @empty
        <div class="col-span-full text-center py-12 card" style="color: var(--text-muted);">No projects found.</div>
        @endforelse
    </div>
    <div class="mt-4">{{ $projects->links() }}</div>
</div>
