<div>
    <div class="flex items-center gap-3 mb-6">
        <a href="{{ route('projects.index', $company->slug) }}" class="btn btn-ghost btn-sm"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg></a>
        <div><h1 class="text-2xl font-bold" style="color: var(--text-primary);">{{ $project->name }}</h1>
        <p class="text-sm" style="color: var(--text-muted);">{{ $project->customer->customer_name ?? '' }}</p></div>
        <a href="{{ route('projects.edit', [$company->slug, $project->id]) }}" class="btn btn-secondary btn-sm ml-auto">Edit</a>
    </div>
    {{-- Task Board --}}
    <div class="card p-5 mb-4">
        <h3 class="text-sm font-semibold mb-4" style="color: var(--text-primary);">Add Task</h3>
        <div class="flex flex-wrap gap-3">
            <div class="flex-1"><input wire:model="taskTitle" type="text" class="form-input" placeholder="Task title *">@error('taskTitle')<span class="text-red-500 text-xs">{{ $message }}</span>@enderror</div>
            <input wire:model="taskDueDate" type="date" class="form-input w-auto">
            <select wire:model="taskAssignedTo" class="form-select w-auto"><option value="">Assign to...</option>@foreach($admins as $a)<option value="{{ $a->id }}">{{ $a->name }}</option>@endforeach</select>
            <button wire:click="addTask" type="button" class="btn btn-primary">Add Task</button>
        </div>
    </div>
    <div class="card overflow-x-auto">
        <table class="data-table">
            <thead><tr><th>Task</th><th>Assigned To</th><th>Due Date</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
                @forelse($project->tasks as $task)
                <tr class="{{ $task->status==='done'?'opacity-60':'' }}">
                    <td class="{{ $task->status==='done'?'line-through':'' }}" style="color: var(--text-primary);">{{ $task->title }}</td>
                    <td style="color: var(--text-muted);">{{ $task->assignedTo->name ?? '-' }}</td>
                    <td>{{ $task->due_date?->format('d M Y') ?? '-' }}</td>
                    <td><span class="badge badge-{{ $task->status==='done'?'green':($task->status==='in_progress'?'blue':'gray') }}">{{ ucfirst(str_replace('_',' ',$task->status)) }}</span></td>
                    <td><button wire:click="toggleTask({{ $task->id }})" class="btn btn-ghost btn-xs">{{ $task->status==='done'?'Reopen':'Done' }}</button></td>
                </tr>
                @empty
                <tr><td colspan="5" class="text-center py-8" style="color: var(--text-muted);">No tasks yet. Add your first task above!</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
