<div>
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
        <div>
            <h1 class="text-2xl font-bold" style="color: var(--text-primary);">Customers</h1>
            <p class="text-sm mt-1" style="color: var(--text-muted);">Manage your customer database</p>
        </div>
        <a href="{{ route('customers.create', $company->slug) }}" class="btn btn-primary mt-3 sm:mt-0">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
            Add Customer
        </a>
    </div>

    {{-- Filters --}}
    <div class="card p-4 mb-4">
        <div class="flex flex-col sm:flex-row gap-3">
            <div class="flex-1">
                <input wire:model.live.debounce.300ms="search" type="text" placeholder="Search customers..." class="form-input">
            </div>
            <select wire:model.live="status" class="form-select sm:w-40">
                <option value="">All Status</option>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
                <option value="blocked">Blocked</option>
            </select>
        </div>
    </div>

    {{-- Table --}}
    <div class="card overflow-x-auto">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Code</th>
                    <th>Customer Name</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Balance</th>
                    <th>Status</th>
                    <th class="text-right">Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($customers as $customer)
                <tr>
                    <td class="font-mono text-xs">{{ $customer->customer_code }}</td>
                    <td>
                        <a href="{{ route('customers.show', [$company->slug, $customer->id]) }}" class="font-medium hover:text-indigo-500 transition" style="color: var(--text-primary);">{{ $customer->customer_name }}</a>
                        @if($customer->company_name)
                            <p class="text-xs" style="color: var(--text-muted);">{{ $customer->company_name }}</p>
                        @endif
                    </td>
                    <td>{{ $customer->phone ?? '-' }}</td>
                    <td>{{ $customer->email ?? '-' }}</td>
                    <td class="font-semibold {{ $customer->current_balance > 0 ? 'text-red-500' : 'text-emerald-500' }}">
                        {{ $company->currency_symbol }} {{ number_format(abs($customer->current_balance), 2) }}
                    </td>
                    <td><span class="badge badge-{{ $customer->status == 'active' ? 'green' : ($customer->status == 'blocked' ? 'red' : 'gray') }}">{{ ucfirst($customer->status) }}</span></td>
                    <td class="text-right">
                        <div class="flex items-center justify-end gap-1">
                            <a href="{{ route('customers.show', [$company->slug, $customer->id]) }}" class="btn btn-ghost btn-xs">View</a>
                            <a href="{{ route('customers.edit', [$company->slug, $customer->id]) }}" class="btn btn-ghost btn-xs">Edit</a>
                            <button wire:click="confirmDelete({{ $customer->id }})" class="btn btn-ghost btn-xs text-red-500">Delete</button>
                        </div>
                    </td>
                </tr>
                @empty
                <tr><td colspan="7" class="text-center py-8" style="color: var(--text-muted);">No customers found. Create your first customer!</td></tr>
                @endforelse
            </tbody>
        </table>
        <div class="px-4 py-3 pagination-wrapper">{{ $customers->links() }}</div>
    </div>

    {{-- Delete Modal --}}
    @if($showDeleteModal)
    <div class="modal-backdrop" wire:click.self="$set('showDeleteModal', false)">
        <div class="modal-content max-w-sm p-6">
            <h3 class="text-lg font-semibold mb-2" style="color: var(--text-primary);">Delete Customer?</h3>
            <p class="text-sm mb-5" style="color: var(--text-secondary);">This action cannot be undone. All related data will be removed.</p>
            <div class="flex gap-3 justify-end">
                <button wire:click="$set('showDeleteModal', false)" class="btn btn-secondary">Cancel</button>
                <button wire:click="delete" class="btn btn-danger">Delete</button>
            </div>
        </div>
    </div>
    @endif
</div>
