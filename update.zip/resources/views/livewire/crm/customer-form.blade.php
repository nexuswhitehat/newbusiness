<div>
    <div class="flex items-center gap-3 mb-6">
        <a href="{{ route('customers.index', $company->slug) }}" class="btn btn-ghost btn-sm">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
        </a>
        <h1 class="text-2xl font-bold" style="color: var(--text-primary);">{{ $editing ? 'Edit Customer' : 'Create Customer' }}</h1>
    </div>

    <form wire:submit="save">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {{-- Main Info --}}
            <div class="lg:col-span-2 space-y-4">
                <div class="card p-5">
                    <h3 class="text-sm font-semibold mb-4" style="color: var(--text-primary);">Customer Information</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="form-label">Customer Name *</label>
                            <input wire:model="customer_name" type="text" class="form-input" placeholder="Full name">
                            @error('customer_name') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
                        </div>
                        <div>
                            <label class="form-label">Company Name</label>
                            <input wire:model="company_name" type="text" class="form-input" placeholder="Company">
                        </div>
                        <div>
                            <label class="form-label">Phone</label>
                            <input wire:model="phone" type="text" class="form-input" placeholder="+92 300 1234567">
                        </div>
                        <div>
                            <label class="form-label">Email</label>
                            <input wire:model="email" type="email" class="form-input" placeholder="email@example.com">
                        </div>
                        <div>
                            <label class="form-label">VAT Number</label>
                            <input wire:model="vat_number" type="text" class="form-input">
                        </div>
                        <div>
                            <label class="form-label">Status</label>
                            <select wire:model="status" class="form-select">
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                                <option value="blocked">Blocked</option>
                            </select>
                        </div>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                        <div>
                            <label class="form-label">Billing Address</label>
                            <textarea wire:model="billing_address" class="form-input" rows="3"></textarea>
                        </div>
                        <div>
                            <label class="form-label">Shipping Address</label>
                            <textarea wire:model="shipping_address" class="form-input" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="mt-4">
                        <label class="form-label">Remarks</label>
                        <textarea wire:model="remarks" class="form-input" rows="2"></textarea>
                    </div>
                </div>

                {{-- Contacts --}}
                <div class="card p-5">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-sm font-semibold" style="color: var(--text-primary);">Contact Persons</h3>
                        <button type="button" wire:click="addContact" class="btn btn-secondary btn-sm">+ Add Contact</button>
                    </div>
                    @foreach($contacts as $i => $contact)
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-3 mb-3 p-3 rounded-lg" style="background: var(--bg-hover);">
                        <input wire:model="contacts.{{ $i }}.name" type="text" class="form-input" placeholder="Name *">
                        <input wire:model="contacts.{{ $i }}.phone" type="text" class="form-input" placeholder="Phone">
                        <input wire:model="contacts.{{ $i }}.email" type="email" class="form-input" placeholder="Email">
                        <div class="flex gap-2">
                            <input wire:model="contacts.{{ $i }}.designation" type="text" class="form-input" placeholder="Designation">
                            <button type="button" wire:click="removeContact({{ $i }})" class="btn btn-ghost btn-sm text-red-500">✕</button>
                        </div>
                    </div>
                    @endforeach
                    @if(empty($contacts))
                    <p class="text-sm text-center py-4" style="color: var(--text-muted);">No contacts added yet</p>
                    @endif
                </div>
            </div>

            {{-- Sidebar --}}
            <div class="space-y-4">
                <div class="card p-5">
                    <h3 class="text-sm font-semibold mb-4" style="color: var(--text-primary);">Financial</h3>
                    <div class="space-y-3">
                        <div>
                            <label class="form-label">Opening Balance ({{ $company->currency_symbol }})</label>
                            <input wire:model="opening_balance" type="number" step="0.01" class="form-input" {{ $editing ? 'disabled' : '' }}>
                        </div>
                        <div>
                            <label class="form-label">Credit Limit ({{ $company->currency_symbol }})</label>
                            <input wire:model="credit_limit" type="number" step="0.01" class="form-input">
                        </div>
                    </div>
                </div>

                <div class="card p-5">
                    <button type="submit" class="btn btn-primary w-full justify-center btn-lg">
                        <span wire:loading.remove wire:target="save">{{ $editing ? 'Update Customer' : 'Create Customer' }}</span>
                        <span wire:loading wire:target="save"><div class="spinner !w-4 !h-4 !border-white/30 !border-t-white"></div> Saving...</span>
                    </button>
                </div>
            </div>
        </div>
    </form>
</div>
