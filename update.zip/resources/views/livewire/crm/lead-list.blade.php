<div>
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
        <div>
            <h1 class="text-2xl font-bold" style="color: var(--text-primary);">Leads</h1>
            <p class="text-sm mt-1" style="color: var(--text-muted);">Track and manage your sales pipeline</p>
        </div>
        <a href="{{ route('leads.create', $company->slug) }}" class="btn btn-primary mt-3 sm:mt-0">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
            Add Lead
        </a>
    </div>

    {{-- Pipeline Summary --}}
    <div class="grid grid-cols-3 md:grid-cols-6 gap-3 mb-5">
        @php
            $statuses = ['new'=>['label'=>'New','color'=>'badge-blue'],'contacted'=>['label'=>'Contacted','color'=>'badge-indigo'],'qualified'=>['label'=>'Qualified','color'=>'badge-purple'],'proposal'=>['label'=>'Proposal','color'=>'badge-orange'],'won'=>['label'=>'Won','color'=>'badge-green'],'lost'=>['label'=>'Lost','color'=>'badge-red']];
            $counts = $leads->groupBy('status');
        @endphp
        @foreach($statuses as $key => $s)
        <button wire:click="$set('status', '{{ $key }}')" class="card p-3 text-center cursor-pointer {{ $status === $key ? 'ring-2 ring-indigo-500' : '' }}">
            <p class="text-lg font-bold" style="color: var(--text-primary);">{{ \App\Models\Lead::where('status', $key)->count() }}</p>
            <span class="badge {{ $s['color'] }} mt-1">{{ $s['label'] }}</span>
        </button>
        @endforeach
    </div>

    {{-- Filters --}}
    <div class="card p-4 mb-4">
        <div class="flex flex-col sm:flex-row gap-3">
            <div class="flex-1">
                <input wire:model.live.debounce.300ms="search" type="text" placeholder="Search leads..." class="form-input">
            </div>
            <select wire:model.live="status" class="form-select sm:w-44">
                <option value="">All Stages</option>
                <option value="new">New</option>
                <option value="contacted">Contacted</option>
                <option value="qualified">Qualified</option>
                <option value="proposal">Proposal Sent</option>
                <option value="won">Won</option>
                <option value="lost">Lost</option>
            </select>
        </div>
    </div>

    {{-- Table --}}
    <div class="card overflow-x-auto">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Lead</th>
                    <th>Company</th>
                    <th>Phone</th>
                    <th>Source</th>
                    <th>Value</th>
                    <th>Status</th>
                    <th class="text-right">Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($leads as $lead)
                @php
                    $statusColors = ['new'=>'badge-blue','contacted'=>'badge-indigo','qualified'=>'badge-purple','proposal'=>'badge-orange','won'=>'badge-green','lost'=>'badge-red'];
                @endphp
                <tr>
                    <td>
                        <p class="font-medium" style="color: var(--text-primary);">{{ $lead->name }}</p>
                        <p class="text-xs" style="color: var(--text-muted);">{{ $lead->email }}</p>
                    </td>
                    <td>{{ $lead->company_name ?? '-' }}</td>
                    <td>{{ $lead->phone ?? '-' }}</td>
                    <td><span class="badge badge-gray">{{ ucfirst($lead->source ?? 'N/A') }}</span></td>
                    <td class="font-semibold" style="color: var(--text-primary);">
                        @if($lead->estimated_value){{ $company->currency_symbol }} {{ number_format($lead->estimated_value) }}@else -@endif
                    </td>
                    <td><span class="badge {{ $statusColors[$lead->status] ?? 'badge-gray' }}">{{ ucfirst($lead->status) }}</span></td>
                    <td class="text-right">
                        <div class="flex items-center justify-end gap-1">
                            <a href="{{ route('leads.edit', [$company->slug, $lead->id]) }}" class="btn btn-ghost btn-xs">Edit</a>
                            <button wire:click="confirmDelete({{ $lead->id }})" class="btn btn-ghost btn-xs text-red-500">Del</button>
                        </div>
                    </td>
                </tr>
                @empty
                <tr><td colspan="7" class="text-center py-10" style="color: var(--text-muted);">No leads found. Start building your pipeline!</td></tr>
                @endforelse
            </tbody>
        </table>
        <div class="px-4 py-3 pagination-wrapper">{{ $leads->links() }}</div>
    </div>

    @if($showDeleteModal)
    <div class="modal-backdrop" wire:click.self="$set('showDeleteModal', false)">
        <div class="modal-content max-w-sm p-6">
            <h3 class="text-lg font-semibold mb-2" style="color: var(--text-primary);">Delete Lead?</h3>
            <p class="text-sm mb-5" style="color: var(--text-secondary);">This will permanently remove the lead and all follow-ups.</p>
            <div class="flex gap-3 justify-end">
                <button wire:click="$set('showDeleteModal', false)" class="btn btn-secondary">Cancel</button>
                <button wire:click="delete" class="btn btn-danger">Delete</button>
            </div>
        </div>
    </div>
    @endif
</div>
