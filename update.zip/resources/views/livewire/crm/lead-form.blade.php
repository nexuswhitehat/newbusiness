<div>
    <div class="flex items-center gap-3 mb-6">
        <a href="{{ route('leads.index', $company->slug) }}" class="btn btn-ghost btn-sm"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg></a>
        <h1 class="text-2xl font-bold" style="color: var(--text-primary);">{{ $editing ? 'Edit Lead' : 'New Lead' }}</h1>
    </div>
    <form wire:submit="save">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div class="lg:col-span-2 space-y-4">
                <div class="card p-5">
                    <h3 class="text-sm font-semibold mb-4" style="color: var(--text-primary);">Lead Information</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div><label class="form-label">Full Name *</label><input wire:model="name" type="text" class="form-input">@error('name')<span class="text-red-500 text-xs">{{ $message }}</span>@enderror</div>
                        <div><label class="form-label">Company</label><input wire:model="company_name" type="text" class="form-input"></div>
                        <div><label class="form-label">Phone</label><input wire:model="phone" type="text" class="form-input"></div>
                        <div><label class="form-label">Email</label><input wire:model="email" type="email" class="form-input"></div>
                        <div><label class="form-label">Source</label>
                            <select wire:model="source" class="form-select">
                                <option value="manual">Manual</option><option value="website">Website</option><option value="referral">Referral</option><option value="social_media">Social Media</option><option value="call">Cold Call</option><option value="email">Email Campaign</option><option value="other">Other</option>
                            </select>
                        </div>
                        <div><label class="form-label">Status</label>
                            <select wire:model="status" class="form-select">
                                <option value="new">New</option><option value="contacted">Contacted</option><option value="qualified">Qualified</option><option value="proposal">Proposal Sent</option><option value="won">Won</option><option value="lost">Lost</option>
                            </select>
                        </div>
                        <div><label class="form-label">Estimated Value ({{ $company->currency_symbol }})</label><input wire:model="estimated_value" type="number" step="0.01" class="form-input"></div>
                        <div><label class="form-label">Expected Close Date</label><input wire:model="expected_close_date" type="date" class="form-input"></div>
                        <div><label class="form-label">Assigned To</label>
                            <select wire:model="assigned_to" class="form-select">
                                <option value="">Unassigned</option>
                                @foreach($admins as $admin)<option value="{{ $admin->id }}">{{ $admin->name }}</option>@endforeach
                            </select>
                        </div>
                    </div>
                    <div class="mt-4"><label class="form-label">Notes</label><textarea wire:model="notes" class="form-input" rows="4"></textarea></div>
                </div>
            </div>
            <div>
                <div class="card p-5">
                    <button type="submit" class="btn btn-primary w-full justify-center btn-lg">
                        <span wire:loading.remove wire:target="save">{{ $editing ? 'Update Lead' : 'Create Lead' }}</span>
                        <span wire:loading wire:target="save" class="flex items-center gap-2"><div class="spinner !w-4 !h-4 !border-white/30 !border-t-white"></div> Saving...</span>
                    </button>
                </div>
            </div>
        </div>
    </form>
</div>
