<div>
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
        <div class="flex items-center gap-3">
            <a href="{{ route('customers.index', $company->slug) }}" class="btn btn-ghost btn-sm"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg></a>
            <div>
                <h1 class="text-2xl font-bold" style="color: var(--text-primary);">{{ $customer->customer_name }}</h1>
                <p class="text-sm" style="color: var(--text-muted);">{{ $customer->customer_code }} · {{ $customer->company_name }}</p>
            </div>
        </div>
        <div class="flex gap-2 mt-3 sm:mt-0">
            <a href="{{ route('invoices.create', $company->slug) }}" class="btn btn-primary btn-sm">+ Invoice</a>
            <a href="{{ route('customers.edit', [$company->slug, $customer->id]) }}" class="btn btn-secondary btn-sm">Edit</a>
        </div>
    </div>

    {{-- Stats --}}
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div class="stat-card stat-card-blue"><p class="text-xl font-bold" style="color: var(--text-primary);">{{ $customer->invoices->count() }}</p><p class="text-xs" style="color: var(--text-muted);">Total Invoices</p></div>
        <div class="stat-card stat-card-green"><p class="text-xl font-bold text-emerald-500">{{ $company->currency_symbol }} {{ number_format($customer->payments->sum('amount'), 2) }}</p><p class="text-xs" style="color: var(--text-muted);">Total Paid</p></div>
        <div class="stat-card stat-card-red"><p class="text-xl font-bold text-red-500">{{ $company->currency_symbol }} {{ number_format($customer->current_balance, 2) }}</p><p class="text-xs" style="color: var(--text-muted);">Outstanding</p></div>
        <div class="stat-card stat-card-purple"><p class="text-xl font-bold" style="color: var(--text-primary);">{{ $company->currency_symbol }} {{ number_format($customer->credit_limit, 2) }}</p><p class="text-xs" style="color: var(--text-muted);">Credit Limit</p></div>
    </div>

    {{-- Tabs --}}
    <div class="flex gap-1 border-b mb-4" style="border-color: var(--border-color);">
        <button wire:click="$set('tab', 'overview')" class="tab-link {{ $tab == 'overview' ? 'active' : '' }}">Overview</button>
        <button wire:click="$set('tab', 'invoices')" class="tab-link {{ $tab == 'invoices' ? 'active' : '' }}">Invoices</button>
        <button wire:click="$set('tab', 'payments')" class="tab-link {{ $tab == 'payments' ? 'active' : '' }}">Payments</button>
        <button wire:click="$set('tab', 'ledger')" class="tab-link {{ $tab == 'ledger' ? 'active' : '' }}">Ledger</button>
        <button wire:click="$set('tab', 'contacts')" class="tab-link {{ $tab == 'contacts' ? 'active' : '' }}">Contacts</button>
    </div>

    {{-- Tab Content --}}
    @if($tab == 'overview')
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div class="card p-5">
            <h3 class="text-sm font-semibold mb-3" style="color: var(--text-primary);">Details</h3>
            <dl class="space-y-2 text-sm">
                <div class="flex justify-between"><dt style="color: var(--text-muted);">Phone</dt><dd style="color: var(--text-primary);">{{ $customer->phone ?? '-' }}</dd></div>
                <div class="flex justify-between"><dt style="color: var(--text-muted);">Email</dt><dd style="color: var(--text-primary);">{{ $customer->email ?? '-' }}</dd></div>
                <div class="flex justify-between"><dt style="color: var(--text-muted);">VAT</dt><dd style="color: var(--text-primary);">{{ $customer->vat_number ?? '-' }}</dd></div>
                <div class="flex justify-between"><dt style="color: var(--text-muted);">Status</dt><dd><span class="badge badge-{{ $customer->status == 'active' ? 'green' : 'red' }}">{{ ucfirst($customer->status) }}</span></dd></div>
            </dl>
        </div>
        <div class="card p-5">
            <h3 class="text-sm font-semibold mb-3" style="color: var(--text-primary);">Addresses</h3>
            <div class="space-y-3 text-sm">
                <div><p class="text-xs font-semibold" style="color: var(--text-muted);">Billing</p><p style="color: var(--text-primary);">{{ $customer->billing_address ?: 'Not provided' }}</p></div>
                <div><p class="text-xs font-semibold" style="color: var(--text-muted);">Shipping</p><p style="color: var(--text-primary);">{{ $customer->shipping_address ?: 'Not provided' }}</p></div>
            </div>
        </div>
    </div>
    @elseif($tab == 'invoices')
    <div class="card overflow-x-auto">
        <table class="data-table"><thead><tr><th>Invoice#</th><th>Date</th><th>Total</th><th>Paid</th><th>Due</th><th>Status</th></tr></thead>
            <tbody>
                @forelse($customer->invoices as $inv)
                <tr><td><a href="{{ route('invoices.show', [$company->slug, $inv->id]) }}" class="text-indigo-500 hover:underline">{{ $inv->invoice_no }}</a></td><td>{{ $inv->invoice_date->format('d M Y') }}</td><td>{{ $company->currency_symbol }} {{ number_format($inv->grand_total, 2) }}</td><td class="text-emerald-500">{{ $company->currency_symbol }} {{ number_format($inv->paid_amount, 2) }}</td><td class="text-red-500">{{ $company->currency_symbol }} {{ number_format($inv->due_amount, 2) }}</td><td><span class="badge badge-{{ $inv->status_color }}">{{ ucfirst($inv->status) }}</span></td></tr>
                @empty
                <tr><td colspan="6" class="text-center py-6" style="color: var(--text-muted);">No invoices</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    @elseif($tab == 'payments')
    <div class="card overflow-x-auto">
        <table class="data-table"><thead><tr><th>Payment#</th><th>Date</th><th>Method</th><th>Amount</th><th>Reference</th></tr></thead>
            <tbody>
                @forelse($customer->payments as $pay)
                <tr><td>{{ $pay->payment_no }}</td><td>{{ $pay->payment_date->format('d M Y') }}</td><td><span class="badge badge-blue">{{ ucfirst(str_replace('_', ' ', $pay->payment_method)) }}</span></td><td class="text-emerald-500 font-semibold">{{ $company->currency_symbol }} {{ number_format($pay->amount, 2) }}</td><td>{{ $pay->reference ?? '-' }}</td></tr>
                @empty
                <tr><td colspan="5" class="text-center py-6" style="color: var(--text-muted);">No payments</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    @elseif($tab == 'ledger')
    <div class="card overflow-x-auto">
        <table class="data-table"><thead><tr><th>Date</th><th>Reference</th><th>Type</th><th>Debit</th><th>Credit</th><th>Balance</th></tr></thead>
            <tbody>
                @forelse($customer->ledger as $entry)
                <tr><td>{{ $entry->date->format('d M Y') }}</td><td>{{ $entry->reference ?? '-' }}</td><td><span class="badge badge-gray">{{ ucfirst(str_replace('_', ' ', $entry->type)) }}</span></td><td class="text-red-500">{{ $entry->debit > 0 ? $company->currency_symbol . ' ' . number_format($entry->debit, 2) : '-' }}</td><td class="text-emerald-500">{{ $entry->credit > 0 ? $company->currency_symbol . ' ' . number_format($entry->credit, 2) : '-' }}</td><td class="font-semibold" style="color: var(--text-primary);">{{ $company->currency_symbol }} {{ number_format($entry->balance, 2) }}</td></tr>
                @empty
                <tr><td colspan="6" class="text-center py-6" style="color: var(--text-muted);">No ledger entries</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    @elseif($tab == 'contacts')
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        @forelse($customer->contacts as $contact)
        <div class="card p-4">
            <p class="font-semibold text-sm" style="color: var(--text-primary);">{{ $contact->name }}</p>
            <p class="text-xs" style="color: var(--text-muted);">{{ $contact->designation }}</p>
            <div class="mt-2 space-y-1 text-xs" style="color: var(--text-secondary);">
                @if($contact->phone)<p>📞 {{ $contact->phone }}</p>@endif
                @if($contact->email)<p>✉️ {{ $contact->email }}</p>@endif
            </div>
        </div>
        @empty
        <div class="col-span-full text-center py-8" style="color: var(--text-muted);">No contacts added</div>
        @endforelse
    </div>
    @endif
</div>
