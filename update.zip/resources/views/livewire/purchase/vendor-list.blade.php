<div>
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold" style="color: var(--text-primary);">Vendors</h1>
        <a href="{{ route('vendors.create', $company->slug) }}" class="btn btn-primary"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg> Add Vendor</a>
    </div>
    <div class="card p-4 mb-4"><input wire:model.live.debounce.300ms="search" type="text" placeholder="Search vendors..." class="form-input"></div>
    <div class="card overflow-x-auto">
        <table class="data-table"><thead><tr><th>Code</th><th>Vendor Name</th><th>Phone</th><th>Email</th><th>Balance</th><th>Status</th><th class="text-right">Actions</th></tr></thead>
        <tbody>
            @forelse($vendors as $v)
            <tr><td class="font-mono text-xs">{{ $v->vendor_code }}</td><td><p class="font-medium" style="color: var(--text-primary);">{{ $v->contact_name }}</p>@if($v->company_name)<p class="text-xs" style="color: var(--text-muted);">{{ $v->company_name }}</p>@endif</td><td>{{ $v->phone ?? '-' }}</td><td>{{ $v->email ?? '-' }}</td><td class="font-semibold {{ $v->current_balance > 0 ? 'text-red-500' : 'text-emerald-500' }}">{{ $company->currency_symbol }} {{ number_format(abs($v->current_balance),2) }}</td><td><span class="badge badge-{{ $v->status=='active'?'green':'gray' }}">{{ ucfirst($v->status) }}</span></td>
            <td class="text-right"><div class="flex justify-end gap-1"><a href="{{ route('vendors.show',[$company->slug,$v->id]) }}" class="btn btn-ghost btn-xs">View</a><a href="{{ route('vendors.edit',[$company->slug,$v->id]) }}" class="btn btn-ghost btn-xs">Edit</a><button wire:click="confirmDelete({{ $v->id }})" class="btn btn-ghost btn-xs text-red-500">Del</button></div></td></tr>
            @empty<tr><td colspan="7" class="text-center py-10" style="color: var(--text-muted);">No vendors found.</td></tr>@endforelse
        </tbody></table>
        <div class="px-4 py-3 pagination-wrapper">{{ $vendors->links() }}</div>
    </div>
    @if($showDeleteModal)<div class="modal-backdrop" wire:click.self="$set('showDeleteModal',false)"><div class="modal-content max-w-sm p-6"><h3 class="text-lg font-semibold mb-4" style="color: var(--text-primary);">Delete Vendor?</h3><div class="flex gap-3 justify-end"><button wire:click="$set('showDeleteModal',false)" class="btn btn-secondary">Cancel</button><button wire:click="delete" class="btn btn-danger">Delete</button></div></div></div>@endif
</div>
