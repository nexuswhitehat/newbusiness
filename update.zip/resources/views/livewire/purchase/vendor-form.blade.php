<div>
    <div class="flex items-center gap-3 mb-6">
        <a href="{{ route('vendors.index', $company->slug) }}" class="btn btn-ghost btn-sm"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg></a>
        <h1 class="text-2xl font-bold" style="color: var(--text-primary);">{{ $editing ? 'Edit Vendor' : 'Add Vendor' }}</h1>
    </div>
    <form wire:submit="save">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div class="lg:col-span-2">
                <div class="card p-5">
                    <h3 class="text-sm font-semibold mb-4" style="color: var(--text-primary);">Vendor Information</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div><label class="form-label">Vendor Name *</label><input wire:model="contact_name" type="text" class="form-input">@error('contact_name')<span class="text-red-500 text-xs">{{ $message }}</span>@enderror</div>
                        <div><label class="form-label">Company Name</label><input wire:model="company_name" type="text" class="form-input"></div>
                        <div><label class="form-label">Phone</label><input wire:model="phone" type="text" class="form-input"></div>
                        <div><label class="form-label">Email</label><input wire:model="email" type="email" class="form-input"></div>
                        <div><label class="form-label">Opening Balance ({{ $company->currency_symbol }})</label><input wire:model="opening_balance" type="number" step="0.01" class="form-input" {{ $editing?'disabled':'' }}></div>
                        <div><label class="form-label">Status</label><select wire:model="status" class="form-select"><option value="active">Active</option><option value="inactive">Inactive</option></select></div>
                    </div>
                    <div class="mt-4"><label class="form-label">Address</label><textarea wire:model="address" class="form-input" rows="3"></textarea></div>
                </div>
            </div>
            <div><div class="card p-5"><button type="submit" class="btn btn-primary w-full justify-center btn-lg"><span wire:loading.remove wire:target="save">{{ $editing ? 'Update' : 'Add Vendor' }}</span><span wire:loading wire:target="save"><div class="spinner !w-4 !h-4 !border-white/30 !border-t-white"></div></span></button></div></div>
        </div>
    </form>
</div>
