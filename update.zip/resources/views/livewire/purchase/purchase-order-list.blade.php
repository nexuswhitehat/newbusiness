<div>
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold" style="color: var(--text-primary);">Purchase Orders</h1>
        <a href="{{ route('purchase-orders.create', $company->slug) }}" class="btn btn-primary">+ New PO</a>
    </div>
    <div class="card p-4 mb-4"><div class="flex gap-3"><div class="flex-1"><input wire:model.live.debounce.300ms="search" type="text" placeholder="Search POs..." class="form-input"></div><select wire:model.live="status" class="form-select w-40"><option value="">All</option><option value="draft">Draft</option><option value="sent">Sent</option><option value="received">Received</option><option value="cancelled">Cancelled</option></select></div></div>
    <div class="card overflow-x-auto">
        <table class="data-table"><thead><tr><th>PO#</th><th>Vendor</th><th>Date</th><th>Total</th><th>Status</th><th class="text-right">Actions</th></tr></thead>
        <tbody>
            @forelse($pos as $po)
            <tr><td class="text-indigo-500 font-mono font-medium">{{ $po->po_no }}</td><td style="color: var(--text-primary);">{{ $po->vendor->contact_name ?? '-' }}</td><td>{{ $po->po_date->format('d M Y') }}</td><td class="font-semibold">{{ $company->currency_symbol }} {{ number_format($po->grand_total,2) }}</td><td><span class="badge badge-gray">{{ ucfirst($po->status) }}</span></td>
            <td class="text-right"><div class="flex justify-end gap-1"><a href="{{ route('purchase-orders.edit',[$company->slug,$po->id]) }}" class="btn btn-ghost btn-xs">Edit</a></div></td></tr>
            @empty<tr><td colspan="6" class="text-center py-10" style="color: var(--text-muted);">No purchase orders.</td></tr>@endforelse
        </tbody></table>
        <div class="px-4 py-3 pagination-wrapper">{{ $pos->links() }}</div>
    </div>
</div>
