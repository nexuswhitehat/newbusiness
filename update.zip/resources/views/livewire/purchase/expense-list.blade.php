<div>
    <div class="flex items-center justify-between mb-6">
        <div><h1 class="text-2xl font-bold" style="color: var(--text-primary);">Expenses</h1><p class="text-sm mt-1" style="color: var(--text-muted);">This month: {{ $company->currency_symbol }} {{ number_format($totalMonth,2) }}</p></div>
        <a href="{{ route('expenses.create', $company->slug) }}" class="btn btn-primary">+ Add Expense</a>
    </div>
    <div class="card p-4 mb-4"><input wire:model.live.debounce.300ms="search" type="text" placeholder="Search expenses..." class="form-input"></div>
    <div class="card overflow-x-auto">
        <table class="data-table"><thead><tr><th>Expense#</th><th>Category</th><th>Date</th><th>Vendor</th><th>Method</th><th>Amount</th><th>Actions</th></tr></thead>
        <tbody>
            @forelse($expenses as $e)
            <tr><td class="font-mono text-xs">{{ $e->expense_no }}</td><td><span class="badge badge-gray">{{ $e->category->name??'-' }}</span></td><td>{{ $e->date->format('d M Y') }}</td><td>{{ $e->contact_name??'-' }}</td><td><span class="badge badge-blue">{{ ucfirst(str_replace('_',' ',$e->payment_method)) }}</span></td><td class="font-semibold text-red-500">{{ $company->currency_symbol }} {{ number_format($e->amount,2) }}</td><td><a href="{{ route('expenses.edit',[$company->slug,$e->id]) }}" class="btn btn-ghost btn-xs">Edit</a></td></tr>
            @empty<tr><td colspan="7" class="text-center py-10" style="color: var(--text-muted);">No expenses recorded.</td></tr>@endforelse
        </tbody></table>
        <div class="px-4 py-3 pagination-wrapper">{{ $expenses->links() }}</div>
    </div>
</div>
