<div>
    <div class="flex items-center justify-between mb-6">
        <div><h1 class="text-2xl font-bold" style="color: var(--text-primary);">Purchase Bills</h1><p class="text-sm mt-1" style="color: var(--text-muted);">Total Outstanding: {{ $company->currency_symbol }} {{ number_format($totalDue,2) }}</p></div>
        <a href="{{ route('purchase-bills.create', $company->slug) }}" class="btn btn-primary">+ New Bill</a>
    </div>
    <div class="card p-4 mb-4"><div class="flex gap-3"><div class="flex-1"><input wire:model.live.debounce.300ms="search" type="text" placeholder="Search bills..." class="form-input"></div><select wire:model.live="status" class="form-select w-36"><option value="">All</option><option value="draft">Draft</option><option value="partial">Partial</option><option value="paid">Paid</option></select></div></div>
    <div class="card overflow-x-auto">
        <table class="data-table"><thead><tr><th>Bill#</th><th>Vendor</th><th>Date</th><th>Total</th><th>Due</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody>
            @forelse($bills as $b)
            @php $sc=['draft'=>'badge-gray','partial'=>'badge-orange','paid'=>'badge-green','cancelled'=>'badge-red']; @endphp
            <tr><td class="font-mono text-xs">{{ $b->bill_no }}</td><td style="color: var(--text-primary);">{{ $b->vendor->contact_name??'-' }}</td><td>{{ $b->bill_date->format('d M Y') }}</td><td>{{ $company->currency_symbol }} {{ number_format($b->grand_total,2) }}</td><td class="{{ $b->due_amount>0?'text-red-500 font-semibold':'' }}">{{ $company->currency_symbol }} {{ number_format($b->due_amount,2) }}</td><td><span class="badge {{ $sc[$b->status]??'badge-gray' }}">{{ ucfirst($b->status) }}</span></td>
            <td><a href="{{ route('purchase-bills.edit',[$company->slug,$b->id]) }}" class="btn btn-ghost btn-xs">Edit</a></td></tr>
            @empty<tr><td colspan="7" class="text-center py-10" style="color: var(--text-muted);">No bills.</td></tr>@endforelse
        </tbody></table>
        <div class="px-4 py-3 pagination-wrapper">{{ $bills->links() }}</div>
    </div>
</div>
