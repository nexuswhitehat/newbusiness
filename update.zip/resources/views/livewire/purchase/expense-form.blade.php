<div>
    <div class="flex items-center gap-3 mb-6">
        <a href="{{ route('expenses.index', $company->slug) }}" class="btn btn-ghost btn-sm"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg></a>
        <h1 class="text-2xl font-bold" style="color: var(--text-primary);">{{ $editing ? 'Edit Expense' : 'Add Expense' }}</h1>
    </div>
    <form wire:submit="save">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div class="lg:col-span-2">
                <div class="card p-5">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div><label class="form-label">Category *</label><select wire:model="category_id" class="form-select"><option value="">Select...</option>@foreach($categories as $c)<option value="{{ $c->id }}">{{ $c->name }}</option>@endforeach</select>@error('category_id')<span class="text-red-500 text-xs">{{ $message }}</span>@enderror</div>
                        <div><label class="form-label">Amount ({{ $company->currency_symbol }}) *</label><input wire:model="amount" type="number" step="0.01" min="0.01" class="form-input">@error('amount')<span class="text-red-500 text-xs">{{ $message }}</span>@enderror</div>
                        <div><label class="form-label">Date *</label><input wire:model="date" type="date" class="form-input"></div>
                        <div><label class="form-label">Payment Method *</label><select wire:model="payment_method" class="form-select"><option value="cash">Cash</option><option value="bank_transfer">Bank Transfer</option><option value="cheque">Cheque</option><option value="card">Card</option></select></div>
                        <div><label class="form-label">Vendor Name</label><input wire:model="contact_name" type="text" class="form-input"></div>
                        <div><label class="form-label">Reference</label><input wire:model="reference" type="text" class="form-input"></div>
                    </div>
                    <div class="mt-4"><label class="form-label">Remarks</label><textarea wire:model="remarks" class="form-input" rows="2"></textarea></div>
                </div>
            </div>
            <div><div class="card p-5"><button type="submit" class="btn btn-primary w-full justify-center btn-lg"><span wire:loading.remove wire:target="save">{{ $editing ? 'Update' : 'Add Expense' }}</span><span wire:loading wire:target="save"><div class="spinner !w-4 !h-4 !border-white/30 !border-t-white"></div></span></button></div></div>
        </div>
    </form>
</div>
