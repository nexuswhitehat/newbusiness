<div>
    <div class="flex items-center gap-3 mb-6">
        <a href="{{ route('admin.roles.index', $company->slug) }}" class="btn btn-ghost btn-sm"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg></a>
        <h1 class="text-2xl font-bold" style="color: var(--text-primary);">{{ $editing ? 'Edit Role' : 'Create Role' }}</h1>
    </div>
    <form wire:submit="save">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div class="lg:col-span-2">
                <div class="card p-5 mb-4">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div><label class="form-label">Role Name *</label><input wire:model="name" type="text" class="form-input">@error('name')<span class="text-red-500 text-xs">{{ $message }}</span>@enderror</div>
                        <div><label class="form-label">Description</label><input wire:model="description" type="text" class="form-input"></div>
                    </div>
                </div>
                <div class="card p-5">
                    <h3 class="text-sm font-semibold mb-4" style="color: var(--text-primary);">Permissions</h3>
                    @foreach($permissions as $module => $perms)
                    <div class="mb-5">
                        <div class="flex items-center justify-between mb-2">
                            <h4 class="text-xs font-bold uppercase tracking-wide" style="color: var(--text-muted);">{{ ucfirst($module) }}</h4>
                            <button type="button" wire:click="toggleAll('{{ $module }}')" class="text-xs text-indigo-500 hover:text-indigo-400">Toggle All</button>
                        </div>
                        <div class="flex flex-wrap gap-2">
                            @foreach($perms as $perm)
                            <label class="flex items-center gap-1.5 cursor-pointer px-3 py-1.5 rounded-lg border transition {{ in_array($perm->id, $selectedPermissions) ? 'border-indigo-500 bg-indigo-500/10' : '' }}" style="border-color: var(--border-color);">
                                <input type="checkbox" wire:model.live="selectedPermissions" value="{{ $perm->id }}" class="hidden">
                                <span class="text-xs font-medium" style="color: var(--text-primary);">{{ ucfirst($perm->action) }}</span>
                            </label>
                            @endforeach
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
            <div>
                <div class="card p-5">
                    <p class="text-sm mb-2" style="color: var(--text-muted);">{{ count($selectedPermissions) }} permissions selected</p>
                    <button type="submit" class="btn btn-primary w-full justify-center btn-lg">
                        <span wire:loading.remove wire:target="save">{{ $editing ? 'Update Role' : 'Create Role' }}</span>
                        <span wire:loading wire:target="save"><div class="spinner !w-4 !h-4 !border-white/30 !border-t-white"></div></span>
                    </button>
                </div>
            </div>
        </div>
    </form>
</div>
