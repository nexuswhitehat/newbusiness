<div>
    <div class="mb-6"><h1 class="text-2xl font-bold" style="color: var(--text-primary);">Activity Logs</h1></div>
    <div class="card p-4 mb-4"><div class="flex gap-3"><div class="flex-1"><input wire:model.live.debounce.300ms="search" type="text" placeholder="Search logs..." class="form-input"></div><select wire:model.live="module" class="form-select w-40"><option value="">All Modules</option>@foreach($modules as $m)<option value="{{ $m }}">{{ ucfirst($m) }}</option>@endforeach</select></div></div>
    <div class="card overflow-x-auto">
        <table class="data-table">
            <thead><tr><th>Date/Time</th><th>User</th><th>Module</th><th>Action</th><th>Description</th></tr></thead>
            <tbody>
                @forelse($logs as $log)
                <tr>
                    <td class="text-xs" style="color: var(--text-muted);">{{ $log->created_at->format('d M Y H:i') }}</td>
                    <td class="text-sm" style="color: var(--text-primary);">{{ $log->admin->name ?? 'System' }}</td>
                    <td><span class="badge badge-indigo">{{ ucfirst($log->module) }}</span></td>
                    <td><span class="badge badge-{{ ['created'=>'green','updated'=>'blue','deleted'=>'red','login'=>'purple','logout'=>'gray'][$log->action]??'gray' }}">{{ ucfirst($log->action) }}</span></td>
                    <td class="text-sm" style="color: var(--text-secondary);">{{ $log->description }}</td>
                </tr>
                @empty
                <tr><td colspan="5" class="text-center py-8" style="color: var(--text-muted);">No activity logs.</td></tr>
                @endforelse
            </tbody>
        </table>
        <div class="px-4 py-3 pagination-wrapper">{{ $logs->links() }}</div>
    </div>
</div>
