<div>
    <div class="flex items-center gap-3 mb-6">
        <a href="{{ route('admin.admins.index', $company->slug) }}" class="btn btn-ghost btn-sm"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg></a>
        <h1 class="text-2xl font-bold" style="color: var(--text-primary);">{{ $editing ? 'Edit Admin' : 'Add Admin' }}</h1>
    </div>
    <form wire:submit="save">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div class="lg:col-span-2 space-y-4">
                <div class="card p-5">
                    <h3 class="text-sm font-semibold mb-4" style="color: var(--text-primary);">Admin Information</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div><label class="form-label">Full Name *</label><input wire:model="name" type="text" class="form-input">@error('name')<span class="text-red-500 text-xs">{{ $message }}</span>@enderror</div>
                        <div><label class="form-label">Email *</label><input wire:model="email" type="email" class="form-input">@error('email')<span class="text-red-500 text-xs">{{ $message }}</span>@enderror</div>
                        <div><label class="form-label">Phone</label><input wire:model="phone" type="text" class="form-input"></div>
                        <div><label class="form-label">Role *</label><select wire:model="role_id" class="form-select"><option value="">Select role...</option>@foreach($roles as $r)<option value="{{ $r->id }}">{{ $r->name }}</option>@endforeach</select>@error('role_id')<span class="text-red-500 text-xs">{{ $message }}</span>@enderror</div>
                        <div><label class="form-label">Password {{ $editing ? '(leave blank to keep)' : '*' }}</label><input wire:model="password" type="password" class="form-input" placeholder="{{ $editing ? 'New password...' : 'Min 8 characters' }}">@error('password')<span class="text-red-500 text-xs">{{ $message }}</span>@enderror</div>
                        <div><label class="form-label">Status</label><select wire:model="status" class="form-select"><option value="active">Active</option><option value="inactive">Inactive</option></select></div>
                    </div>
                </div>
                <div class="card p-5">
                    <h3 class="text-sm font-semibold mb-4" style="color: var(--text-primary);">Assign Companies</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                        @foreach($companies as $comp)
                        <label class="flex items-center gap-3 p-3 rounded-lg border cursor-pointer {{ in_array($comp->id, $companyIds) ? 'border-indigo-500 bg-indigo-500/10' : '' }}" style="border-color: var(--border-color);">
                            <input type="checkbox" wire:model.live="companyIds" value="{{ $comp->id }}" class="text-indigo-500">
                            <div>
                                <p class="text-sm font-medium" style="color: var(--text-primary);">{{ $comp->name }}</p>
                                <p class="text-xs" style="color: var(--text-muted);">{{ $comp->slug }}</p>
                            </div>
                        </label>
                        @endforeach
                    </div>
                </div>
            </div>
            <div><div class="card p-5"><button type="submit" class="btn btn-primary w-full justify-center btn-lg"><span wire:loading.remove wire:target="save">{{ $editing ? 'Update Admin' : 'Add Admin' }}</span><span wire:loading wire:target="save"><div class="spinner !w-4 !h-4 !border-white/30 !border-t-white"></div></span></button></div></div>
        </div>
    </form>
</div>
