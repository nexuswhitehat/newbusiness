<div>
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold" style="color: var(--text-primary);">Admin Users</h1>
        <a href="{{ route('admin.admins.create', $company->slug) }}" class="btn btn-primary">+ Add Admin</a>
    </div>
    <div class="card p-4 mb-4"><div class="flex gap-3"><div class="flex-1"><input wire:model.live.debounce.300ms="search" type="text" placeholder="Search admins..." class="form-input"></div><select wire:model.live="status" class="form-select w-36"><option value="">All</option><option value="active">Active</option><option value="inactive">Inactive</option></select></div></div>
    <div class="card overflow-x-auto">
        <table class="data-table">
            <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Companies</th><th>Last Login</th><th>Status</th><th class="text-right">Actions</th></tr></thead>
            <tbody>
                @forelse($admins as $admin)
                <tr>
                    <td>
                        <div class="flex items-center gap-3">
                            <img src="{{ $admin->photo_url }}" class="w-8 h-8 rounded-full object-cover">
                            <div><p class="font-medium" style="color: var(--text-primary);">{{ $admin->name }}</p></div>
                        </div>
                    </td>
                    <td style="color: var(--text-muted);">{{ $admin->email }}</td>
                    <td><span class="badge badge-indigo">{{ $admin->role->name ?? '-' }}</span></td>
                    <td><span class="badge badge-blue">{{ $admin->companies->count() }} co.</span></td>
                    <td class="text-xs" style="color: var(--text-muted);">{{ $admin->last_login ? $admin->last_login->diffForHumans() : 'Never' }}</td>
                    <td><span class="badge badge-{{ $admin->status==='active'?'green':'gray' }}">{{ ucfirst($admin->status) }}</span></td>
                    <td class="text-right">
                        <div class="flex justify-end gap-1">
                            <a href="{{ route('admin.admins.edit', [$company->slug, $admin->id]) }}" class="btn btn-ghost btn-xs">Edit</a>
                            @if(auth('admin')->user()->isSuperAdmin() && auth('admin')->id() !== $admin->id)
                                <button wire:click="delete({{ $admin->id }})" wire:confirm="Are you sure you want to delete this admin?" class="btn btn-ghost btn-xs text-red-500 hover:text-red-700">Delete</button>
                            @endif
                        </div>
                    </td>
                </tr>
                @empty
                <tr><td colspan="7" class="text-center py-10" style="color: var(--text-muted);">No admins found.</td></tr>
                @endforelse
            </tbody>
        </table>
        <div class="px-4 py-3 pagination-wrapper">{{ $admins->links() }}</div>
    </div>
</div>
