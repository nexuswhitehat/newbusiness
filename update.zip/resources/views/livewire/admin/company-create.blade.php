<div class="login-bg" x-data>
    <div class="w-full max-w-2xl px-4 py-8">
        {{-- Header --}}
        <div class="text-center mb-8">
            <div class="w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 mx-auto flex items-center justify-center text-white text-2xl font-bold shadow-lg mb-4">
                NB
            </div>
            <h1 class="text-2xl font-bold text-white">Create New Company</h1>
            <p class="text-sm text-slate-400 mt-1">Set up your company to get started with NewBusiness ERP</p>
        </div>

        {{-- Success / Error --}}
        @if (session('error'))
            <div class="mb-4 p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-sm">
                {{ session('error') }}
            </div>
        @endif

        <div class="login-card !max-w-2xl !p-6">
            <form wire:submit="save" class="space-y-6">
                {{-- Company Name --}}
                <div>
                    <label class="block text-xs font-semibold text-slate-300 mb-2">Company Name *</label>
                    <input wire:model="name" type="text" placeholder="e.g. Acme Corporation"
                           class="w-full bg-slate-800/50 border border-slate-700 rounded-lg py-2.5 px-4 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition">
                    @error('name') <p class="text-red-400 text-xs mt-1.5">{{ $message }}</p> @enderror
                </div>

                {{-- Owner & Email --}}
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-semibold text-slate-300 mb-2">Owner Name</label>
                        <input wire:model="owner" type="text" placeholder="John Doe"
                               class="w-full bg-slate-800/50 border border-slate-700 rounded-lg py-2.5 px-4 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-300 mb-2">Email</label>
                        <input wire:model="email" type="email" placeholder="company@example.com"
                               class="w-full bg-slate-800/50 border border-slate-700 rounded-lg py-2.5 px-4 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition">
                        @error('email') <p class="text-red-400 text-xs mt-1.5">{{ $message }}</p> @enderror
                    </div>
                </div>

                {{-- Phone & Country --}}
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-semibold text-slate-300 mb-2">Phone</label>
                        <input wire:model="phone" type="text" placeholder="+92 300 1234567"
                               class="w-full bg-slate-800/50 border border-slate-700 rounded-lg py-2.5 px-4 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-300 mb-2">Country</label>
                        <input wire:model="country" type="text" placeholder="Pakistan"
                               class="w-full bg-slate-800/50 border border-slate-700 rounded-lg py-2.5 px-4 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition">
                    </div>
                </div>

                {{-- Currency & Symbol --}}
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-semibold text-slate-300 mb-2">Currency *</label>
                        <select wire:model.live="currency"
                                class="w-full bg-slate-800/50 border border-slate-700 rounded-lg py-2.5 px-4 text-sm text-white focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition">
                            @foreach($currencies as $code => $symbol)
                                <option value="{{ $code }}">{{ $code }} ({{ $symbol }})</option>
                            @endforeach
                        </select>
                        @error('currency') <p class="text-red-400 text-xs mt-1.5">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-300 mb-2">Currency Symbol *</label>
                        <input wire:model="currency_symbol" type="text" placeholder="₨"
                               class="w-full bg-slate-800/50 border border-slate-700 rounded-lg py-2.5 px-4 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition">
                        @error('currency_symbol') <p class="text-red-400 text-xs mt-1.5">{{ $message }}</p> @enderror
                    </div>
                </div>

                {{-- Timezone --}}
                <div>
                    <label class="block text-xs font-semibold text-slate-300 mb-2">Timezone</label>
                    <select wire:model="timezone"
                            class="w-full bg-slate-800/50 border border-slate-700 rounded-lg py-2.5 px-4 text-sm text-white focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition">
                        @foreach($timezones as $tz)
                            <option value="{{ $tz }}">{{ $tz }}</option>
                        @endforeach
                    </select>
                </div>

                {{-- VAT Number --}}
                <div>
                    <label class="block text-xs font-semibold text-slate-300 mb-2">VAT / Tax Number</label>
                    <input wire:model="vat_number" type="text" placeholder="Optional"
                           class="w-full bg-slate-800/50 border border-slate-700 rounded-lg py-2.5 px-4 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition">
                </div>

                {{-- Address --}}
                <div>
                    <label class="block text-xs font-semibold text-slate-300 mb-2">Address</label>
                    <textarea wire:model="address" rows="2" placeholder="Company address..."
                              class="w-full bg-slate-800/50 border border-slate-700 rounded-lg py-2.5 px-4 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition resize-none"></textarea>
                </div>

                {{-- Logo --}}
                <div>
                    <label class="block text-xs font-semibold text-slate-300 mb-2">Company Logo</label>
                    <input wire:model="logo" type="file" accept="image/*"
                           class="w-full text-sm text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-indigo-500/10 file:text-indigo-400 hover:file:bg-indigo-500/20 transition">
                    @error('logo') <p class="text-red-400 text-xs mt-1.5">{{ $message }}</p> @enderror
                    <div wire:loading wire:target="logo" class="text-xs text-indigo-400 mt-1">Uploading...</div>
                </div>

                {{-- Submit --}}
                <div class="flex items-center justify-between pt-2">
                    @if(\App\Models\Company::count() > 0)
                        <a href="{{ route('company.select') }}" class="text-sm text-slate-400 hover:text-slate-300 transition">← Back to companies</a>
                    @else
                        <span></span>
                    @endif
                    <button type="submit" class="btn btn-primary btn-lg relative overflow-hidden group">
                        <span wire:loading.remove wire:target="save">Create Company</span>
                        <span wire:loading wire:target="save" class="flex items-center gap-2">
                            <div class="spinner !w-4 !h-4 !border-white/30 !border-t-white"></div>
                            Creating...
                        </span>
                    </button>
                </div>
            </form>
        </div>

        {{-- Sign Out --}}
        <div class="mt-6 text-center">
            <form method="POST" action="{{ route('admin.logout') }}">
                @csrf
                <button type="submit" class="text-sm text-slate-500 hover:text-red-400 transition">Sign out</button>
            </form>
        </div>
    </div>
</div>
