<div>
    <div class="mb-6"><h1 class="text-2xl font-bold" style="color: var(--text-primary);">Settings</h1></div>
    <div class="flex gap-1 border-b mb-6" style="border-color: var(--border-color);">
        <button wire:click="$set('tab','company')" class="tab-link {{ $tab==='company'?'active':'' }}">Company</button>
        <button wire:click="$set('tab','system')" class="tab-link {{ $tab==='system'?'active':'' }}">System</button>
        <button wire:click="$set('tab','notifications')" class="tab-link {{ $tab==='notifications'?'active':'' }}">Notifications</button>
    </div>

    @if($tab === 'company')
    <form wire:submit="saveCompany">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div class="lg:col-span-2">
                <div class="card p-5">
                    <h3 class="text-sm font-semibold mb-4" style="color: var(--text-primary);">Company Information</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div><label class="form-label">Company Name *</label><input wire:model="name" type="text" class="form-input">@error('name')<span class="text-red-500 text-xs">{{ $message }}</span>@enderror</div>
                        <div><label class="form-label">Owner Name</label><input wire:model="owner" type="text" class="form-input"></div>
                        <div><label class="form-label">Email</label><input wire:model="email" type="email" class="form-input"></div>
                        <div><label class="form-label">Phone</label><input wire:model="phone" type="text" class="form-input"></div>
                        <div><label class="form-label">Country</label><input wire:model="country" type="text" class="form-input"></div>
                        <div><label class="form-label">VAT/NTN Number</label><input wire:model="vat_number" type="text" class="form-input"></div>
                        <div><label class="form-label">Currency Code *</label><input wire:model="currency" type="text" class="form-input" placeholder="PKR">@error('currency')<span class="text-red-500 text-xs">{{ $message }}</span>@enderror</div>
                        <div><label class="form-label">Currency Symbol *</label><input wire:model="currency_symbol" type="text" class="form-input" placeholder="₨">@error('currency_symbol')<span class="text-red-500 text-xs">{{ $message }}</span>@enderror</div>
                        <div><label class="form-label">Timezone</label><select wire:model="timezone" class="form-select"><option value="Asia/Karachi">Asia/Karachi</option><option value="UTC">UTC</option><option value="Asia/Dubai">Asia/Dubai</option><option value="America/New_York">America/New_York</option><option value="Europe/London">Europe/London</option></select></div>
                        <div><label class="form-label">Logo</label><input wire:model="logo" type="file" accept="image/*" class="form-input"></div>
                    </div>
                    <div class="mt-4"><label class="form-label">Address</label><textarea wire:model="address" class="form-input" rows="2"></textarea></div>
                </div>
            </div>
            <div><div class="card p-5"><button type="submit" class="btn btn-primary w-full justify-center btn-lg"><span wire:loading.remove wire:target="saveCompany">Save Company</span><span wire:loading wire:target="saveCompany"><div class="spinner !w-4 !h-4 !border-white/30 !border-t-white"></div></span></button></div></div>
        </div>
    </form>
    @elseif($tab === 'system')
    <form wire:submit="saveSettings">
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
            @foreach($allCompanySettings->groupBy('group') as $group => $groupSettings)
            <div class="card p-5">
                <h3 class="text-sm font-semibold mb-4 capitalize" style="color: var(--text-primary);">{{ str_replace('_',' ',$group) }}</h3>
                <div class="space-y-3">
                    @foreach($groupSettings as $setting)
                    <div>
                        <label class="form-label">{{ str_replace('_',' ',ucfirst($setting->key)) }}</label>
                        @if($setting->type === 'boolean')
                        <select wire:model="settings.{{ $setting->key }}" class="form-select"><option value="on">On</option><option value="off">Off</option></select>
                        @elseif($setting->type === 'textarea')
                        <textarea wire:model="settings.{{ $setting->key }}" class="form-input" rows="3"></textarea>
                        @else
                        <input wire:model="settings.{{ $setting->key }}" type="text" class="form-input">
                        @endif
                    </div>
                    @endforeach
                </div>
            </div>
            @endforeach
        </div>
        <div class="mt-4"><button type="submit" class="btn btn-primary">Save Settings</button></div>
    </form>
    @elseif($tab === 'notifications')
    <form wire:submit="saveSettings">
        <div class="card p-5 max-w-lg">
            <h3 class="text-sm font-semibold mb-4" style="color: var(--text-primary);">Email Notifications</h3>
            <div class="space-y-4">
                <div class="flex items-center justify-between"><div><p class="text-sm font-medium" style="color: var(--text-primary);">Email Notifications</p><p class="text-xs" style="color: var(--text-muted);">Master switch for all email alerts</p></div><select wire:model="settings.email_notifications" class="form-select w-28"><option value="on">On</option><option value="off">Off</option></select></div>
                <div class="flex items-center justify-between"><div><p class="text-sm font-medium" style="color: var(--text-primary);">Invoice Email</p><p class="text-xs" style="color: var(--text-muted);">Send email when invoice is created/sent</p></div><select wire:model="settings.email_on_invoice" class="form-select w-28"><option value="on">On</option><option value="off">Off</option></select></div>
                <div class="flex items-center justify-between"><div><p class="text-sm font-medium" style="color: var(--text-primary);">Payment Receipt Email</p><p class="text-xs" style="color: var(--text-muted);">Send receipt when payment is recorded</p></div><select wire:model="settings.email_on_payment" class="form-select w-28"><option value="on">On</option><option value="off">Off</option></select></div>
                <div class="flex items-center justify-between"><div><p class="text-sm font-medium" style="color: var(--text-primary);">Low Stock Alert</p><p class="text-xs" style="color: var(--text-muted);">Send alert when stock is low</p></div><select wire:model="settings.email_on_low_stock" class="form-select w-28"><option value="on">On</option><option value="off">Off</option></select></div>
            </div>
            <div class="mt-5"><button type="submit" class="btn btn-primary">Save Notification Settings</button></div>
        </div>
    </form>
    @endif
</div>
