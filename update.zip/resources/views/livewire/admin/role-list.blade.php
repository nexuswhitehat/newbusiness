<div>
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold" style="color: var(--text-primary);">Roles & Permissions</h1>
        <a href="{{ route('admin.roles.create', $company->slug) }}" class="btn btn-primary">+ Create Role</a>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        @forelse($roles as $role)
        <div class="card p-5">
            <div class="flex items-start justify-between mb-3">
                <div>
                    <h3 class="font-semibold" style="color: var(--text-primary);">{{ $role->name }}</h3>
                    <p class="text-xs mt-1" style="color: var(--text-muted);">{{ $role->admins_count }} {{ Str::plural('user', $role->admins_count) }}</p>
                </div>
                @if($role->is_system ?? false)
                <span class="badge badge-indigo">System</span>
                @else
                <div class="flex gap-1">
                    <a href="{{ route('admin.roles.edit', [$company->slug, $role->id]) }}" class="btn btn-ghost btn-xs">Edit</a>
                    <button wire:click="confirmDelete({{ $role->id }})" class="btn btn-ghost btn-xs text-red-500">Del</button>
                </div>
                @endif
            </div>
            @if($role->description)<p class="text-xs mb-3" style="color: var(--text-muted);">{{ $role->description }}</p>@endif
            <div class="flex flex-wrap gap-1">
                @foreach($role->permissions->take(5) as $perm)
                <span class="badge badge-gray text-[10px]">{{ $perm->action }}</span>
                @endforeach
                @if($role->permissions->count() > 5)
                <span class="badge badge-gray text-[10px]">+{{ $role->permissions->count() - 5 }} more</span>
                @endif
            </div>
        </div>
        @empty
        <div class="col-span-full text-center py-12" style="color: var(--text-muted);">No roles configured.</div>
        @endforelse
    </div>
    @if($showDeleteModal)
    <div class="modal-backdrop" wire:click.self="$set('showDeleteModal', false)">
        <div class="modal-content max-w-sm p-6">
            <h3 class="text-lg font-semibold mb-2" style="color: var(--text-primary);">Delete Role?</h3>
            <div class="flex gap-3 justify-end mt-4">
                <button wire:click="$set('showDeleteModal', false)" class="btn btn-secondary">Cancel</button>
                <button wire:click="delete" class="btn btn-danger">Delete</button>
            </div>
        </div>
    </div>
    @endif
</div>
