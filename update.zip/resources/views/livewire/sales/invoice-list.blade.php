<div>
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
        <div>
            <h1 class="text-2xl font-bold" style="color: var(--text-primary);">Invoices</h1>
            <p class="text-sm mt-1" style="color: var(--text-muted);">Manage sales invoices and billing</p>
        </div>
        <a href="{{ route('invoices.create', $company->slug) }}" class="btn btn-primary mt-3 sm:mt-0">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
            Create Invoice
        </a>
    </div>

    {{-- Summary KPIs --}}
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-5">
        <div class="stat-card stat-card-purple">
            <p class="text-xs font-semibold mb-1" style="color: var(--text-muted);">Total Revenue</p>
            <p class="text-2xl font-bold" style="color: var(--text-primary);">{{ $company->currency_symbol }} {{ number_format($totalRevenue, 2) }}</p>
        </div>
        <div class="stat-card stat-card-red">
            <p class="text-xs font-semibold mb-1" style="color: var(--text-muted);">Total Outstanding</p>
            <p class="text-2xl font-bold text-red-500">{{ $company->currency_symbol }} {{ number_format($totalDue, 2) }}</p>
        </div>
        <div class="stat-card stat-card-orange">
            <p class="text-xs font-semibold mb-1" style="color: var(--text-muted);">Overdue Invoices</p>
            <p class="text-2xl font-bold text-amber-500">{{ $overdueCount }}</p>
        </div>
    </div>

    {{-- Filters --}}
    <div class="card p-4 mb-4">
        <div class="flex flex-wrap gap-3">
            <div class="flex-1 min-w-[200px]">
                <input wire:model.live.debounce.300ms="search" type="text" placeholder="Search by invoice# or customer..." class="form-input">
            </div>
            <select wire:model.live="status" class="form-select w-auto">
                <option value="">All Status</option>
                <option value="draft">Draft</option>
                <option value="sent">Sent</option>
                <option value="partial">Partial</option>
                <option value="paid">Paid</option>
                <option value="overdue">Overdue</option>
                <option value="cancelled">Cancelled</option>
            </select>
            <input wire:model.live="dateFrom" type="date" class="form-input w-auto" title="From">
            <input wire:model.live="dateTo" type="date" class="form-input w-auto" title="To">
        </div>
    </div>

    {{-- Table --}}
    <div class="card overflow-x-auto">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Invoice #</th>
                    <th>Customer</th>
                    <th>Date</th>
                    <th>Due Date</th>
                    <th>Total</th>
                    <th>Paid</th>
                    <th>Due</th>
                    <th>Status</th>
                    <th class="text-right">Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($invoices as $inv)
                @php $statusColors = ['draft'=>'badge-gray','sent'=>'badge-blue','partial'=>'badge-orange','paid'=>'badge-green','overdue'=>'badge-red','cancelled'=>'badge-gray']; @endphp
                <tr>
                    <td><a href="{{ route('invoices.show', [$company->slug, $inv->id]) }}" class="font-mono text-indigo-500 hover:text-indigo-400 font-medium">{{ $inv->invoice_no }}</a></td>
                    <td>
                        <p style="color: var(--text-primary);" class="font-medium">{{ $inv->customer->customer_name ?? 'N/A' }}</p>
                    </td>
                    <td class="text-sm">{{ $inv->invoice_date->format('d M Y') }}</td>
                    <td class="text-sm {{ $inv->due_date && $inv->due_date->isPast() && $inv->status != 'paid' ? 'text-red-500 font-semibold' : '' }}">{{ $inv->due_date ? $inv->due_date->format('d M Y') : '-' }}</td>
                    <td class="font-semibold">{{ $company->currency_symbol }} {{ number_format($inv->grand_total, 2) }}</td>
                    <td class="text-emerald-500">{{ $company->currency_symbol }} {{ number_format($inv->paid_amount, 2) }}</td>
                    <td class="{{ $inv->due_amount > 0 ? 'text-red-500 font-semibold' : 'text-emerald-500' }}">{{ $company->currency_symbol }} {{ number_format($inv->due_amount, 2) }}</td>
                    <td><span class="badge {{ $statusColors[$inv->status] ?? 'badge-gray' }}">{{ ucfirst($inv->status) }}</span></td>
                    <td class="text-right">
                        <div class="flex items-center justify-end gap-1">
                            <a href="{{ route('invoices.show', [$company->slug, $inv->id]) }}" class="btn btn-ghost btn-xs">View</a>
                            <a href="{{ route('invoices.pdf', [$company->slug, $inv->id]) }}" target="_blank" class="btn btn-ghost btn-xs">PDF</a>
                            @if($inv->status === 'draft')
                                <a href="{{ route('invoices.edit', [$company->slug, $inv->id]) }}" class="btn btn-ghost btn-xs">Edit</a>
                                <button wire:click="confirmDelete({{ $inv->id }})" class="btn btn-ghost btn-xs text-red-500">Del</button>
                            @endif
                        </div>
                    </td>
                </tr>
                @empty
                <tr><td colspan="9" class="text-center py-10" style="color: var(--text-muted);">No invoices found. Create your first invoice!</td></tr>
                @endforelse
            </tbody>
        </table>
        <div class="px-4 py-3 pagination-wrapper">{{ $invoices->links() }}</div>
    </div>

    @if($showDeleteModal)
    <div class="modal-backdrop" wire:click.self="$set('showDeleteModal', false)">
        <div class="modal-content max-w-sm p-6">
            <h3 class="text-lg font-semibold mb-2" style="color: var(--text-primary);">Delete Invoice?</h3>
            <p class="text-sm mb-5" style="color: var(--text-secondary);">This cannot be undone. Only draft invoices can be deleted.</p>
            <div class="flex gap-3 justify-end">
                <button wire:click="$set('showDeleteModal', false)" class="btn btn-secondary">Cancel</button>
                <button wire:click="delete" class="btn btn-danger">Delete</button>
            </div>
        </div>
    </div>
    @endif
</div>
