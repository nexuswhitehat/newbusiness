<div>
    {{-- Header --}}
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
        <div class="flex items-center gap-3">
            <a href="{{ route('invoices.index', $company->slug) }}" class="btn btn-ghost btn-sm"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg></a>
            <div>
                <h1 class="text-2xl font-bold" style="color: var(--text-primary);">{{ $invoice->invoice_no }}</h1>
                <p class="text-sm" style="color: var(--text-muted);">Created {{ $invoice->invoice_date->format('d M Y') }}</p>
            </div>
        </div>
        <div class="flex flex-wrap gap-2 mt-3 sm:mt-0">
            @if($invoice->status === 'draft')
                <button wire:click="markAsSent" class="btn btn-secondary btn-sm">Mark as Sent</button>
                <a href="{{ route('invoices.edit', [$company->slug, $invoice->id]) }}" class="btn btn-secondary btn-sm">Edit</a>
            @endif
            @if(in_array($invoice->status, ['sent','partial','overdue']))
                <button wire:click="$set('showPaymentModal', true)" class="btn btn-success btn-sm">+ Record Payment</button>
            @endif
            <a href="{{ route('invoices.pdf', [$company->slug, $invoice->id]) }}" target="_blank" class="btn btn-secondary btn-sm">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                Download PDF
            </a>
            <a href="{{ route('invoices.print', [$company->slug, $invoice->id]) }}" target="_blank" class="btn btn-secondary btn-sm">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/></svg>
                Print
            </a>
        </div>
    </div>

    {{-- Status + Summary --}}
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div class="stat-card"><p class="text-xs" style="color: var(--text-muted);">Status</p>
            @php $sc = ['draft'=>'badge-gray','sent'=>'badge-blue','partial'=>'badge-orange','paid'=>'badge-green','overdue'=>'badge-red','cancelled'=>'badge-gray']; @endphp
            <span class="badge {{ $sc[$invoice->status] ?? 'badge-gray' }} mt-2 text-sm">{{ ucfirst($invoice->status) }}</span>
        </div>
        <div class="stat-card"><p class="text-xs" style="color: var(--text-muted);">Grand Total</p><p class="text-xl font-bold mt-1" style="color: var(--text-primary);">{{ $company->currency_symbol }} {{ number_format($invoice->grand_total, 2) }}</p></div>
        <div class="stat-card"><p class="text-xs" style="color: var(--text-muted);">Paid</p><p class="text-xl font-bold text-emerald-500 mt-1">{{ $company->currency_symbol }} {{ number_format($invoice->paid_amount, 2) }}</p></div>
        <div class="stat-card"><p class="text-xs" style="color: var(--text-muted);">Outstanding</p><p class="text-xl font-bold text-red-500 mt-1">{{ $company->currency_symbol }} {{ number_format($invoice->due_amount, 2) }}</p></div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {{-- Invoice Preview --}}
        <div class="lg:col-span-2">
            <div class="card p-6">
                {{-- Invoice Header --}}
                <div class="flex flex-col sm:flex-row justify-between mb-8">
                    <div>
                        <h2 class="text-2xl font-bold text-indigo-500">INVOICE</h2>
                        <p class="text-lg font-mono font-semibold mt-1" style="color: var(--text-primary);">{{ $invoice->invoice_no }}</p>
                    </div>
                    <div class="text-sm text-right mt-4 sm:mt-0">
                        <p class="font-bold text-base" style="color: var(--text-primary);">{{ $company->name }}</p>
                        <p style="color: var(--text-muted);">{{ $company->email }}</p>
                        <p style="color: var(--text-muted);">{{ $company->phone }}</p>
                    </div>
                </div>

                {{-- Bill To / Dates --}}
                <div class="grid grid-cols-2 gap-6 mb-6">
                    <div>
                        <p class="text-xs font-bold uppercase tracking-wide mb-2" style="color: var(--text-muted);">Bill To</p>
                        <p class="font-semibold" style="color: var(--text-primary);">{{ $invoice->customer->customer_name ?? 'N/A' }}</p>
                        @if($invoice->customer->company_name)<p class="text-sm" style="color: var(--text-secondary);">{{ $invoice->customer->company_name }}</p>@endif
                        @if($invoice->customer->billing_address)<p class="text-xs mt-1" style="color: var(--text-muted);">{{ $invoice->customer->billing_address }}</p>@endif
                    </div>
                    <div class="text-sm">
                        <div class="flex justify-between mb-1"><span style="color: var(--text-muted);">Invoice Date:</span><span style="color: var(--text-primary);">{{ $invoice->invoice_date->format('d M Y') }}</span></div>
                        @if($invoice->due_date)<div class="flex justify-between mb-1"><span style="color: var(--text-muted);">Due Date:</span><span class="{{ $invoice->due_date->isPast() && $invoice->status != 'paid' ? 'text-red-500 font-semibold' : '' }}" style="color: var(--text-primary);">{{ $invoice->due_date->format('d M Y') }}</span></div>@endif
                        @if($invoice->reference)<div class="flex justify-between"><span style="color: var(--text-muted);">Reference:</span><span style="color: var(--text-primary);">{{ $invoice->reference }}</span></div>@endif
                    </div>
                </div>

                {{-- Line Items --}}
                <div class="overflow-x-auto">
                    <table class="data-table">
                        <thead><tr><th>#</th><th>Description</th><th class="text-center">Qty</th><th class="text-right">Price</th><th class="text-center">Disc%</th><th class="text-right">Total</th></tr></thead>
                        <tbody>
                            @foreach($invoice->items as $i => $item)
                            <tr>
                                <td class="text-xs" style="color: var(--text-muted);">{{ $i+1 }}</td>
                                <td>
                                    <p style="color: var(--text-primary);" class="font-medium">{{ $item->description }}</p>
                                    @if($item->product)<p class="text-xs" style="color: var(--text-muted);">SKU: {{ $item->product->sku }}</p>@endif
                                </td>
                                <td class="text-center">{{ $item->qty }}</td>
                                <td class="text-right">{{ $company->currency_symbol }} {{ number_format($item->unit_price, 2) }}</td>
                                <td class="text-center">{{ $item->discount > 0 ? $item->discount.'%' : '-' }}</td>
                                <td class="text-right font-semibold" style="color: var(--text-primary);">{{ $company->currency_symbol }} {{ number_format($item->total, 2) }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>

                {{-- Totals --}}
                <div class="flex justify-end mt-4">
                    <div class="w-full max-w-xs space-y-2 text-sm">
                        <div class="flex justify-between"><span style="color: var(--text-muted);">Subtotal</span><span style="color: var(--text-primary);">{{ $company->currency_symbol }} {{ number_format($invoice->subtotal, 2) }}</span></div>
                        @if($invoice->discount_amount > 0)
                        <div class="flex justify-between text-red-500"><span>Discount</span><span>- {{ $company->currency_symbol }} {{ number_format($invoice->discount_amount, 2) }}</span></div>
                        @endif
                        @if($invoice->tax_amount > 0)
                        <div class="flex justify-between" style="color: var(--text-secondary);"><span>Tax ({{ $invoice->tax_rate }}%)</span><span>+ {{ $company->currency_symbol }} {{ number_format($invoice->tax_amount, 2) }}</span></div>
                        @endif
                        <div class="flex justify-between font-bold text-base pt-2 border-t" style="border-color: var(--border-color);"><span style="color: var(--text-primary);">Grand Total</span><span class="text-indigo-500">{{ $company->currency_symbol }} {{ number_format($invoice->grand_total, 2) }}</span></div>
                    </div>
                </div>

                @if($invoice->notes)
                <div class="mt-6 pt-4 border-t text-sm" style="border-color: var(--border-color);"><p class="font-semibold mb-1" style="color: var(--text-primary);">Notes:</p><p style="color: var(--text-muted);">{{ $invoice->notes }}</p></div>
                @endif
                @if($invoice->terms)
                <div class="mt-3 text-sm"><p class="font-semibold mb-1" style="color: var(--text-primary);">Terms:</p><p style="color: var(--text-muted);">{{ $invoice->terms }}</p></div>
                @endif
            </div>
        </div>

        {{-- Sidebar: Payments --}}
        <div class="space-y-4">
            <div class="card p-5">
                <h3 class="text-sm font-semibold mb-4" style="color: var(--text-primary);">Payments Received</h3>
                @forelse($invoice->payments as $pay)
                <div class="flex justify-between items-start py-2 border-b last:border-0" style="border-color: var(--border-light);">
                    <div>
                        <p class="text-sm font-medium" style="color: var(--text-primary);">{{ $company->currency_symbol }} {{ number_format($pay->amount, 2) }}</p>
                        <p class="text-xs" style="color: var(--text-muted);">{{ $pay->payment_date->format('d M Y') }}</p>
                        <span class="badge badge-blue">{{ ucfirst(str_replace('_',' ',$pay->payment_method)) }}</span>
                    </div>
                    <span class="text-xs font-mono" style="color: var(--text-muted);">{{ $pay->payment_no }}</span>
                </div>
                @empty
                <p class="text-sm text-center py-4" style="color: var(--text-muted);">No payments yet</p>
                @endforelse
            </div>
        </div>
    </div>

    {{-- Payment Modal --}}
    @if($showPaymentModal)
    <div class="modal-backdrop" wire:click.self="$set('showPaymentModal', false)">
        <div class="modal-content max-w-md p-6">
            <h3 class="text-lg font-semibold mb-5" style="color: var(--text-primary);">Record Payment</h3>
            <div class="space-y-4">
                <div class="p-3 rounded-lg" style="background: var(--bg-hover);">
                    <p class="text-xs" style="color: var(--text-muted);">Outstanding Amount</p>
                    <p class="text-2xl font-bold text-red-500">{{ $company->currency_symbol }} {{ number_format($invoice->due_amount, 2) }}</p>
                </div>
                <div class="grid grid-cols-2 gap-3">
                    <div><label class="form-label">Payment Date *</label><input wire:model="payment_date" type="date" class="form-input">@error('payment_date')<span class="text-red-500 text-xs">{{ $message }}</span>@enderror</div>
                    <div><label class="form-label">Amount *</label><input wire:model="payment_amount" type="number" step="0.01" min="0.01" class="form-input">@error('payment_amount')<span class="text-red-500 text-xs">{{ $message }}</span>@enderror</div>
                    <div class="col-span-2"><label class="form-label">Payment Method *</label>
                        <select wire:model="payment_method" class="form-select"><option value="cash">Cash</option><option value="bank_transfer">Bank Transfer</option><option value="cheque">Cheque</option><option value="card">Card</option><option value="online">Online</option></select>
                    </div>
                    <div><label class="form-label">Reference</label><input wire:model="payment_reference" type="text" class="form-input" placeholder="Cheque#, TID..."></div>
                    <div><label class="form-label">Notes</label><input wire:model="payment_notes" type="text" class="form-input"></div>
                </div>
                <div class="flex gap-3 pt-2">
                    <button wire:click="$set('showPaymentModal', false)" class="btn btn-secondary flex-1">Cancel</button>
                    <button wire:click="recordPayment" class="btn btn-success flex-1">
                        <span wire:loading.remove wire:target="recordPayment">Record Payment</span>
                        <span wire:loading wire:target="recordPayment"><div class="spinner !w-4 !h-4 !border-white/30 !border-t-white"></div></span>
                    </button>
                </div>
            </div>
        </div>
    </div>
    @endif
</div>
