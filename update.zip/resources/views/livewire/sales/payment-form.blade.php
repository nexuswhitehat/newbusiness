<div>
    <div class="flex items-center gap-3 mb-6">
        <a href="{{ route('payments.index', $company->slug) }}" class="btn btn-ghost btn-sm"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg></a>
        <h1 class="text-2xl font-bold" style="color: var(--text-primary);">Record Payment</h1>
    </div>
    <form wire:submit="save">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div class="lg:col-span-2">
                <div class="card p-5 space-y-4">
                    <div><label class="form-label">Customer *</label><select wire:model.live="customer_id" class="form-select"><option value="">Select customer...</option>@foreach($customers as $c)<option value="{{ $c->id }}">{{ $c->customer_name }}{{ $c->company_name?' — '.$c->company_name:'' }}</option>@endforeach</select>@error('customer_id')<span class="text-red-500 text-xs">{{ $message }}</span>@enderror</div>
                    @if(!empty($customerInvoices))<div><label class="form-label">Apply to Invoice</label><select wire:model.live="invoice_id" class="form-select"><option value="">General Payment</option>@foreach($customerInvoices as $inv)<option value="{{ $inv['id'] }}">{{ $inv['invoice_no'] }} — Due: {{ $company->currency_symbol }} {{ number_format($inv['due_amount'],2) }}</option>@endforeach</select></div>@endif
                    <div class="grid grid-cols-2 gap-4">
                        <div><label class="form-label">Payment Date *</label><input wire:model="payment_date" type="date" class="form-input">@error('payment_date')<span class="text-red-500 text-xs">{{ $message }}</span>@enderror</div>
                        <div><label class="form-label">Amount ({{ $company->currency_symbol }}) *</label><input wire:model="amount" type="number" step="0.01" class="form-input">@error('amount')<span class="text-red-500 text-xs">{{ $message }}</span>@enderror</div>
                    </div>
                    <div><label class="form-label">Payment Method *</label><select wire:model="payment_method" class="form-select"><option value="cash">Cash</option><option value="bank_transfer">Bank Transfer</option><option value="cheque">Cheque</option><option value="card">Card</option><option value="online">Online</option></select></div>
                    <div><label class="form-label">Reference</label><input wire:model="reference" type="text" class="form-input" placeholder="Cheque#, Transaction ID..."></div>
                    <div><label class="form-label">Notes</label><textarea wire:model="notes" class="form-input" rows="2"></textarea></div>
                </div>
            </div>
            <div><div class="card p-5"><button type="submit" class="btn btn-success w-full justify-center btn-lg"><span wire:loading.remove wire:target="save">Record Payment</span><span wire:loading wire:target="save"><div class="spinner !w-4 !h-4 !border-white/30 !border-t-white"></div></span></button></div></div>
        </div>
    </form>
</div>
