<div>
    <div class="flex items-center gap-3 mb-6">
        <a href="{{ route('quotations.index', $company->slug) }}" class="btn btn-ghost btn-sm"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg></a>
        <h1 class="text-2xl font-bold" style="color: var(--text-primary);">{{ $editing ? 'Edit Quotation' : 'Create Quotation' }}</h1>
    </div>
    <form wire:submit="save">
        <div class="grid grid-cols-1 xl:grid-cols-4 gap-6">
            <div class="xl:col-span-3 space-y-5">
                <div class="card p-5">
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div class="md:col-span-1"><label class="form-label">Customer *</label><select wire:model.live="customer_id" class="form-select"><option value="">Select...</option>@foreach($customers as $c)<option value="{{ $c->id }}">{{ $c->customer_name }}</option>@endforeach</select>@error('customer_id')<span class="text-red-500 text-xs">{{ $message }}</span>@enderror</div>
                        <div><label class="form-label">Date *</label><input wire:model="quotation_date" type="date" class="form-input"></div>
                        <div><label class="form-label">Valid Until</label><input wire:model="valid_until" type="date" class="form-input"></div>
                        <div><label class="form-label">Status</label><select wire:model="status" class="form-select"><option value="draft">Draft</option><option value="sent">Sent</option><option value="accepted">Accepted</option><option value="rejected">Rejected</option></select></div>
                    </div>
                </div>
                <div class="card p-5">
                    <div class="flex items-center justify-between mb-4"><h3 class="text-sm font-semibold" style="color: var(--text-primary);">Line Items</h3><button type="button" wire:click="addItem" class="btn btn-secondary btn-sm">+ Add</button></div>
                    @foreach($items as $i => $item)
                    <div class="grid grid-cols-12 gap-2 items-start p-3 rounded-lg mb-2" style="background: var(--bg-hover);">
                        <div class="col-span-12 md:col-span-4"><select wire:model.live="items.{{ $i }}.product_id" wire:change="productSelected({{ $i }})" class="form-select text-xs mb-1"><option value="">Product...</option>@foreach($products as $p)<option value="{{ $p->id }}">{{ $p->name }}</option>@endforeach</select><input wire:model="items.{{ $i }}.description" type="text" class="form-input text-xs" placeholder="Description *">@error("items.$i.description")<span class="text-red-500 text-xs">{{ $message }}</span>@enderror</div>
                        <div class="col-span-3 md:col-span-2"><input wire:model.live="items.{{ $i }}.qty" type="number" step="0.01" min="0.01" class="form-input text-xs text-center" placeholder="Qty"></div>
                        <div class="col-span-3 md:col-span-2"><input wire:model.live="items.{{ $i }}.unit_price" type="number" step="0.01" min="0" class="form-input text-xs text-center" placeholder="Price"></div>
                        <div class="col-span-2 md:col-span-1"><input wire:model.live="items.{{ $i }}.discount" type="number" step="0.1" min="0" max="100" class="form-input text-xs text-center" placeholder="%"></div>
                        <div class="col-span-3 md:col-span-2 flex items-center justify-end"><span class="text-sm font-semibold" style="color: var(--text-primary);">{{ $company->currency_symbol }} {{ number_format($item['total']??0,2) }}</span></div>
                        <div class="col-span-1 flex justify-end"><button type="button" wire:click="removeItem({{ $i }})" class="btn btn-ghost btn-xs text-red-500">✕</button></div>
                    </div>
                    @endforeach
                </div>
            </div>
            <div class="xl:col-span-1 space-y-4">
                <div class="card p-5">
                    <h3 class="text-sm font-semibold mb-4" style="color: var(--text-primary);">Summary</h3>
                    <div class="space-y-3 text-sm">
                        <div class="flex justify-between"><span style="color: var(--text-muted);">Subtotal</span><span>{{ $company->currency_symbol }} {{ number_format($subtotal,2) }}</span></div>
                        <div><label class="form-label">Discount %</label><input wire:model.live="discount_value" type="number" step="0.1" min="0" class="form-input text-sm"></div>
                        <div><label class="form-label">Tax %</label><input wire:model.live="tax_rate" type="number" step="0.1" min="0" class="form-input text-sm"></div>
                        <div class="border-t pt-3" style="border-color: var(--border-color);"><div class="flex justify-between font-bold"><span style="color: var(--text-primary);">Total</span><span class="text-indigo-500 text-xl">{{ $company->currency_symbol }} {{ number_format($grand_total,2) }}</span></div></div>
                    </div>
                </div>
                <div class="card p-5 space-y-3">
                    <button type="submit" class="btn btn-primary w-full justify-center btn-lg"><span wire:loading.remove wire:target="save">{{ $editing ? 'Update' : 'Create Quotation' }}</span><span wire:loading wire:target="save"><div class="spinner !w-4 !h-4 !border-white/30 !border-t-white"></div></span></button>
                    @if($editing && $quotation?->status === 'accepted')
                    <button type="button" wire:click="convertToInvoice" class="btn btn-success w-full justify-center">Convert to Invoice →</button>
                    @endif
                </div>
            </div>
        </div>
    </form>
</div>
