<div>
    <div class="flex items-center justify-between mb-6">
        <div><h1 class="text-2xl font-bold" style="color: var(--text-primary);">Quotations</h1></div>
        <a href="{{ route('quotations.create', $company->slug) }}" class="btn btn-primary"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg> New Quotation</a>
    </div>
    <div class="card p-4 mb-4"><div class="flex gap-3"><div class="flex-1"><input wire:model.live.debounce.300ms="search" type="text" placeholder="Search quotations..." class="form-input"></div><select wire:model.live="status" class="form-select w-40"><option value="">All Status</option><option value="draft">Draft</option><option value="sent">Sent</option><option value="accepted">Accepted</option><option value="rejected">Rejected</option><option value="converted">Converted</option></select></div></div>
    <div class="card overflow-x-auto">
        <table class="data-table"><thead><tr><th>Quotation#</th><th>Customer</th><th>Date</th><th>Valid Until</th><th>Amount</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody>
            @forelse($quotations as $q)
            @php $sc=['draft'=>'badge-gray','sent'=>'badge-blue','accepted'=>'badge-green','rejected'=>'badge-red','converted'=>'badge-purple']; @endphp
            <tr><td class="font-mono text-indigo-500 font-medium">{{ $q->quotation_no }}</td><td style="color: var(--text-primary);">{{ $q->customer->customer_name ?? '-' }}</td><td>{{ $q->quotation_date->format('d M Y') }}</td><td>{{ $q->valid_until?->format('d M Y') ?? '-' }}</td><td class="font-semibold">{{ $company->currency_symbol }} {{ number_format($q->grand_total,2) }}</td><td><span class="badge {{ $sc[$q->status]??'badge-gray' }}">{{ ucfirst($q->status) }}</span></td>
            <td><div class="flex gap-1"><a href="{{ route('quotations.edit',[$company->slug,$q->id]) }}" class="btn btn-ghost btn-xs">Edit</a><button wire:click="confirmDelete({{ $q->id }})" class="btn btn-ghost btn-xs text-red-500">Del</button></div></td></tr>
            @empty<tr><td colspan="7" class="text-center py-10" style="color: var(--text-muted);">No quotations found.</td></tr>@endforelse
        </tbody></table>
        <div class="px-4 py-3 pagination-wrapper">{{ $quotations->links() }}</div>
    </div>
    @if($showDeleteModal)<div class="modal-backdrop" wire:click.self="$set('showDeleteModal', false)"><div class="modal-content max-w-sm p-6"><h3 class="text-lg font-semibold mb-4" style="color: var(--text-primary);">Delete Quotation?</h3><div class="flex gap-3 justify-end"><button wire:click="$set('showDeleteModal', false)" class="btn btn-secondary">Cancel</button><button wire:click="delete" class="btn btn-danger">Delete</button></div></div></div>@endif
</div>
