<div>
    <div class="flex items-center gap-3 mb-6">
        <a href="{{ route('invoices.index', $company->slug) }}" class="btn btn-ghost btn-sm"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg></a>
        <h1 class="text-2xl font-bold" style="color: var(--text-primary);">{{ $editing ? 'Edit Invoice' : 'Create Invoice' }}</h1>
    </div>

    <form wire:submit="save">
        <div class="grid grid-cols-1 xl:grid-cols-4 gap-6">
            {{-- Main Invoice Area --}}
            <div class="xl:col-span-3 space-y-5">
                {{-- Header Info --}}
                <div class="card p-5">
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        <div class="md:col-span-2 lg:col-span-1">
                            <label class="form-label">Bill To (Customer) *</label>
                            <select wire:model.live="customer_id" class="form-select">
                                <option value="">Select customer...</option>
                                @foreach($customers as $c)
                                <option value="{{ $c->id }}">{{ $c->customer_name }}{{ $c->company_name ? ' — '.$c->company_name : '' }}</option>
                                @endforeach
                            </select>
                            @error('customer_id')<span class="text-red-500 text-xs">{{ $message }}</span>@enderror
                            {{-- Customer Preview --}}
                            @if($customer_id)
                            @php $sel = $customers->firstWhere('id', $customer_id); @endphp
                            @if($sel)
                            <div class="mt-2 p-3 rounded-lg text-xs" style="background: var(--bg-hover);">
                                <p class="font-semibold" style="color: var(--text-primary);">{{ $sel->customer_name }}</p>
                                @if($sel->company_name)<p style="color: var(--text-secondary);">{{ $sel->company_name }}</p>@endif
                                @if($sel->phone)<p style="color: var(--text-muted);">{{ $sel->phone }}</p>@endif
                                @if($sel->billing_address)<p style="color: var(--text-muted);">{{ $sel->billing_address }}</p>@endif
                            </div>
                            @endif
                            @endif
                        </div>
                        <div>
                            <label class="form-label">Invoice Date *</label>
                            <input wire:model="invoice_date" type="date" class="form-input">
                        </div>
                        <div>
                            <label class="form-label">Due Date</label>
                            <input wire:model="due_date" type="date" class="form-input">
                        </div>
                        <div>
                            <label class="form-label">Payment Terms</label>
                            <select wire:model="payment_terms" class="form-select">
                                <option value="immediate">Due Immediately</option>
                                <option value="net15">Net 15</option>
                                <option value="net30">Net 30</option>
                                <option value="net60">Net 60</option>
                                <option value="custom">Custom</option>
                            </select>
                        </div>
                        <div>
                            <label class="form-label">Reference / PO#</label>
                            <input wire:model="reference" type="text" class="form-input" placeholder="Customer PO#">
                        </div>
                        <div>
                            <label class="form-label">Status</label>
                            <select wire:model="status" class="form-select">
                                <option value="draft">Draft</option>
                                <option value="sent">Sent</option>
                            </select>
                        </div>
                    </div>
                </div>

                {{-- Line Items --}}
                <div class="card p-5">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-sm font-semibold" style="color: var(--text-primary);">Line Items</h3>
                        <button type="button" wire:click="addItem" class="btn btn-secondary btn-sm">+ Add Line</button>
                    </div>

                    {{-- Table Header --}}
                    <div class="hidden md:grid grid-cols-12 gap-2 mb-2 text-xs font-semibold px-1" style="color: var(--text-muted);">
                        <div class="col-span-4">Product / Description</div>
                        <div class="col-span-2 text-center">Qty</div>
                        <div class="col-span-2 text-center">Unit Price ({{ $company->currency_symbol }})</div>
                        <div class="col-span-1 text-center">Disc%</div>
                        <div class="col-span-2 text-right">Total</div>
                        <div class="col-span-1"></div>
                    </div>

                    <div class="space-y-2">
                        @foreach($items as $i => $item)
                        <div class="grid grid-cols-12 gap-2 items-start p-3 rounded-lg" style="background: var(--bg-hover);">
                            <div class="col-span-12 md:col-span-4">
                                <select wire:model.live="items.{{ $i }}.product_id" wire:change="productSelected({{ $i }})" class="form-select text-xs mb-1">
                                    <option value="">Select product...</option>
                                    @foreach($products as $p)
                                    <option value="{{ $p->id }}">{{ $p->name }} ({{ $p->sku }})</option>
                                    @endforeach
                                </select>
                                <input wire:model="items.{{ $i }}.description" type="text" class="form-input text-xs" placeholder="Description *">
                                @error("items.$i.description")<span class="text-red-500 text-xs">{{ $message }}</span>@enderror
                            </div>
                            <div class="col-span-4 md:col-span-2">
                                <label class="md:hidden form-label text-xs">Qty</label>
                                <input wire:model.live="items.{{ $i }}.qty" type="number" step="0.01" min="0.01" class="form-input text-xs text-center">
                                @error("items.$i.qty")<span class="text-red-500 text-xs">{{ $message }}</span>@enderror
                            </div>
                            <div class="col-span-4 md:col-span-2">
                                <label class="md:hidden form-label text-xs">Price ({{ $company->currency_symbol }})</label>
                                <input wire:model.live="items.{{ $i }}.unit_price" type="number" step="0.01" min="0" class="form-input text-xs text-center">
                                @error("items.$i.unit_price")<span class="text-red-500 text-xs">{{ $message }}</span>@enderror
                            </div>
                            <div class="col-span-2 md:col-span-1">
                                <label class="md:hidden form-label text-xs">Disc%</label>
                                <input wire:model.live="items.{{ $i }}.discount" type="number" step="0.1" min="0" max="100" class="form-input text-xs text-center">
                            </div>
                            <div class="col-span-2 md:col-span-2 flex items-center justify-end">
                                <span class="text-sm font-semibold" style="color: var(--text-primary);">{{ $company->currency_symbol }} {{ number_format($item['total'] ?? 0, 2) }}</span>
                            </div>
                            <div class="col-span-2 md:col-span-1 flex justify-end">
                                <button type="button" wire:click="removeItem({{ $i }})" class="btn btn-ghost btn-xs text-red-500">✕</button>
                            </div>
                        </div>
                        @endforeach
                    </div>
                    @error('items')<p class="text-red-500 text-xs mt-2">{{ $message }}</p>@enderror
                </div>

                {{-- Notes & Terms --}}
                <div class="card p-5">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div><label class="form-label">Notes (visible on invoice)</label><textarea wire:model="notes" class="form-input" rows="3"></textarea></div>
                        <div><label class="form-label">Terms & Conditions</label><textarea wire:model="terms" class="form-input" rows="3"></textarea></div>
                    </div>
                </div>
            </div>

            {{-- Right Sidebar: Totals + Actions --}}
            <div class="xl:col-span-1 space-y-4">
                {{-- Totals --}}
                <div class="card p-5">
                    <h3 class="text-sm font-semibold mb-4" style="color: var(--text-primary);">Summary</h3>
                    <div class="space-y-3">
                        <div class="flex justify-between text-sm">
                            <span style="color: var(--text-muted);">Subtotal</span>
                            <span style="color: var(--text-primary);" class="font-medium">{{ $company->currency_symbol }} {{ number_format($subtotal, 2) }}</span>
                        </div>
                        <div>
                            <label class="form-label">Discount %</label>
                            <input wire:model.live="discount_value" type="number" step="0.1" min="0" max="100" class="form-input text-sm">
                        </div>
                        @if($discount_amount > 0)
                        <div class="flex justify-between text-sm text-red-500">
                            <span>Discount</span>
                            <span>- {{ $company->currency_symbol }} {{ number_format($discount_amount, 2) }}</span>
                        </div>
                        @endif
                        <div>
                            <label class="form-label">Tax Rate %</label>
                            <input wire:model.live="tax_rate" type="number" step="0.1" min="0" class="form-input text-sm">
                        </div>
                        @if($tax_amount > 0)
                        <div class="flex justify-between text-sm" style="color: var(--text-secondary);">
                            <span>Tax</span>
                            <span>+ {{ $company->currency_symbol }} {{ number_format($tax_amount, 2) }}</span>
                        </div>
                        @endif
                        <div class="border-t pt-3" style="border-color: var(--border-color);">
                            <div class="flex justify-between">
                                <span class="font-bold" style="color: var(--text-primary);">Grand Total</span>
                                <span class="text-xl font-bold text-indigo-500">{{ $company->currency_symbol }} {{ number_format($grand_total, 2) }}</span>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- Actions --}}
                <div class="card p-5 space-y-3">
                    <button type="submit" class="btn btn-primary w-full justify-center btn-lg">
                        <span wire:loading.remove wire:target="save">{{ $editing ? 'Update Invoice' : 'Create Invoice' }}</span>
                        <span wire:loading wire:target="save" class="flex items-center gap-2"><div class="spinner !w-4 !h-4 !border-white/30 !border-t-white"></div> Saving...</span>
                    </button>
                </div>
            </div>
        </div>
    </form>
</div>
