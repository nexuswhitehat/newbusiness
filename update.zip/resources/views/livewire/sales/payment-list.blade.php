<div>
    <div class="flex items-center justify-between mb-6">
        <div><h1 class="text-2xl font-bold" style="color: var(--text-primary);">Payments</h1><p class="text-sm mt-1" style="color: var(--text-muted);">Total collected: {{ $company->currency_symbol }} {{ number_format($total,2) }}</p></div>
        <a href="{{ route('payments.create', $company->slug) }}" class="btn btn-primary"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg> Record Payment</a>
    </div>
    <div class="card p-4 mb-4"><input wire:model.live.debounce.300ms="search" type="text" placeholder="Search payments..." class="form-input"></div>
    <div class="card overflow-x-auto">
        <table class="data-table"><thead><tr><th>Payment#</th><th>Customer</th><th>Invoice</th><th>Date</th><th>Method</th><th>Amount</th></tr></thead>
        <tbody>
            @forelse($payments as $pay)
            <tr><td class="font-mono text-xs">{{ $pay->payment_no }}</td><td style="color: var(--text-primary);" class="font-medium">{{ $pay->customer->customer_name ?? '-' }}</td><td class="text-indigo-500">{{ $pay->invoice->invoice_no ?? '-' }}</td><td>{{ $pay->payment_date->format('d M Y') }}</td><td><span class="badge badge-blue">{{ ucfirst(str_replace('_',' ',$pay->payment_method)) }}</span></td><td class="font-semibold text-emerald-500">{{ $company->currency_symbol }} {{ number_format($pay->amount,2) }}</td></tr>
            @empty<tr><td colspan="6" class="text-center py-10" style="color: var(--text-muted);">No payments recorded yet.</td></tr>@endforelse
        </tbody></table>
        <div class="px-4 py-3 pagination-wrapper">{{ $payments->links() }}</div>
    </div>
</div>
