@extends('layouts.app')

@section('content')
<div class="container mx-auto p-6">
    <h1 class="text-2xl font-semibold mb-4">Application Update</h1>

    @if($error)
        <div class="bg-red-100 text-red-800 p-4 rounded">{{ $error }}</div>
    @else
        <div class="mb-4">
            <p>Current version: {{ $current ?? 'unknown' }}</p>
            @if($meta)
                <p>Latest version: {{ $meta['latest_version'] ?? 'unknown' }}</p>
                <p>Release date: {{ $meta['release_date'] ?? '' }}</p>
                <p><a href="{{ $meta['release_notes'] ?? '#' }}" target="_blank">Release notes</a></p>
            @endif
        </div>

        @if($available)
            <div class="mb-4 p-4 bg-yellow-100 rounded">
                <strong>Update available!</strong>
            </div>
            <button id="updateBtn" class="btn btn-primary">Update Now</button>
            <div id="updateStatus" class="mt-4"></div>
        @else
            <div class="p-4 bg-green-100 rounded">No update available.</div>
        @endif
    @endif
</div>

@push('scripts')
<script>
document.getElementById('updateBtn')?.addEventListener('click', function(){
    if (!confirm('Start update now? Make sure you have backups.')) return;
    const status = document.getElementById('updateStatus');
    status.textContent = 'Starting update...';
    fetch("{{ route('admin.update.run', ['company' => request()->route('company')]) }}", {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').getAttribute('content'),
            'Accept': 'application/json'
        }
    }).then(r => r.json()).then(j => {
        if (j.ok) status.textContent = j.message;
        else status.textContent = 'Error: ' + (j.message || 'unknown');
    }).catch(e => { status.textContent = 'Request failed'; });
});
</script>
@endpush

@endsection
