<?php

namespace App\Traits;

use App\Models\Company;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

trait BelongsToCompany
{
    public static function bootBelongsToCompany(): void
    {
        // Auto-scope queries to current company
        static::addGlobalScope('company', function (Builder $builder) {
            $company = Company::current();
            if ($company) {
                $builder->where($builder->getModel()->getTable() . '.company_id', $company->id);
            }
        });

        // Auto-assign company_id on create
        static::creating(function ($model) {
            $company = Company::current();
            if ($company && empty($model->company_id)) {
                $model->company_id = $company->id;
            }
        });
    }

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }
}
