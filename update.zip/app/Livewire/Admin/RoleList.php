<?php
namespace App\Livewire\Admin;
use Livewire\Component; use App\Models\Role; use App\Models\Company;
class RoleList extends Component {
    public bool $showDeleteModal=false; public ?int $deleteId=null;
    public function confirmDelete(int $id){$this->deleteId=$id;$this->showDeleteModal=true;}
    public function delete(){$r=Role::findOrFail($this->deleteId);if($r->is_system){session()->flash('error','System roles cannot be deleted.');$this->showDeleteModal=false;return;}$r->delete();$this->showDeleteModal=false;session()->flash('success','Role deleted.');}
    public function render(){$roles=Role::withCount('admins')->with('permissions')->get();$company=Company::current();return view('livewire.admin.role-list',compact('roles','company'))->layout('layouts.app',['title'=>'Roles & Permissions']);}
}
