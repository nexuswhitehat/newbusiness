<?php

namespace App\Livewire\Admin;

use Livewire\Component;
use Livewire\WithFileUploads;
use App\Models\Company;
use App\Models\Setting;
use App\Models\ActivityLog;
use Illuminate\Support\Str;

class CompanyCreate extends Component
{
    use WithFileUploads;

    public string $name = '';
    public ?string $owner = '';
    public ?string $email = '';
    public ?string $phone = '';
    public ?string $address = '';
    public ?string $country = '';
    public ?string $currency = 'PKR';
    public ?string $currency_symbol = '₨';
    public ?string $timezone = 'Asia/Karachi';
    public ?string $vat_number = '';
    public ?string $fiscal_year_start = '';
    public $logo = null;

    protected $rules = [
        'name'            => 'required|string|max:255|unique:companies,name',
        'currency'        => 'required|string|max:10',
        'currency_symbol' => 'required|string|max:5',
        'email'           => 'nullable|email|max:255',
        'phone'           => 'nullable|string|max:30',
        'address'         => 'nullable|string|max:500',
        'country'         => 'nullable|string|max:100',
        'timezone'        => 'nullable|string|max:100',
        'vat_number'      => 'nullable|string|max:50',
        'logo'            => 'nullable|image|max:2048',
    ];

    public function save()
    {
        $this->validate();

        $data = [
            'name'            => $this->name,
            'slug'            => Str::slug($this->name),
            'owner'           => $this->owner,
            'email'           => $this->email,
            'phone'           => $this->phone,
            'address'         => $this->address,
            'country'         => $this->country,
            'currency'        => $this->currency,
            'currency_symbol' => $this->currency_symbol,
            'timezone'        => $this->timezone,
            'vat_number'      => $this->vat_number,
            'fiscal_year_start' => $this->fiscal_year_start ?: '01-01',
        ];

        if ($this->logo) {
            $data['logo'] = $this->logo->store('logos', 'public');
        }

        // Ensure unique slug
        $i = 1;
        $baseSlug = $data['slug'];
        while (Company::where('slug', $data['slug'])->exists()) {
            $data['slug'] = $baseSlug . '-' . $i++;
        }

        $company = Company::create($data);

        // Attach the admin to this company as default
        $admin = auth('admin')->user();
        $hasOtherCompanies = $admin->companies()->count() > 0;
        $admin->companies()->attach($company->id, [
            'is_default' => !$hasOtherCompanies,
        ]);

        // Create default settings for the company
        $this->seedDefaultSettings($company);

        ActivityLog::log('company', 'created', "Company created: {$company->name}");

        return redirect()->route('dashboard', $company->slug)
            ->with('success', "Company '{$company->name}' created successfully!");
    }

    protected function seedDefaultSettings(Company $company): void
    {
        $defaults = [
            ['group' => 'invoice', 'key' => 'invoice_prefix', 'value' => 'INV', 'label' => 'Invoice Prefix', 'type' => 'text'],
            ['group' => 'invoice', 'key' => 'quotation_prefix', 'value' => 'QUO', 'label' => 'Quotation Prefix', 'type' => 'text'],
            ['group' => 'invoice', 'key' => 'po_prefix', 'value' => 'PO', 'label' => 'PO Prefix', 'type' => 'text'],
            ['group' => 'invoice', 'key' => 'bill_prefix', 'value' => 'BILL', 'label' => 'Bill Prefix', 'type' => 'text'],
            ['group' => 'invoice', 'key' => 'payment_prefix', 'value' => 'PAY', 'label' => 'Payment Prefix', 'type' => 'text'],
            ['group' => 'tax', 'key' => 'default_tax_rate', 'value' => '0', 'label' => 'Default Tax Rate (%)', 'type' => 'number'],
            ['group' => 'email', 'key' => 'email_notifications', 'value' => 'off', 'label' => 'Email Notifications', 'type' => 'toggle'],
            ['group' => 'email', 'key' => 'email_on_invoice', 'value' => 'off', 'label' => 'Email on Invoice', 'type' => 'toggle'],
            ['group' => 'invoice', 'key' => 'invoice_terms', 'value' => '', 'label' => 'Invoice Terms', 'type' => 'textarea'],
            ['group' => 'invoice', 'key' => 'invoice_notes', 'value' => '', 'label' => 'Invoice Notes', 'type' => 'textarea'],
        ];

        foreach ($defaults as $setting) {
            Setting::firstOrCreate(
                ['key' => $setting['key']],
                $setting
            );
        }
    }

    public function render()
    {
        $timezones = timezone_identifiers_list();
        $currencies = [
            'PKR' => '₨', 'USD' => '$', 'EUR' => '€', 'GBP' => '£',
            'INR' => '₹', 'AED' => 'د.إ', 'SAR' => '﷼', 'CAD' => 'CA$',
            'AUD' => 'A$', 'JPY' => '¥', 'CNY' => '¥', 'BDT' => '৳',
        ];

        return view('livewire.admin.company-create', compact('timezones', 'currencies'))
            ->layout('layouts.guest', ['title' => 'Create Company']);
    }
}
