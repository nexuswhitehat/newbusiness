<?php
namespace App\Livewire\Admin;
use Livewire\Component; use App\Models\Admin; use App\Models\Role; use App\Models\Company; use App\Models\ActivityLog;
class AdminForm extends Component {
    public ?Admin $admin=null; public bool $editing=false;
    public string $name=''; public string $email=''; public string $phone=''; public ?int $role_id=null; public string $status='active'; public string $password=''; public array $companyIds=[];
    public function mount(?Admin $admin=null){if($admin&&$admin->exists){$this->admin=$admin;$this->editing=true;$this->name=$admin->name;$this->email=$admin->email;$this->phone=$admin->phone??'';$this->role_id=$admin->role_id;$this->status=$admin->status;$this->companyIds=$admin->companies->pluck('id')->toArray();}}
    protected function rules(){return['name'=>'required|string|max:255','email'=>'required|email|unique:admins,email'.($this->editing?','.$this->admin->id:''),'role_id'=>'required|exists:roles,id','status'=>'required','password'=>$this->editing?'nullable|min:8':'required|min:8'];}
    public function save(){$this->validate();$data=['name'=>$this->name,'email'=>$this->email,'phone'=>$this->phone,'role_id'=>$this->role_id,'status'=>$this->status];if(!empty($this->password))$data['password']=$this->password;if($this->editing){$this->admin->update($data);}else{$this->admin=Admin::create($data);}$this->admin->companies()->sync(array_fill_keys($this->companyIds,['is_default'=>false]));ActivityLog::log('admins',$this->editing?'updated':'created',"Admin: {$this->name}");return redirect()->route('admin.admins.index',Company::current()->slug)->with('success','Admin saved.');}
    public function render(){$roles=Role::orderBy('name')->get(['id','name']);$companies=\App\Models\Company::orderBy('name')->get(['id','name','slug']);$company=Company::current();return view('livewire.admin.admin-form',compact('roles','companies','company'))->layout('layouts.app',['title'=>$this->editing?'Edit Admin':'Add Admin']);}
}
