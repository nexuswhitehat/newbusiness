<?php
namespace App\Livewire\Admin;
use Livewire\Component; use Livewire\WithPagination; use App\Models\ActivityLog; use App\Models\Company;
class ActivityLogList extends Component {
    use WithPagination; public string $search=''; public string $module='';
    public function render(){$logs=ActivityLog::with('admin')->when($this->search,fn($q)=>$q->where('description','like',"%{$this->search}%"))->when($this->module,fn($q)=>$q->where('module',$this->module))->latest()->paginate(20);$company=Company::current();$modules=ActivityLog::distinct('module')->pluck('module');return view('livewire.admin.activity-log-list',compact('logs','company','modules'))->layout('layouts.app',['title'=>'Activity Logs']);}
}
