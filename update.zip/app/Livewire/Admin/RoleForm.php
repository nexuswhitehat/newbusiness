<?php
namespace App\Livewire\Admin;
use Livewire\Component; use App\Models\Role; use App\Models\Permission; use App\Models\Company; use App\Models\ActivityLog;
class RoleForm extends Component {
    public ?Role $role=null; public bool $editing=false;
    public string $name=''; public string $description=''; public array $selectedPermissions=[];
    public function mount(?Role $role=null){if($role&&$role->exists){$this->role=$role;$this->editing=true;$this->name=$role->name;$this->description=$role->description??'';$this->selectedPermissions=$role->permissions->pluck('id')->toArray();}}
    protected $rules=['name'=>'required|string|max:255'];
    public function toggleAll(string $module){$modulePerms=Permission::where('module',$module)->pluck('id')->toArray();$hasAll=count(array_intersect($modulePerms,$this->selectedPermissions))===count($modulePerms);if($hasAll){$this->selectedPermissions=array_values(array_diff($this->selectedPermissions,$modulePerms));}else{$this->selectedPermissions=array_values(array_unique(array_merge($this->selectedPermissions,$modulePerms)));}}
    public function save(){$this->validate();$data=['name'=>$this->name,'description'=>$this->description];if($this->editing){$this->role->update($data);}else{$this->role=Role::create($data);}$this->role->permissions()->sync($this->selectedPermissions);ActivityLog::log('roles',$this->editing?'updated':'created',"Role: {$this->name}");return redirect()->route('admin.roles.index',Company::current()->slug)->with('success','Role saved.');}
    public function render(){$permissions=Permission::orderBy('module')->orderBy('action')->get()->groupBy('module');$company=Company::current();return view('livewire.admin.role-form',compact('permissions','company'))->layout('layouts.app',['title'=>$this->editing?'Edit Role':'Create Role']);}
}
