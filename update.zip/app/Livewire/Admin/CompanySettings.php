<?php
namespace App\Livewire\Admin;
use Livewire\Component; use Livewire\WithFileUploads; use App\Models\Company; use App\Models\Setting; use App\Models\ActivityLog;
class CompanySettings extends Component {
    use WithFileUploads;
    public string $tab='company';
    // Company fields
    public string $name=''; public ?string $owner=''; public ?string $email=''; public ?string $phone=''; public ?string $address=''; public ?string $country=''; public ?string $currency='PKR'; public ?string $currency_symbol='₨'; public ?string $timezone='Asia/Karachi'; public ?string $vat_number='';
    // Settings
    public array $settings=[];
    public $logo=null;

    public function mount(){$company=Company::current();if($company){$this->fill($company->only(['name','owner','email','phone','address','country','currency','currency_symbol','timezone','vat_number']));}$this->settings=Setting::pluck('value','key')->toArray();}

    public function saveCompany(){$this->validate(['name'=>'required|string|max:255','currency'=>'required|string|max:10','currency_symbol'=>'required|string|max:5']);$company=Company::current();$data=$this->only(['name','owner','email','phone','address','country','currency','currency_symbol','timezone','vat_number']);if($this->logo){$path=$this->logo->store('logos','public');$data['logo']=$path;}$company->update($data);ActivityLog::log('company','updated','Company settings updated');session()->flash('success','Company settings saved.');}

    public function saveSettings(){foreach($this->settings as $key=>$value){Setting::where('key',$key)->update(['value'=>$value]);}ActivityLog::log('settings','updated','System settings updated');session()->flash('success','Settings saved.');}

    public function render(){$company=Company::current();$allCompanySettings=Setting::orderBy('group')->orderBy('key')->get();return view('livewire.admin.company-settings',compact('company','allCompanySettings'))->layout('layouts.app',['title'=>'Company Settings']);}
}
