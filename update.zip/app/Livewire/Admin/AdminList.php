<?php
namespace App\Livewire\Admin;
use Livewire\Component; use Livewire\WithPagination; use App\Models\Admin; use App\Models\Company;
class AdminList extends Component {
    use WithPagination; public string $search=''; public string $status='';

    public function delete(int $id)
    {
        $currentAdmin = auth('admin')->user();
        if (!$currentAdmin->isSuperAdmin()) {
            abort(403, 'Unauthorized action.');
        }

        if ($currentAdmin->id === $id) {
            session()->flash('error', 'You cannot delete yourself.');
            return;
        }

        $admin = Admin::findOrFail($id);
        $admin->companies()->detach();
        $admin->delete();

        \App\Models\ActivityLog::log('admins', 'deleted', "Admin deleted: {$admin->name}");
        session()->flash('success', 'Admin user deleted successfully.');
    }

    public function render(){$admins=Admin::with('role')->when($this->search,fn($q)=>$q->where('name','like',"%{$this->search}%")->orWhere('email','like',"%{$this->search}%"))->when($this->status,fn($q)=>$q->where('status',$this->status))->latest()->paginate(15);$company=Company::current();return view('livewire.admin.admin-list',compact('admins','company'))->layout('layouts.app',['title'=>'Admins']);}
}
