<?php
namespace App\Livewire\Sales;
use Livewire\Component;
use Livewire\WithPagination;
use App\Models\Payment;
use App\Models\Company;

class PaymentList extends Component {
    use WithPagination;
    public string $search = '';
    public function render() {
        $payments = Payment::with('customer','invoice')
            ->when($this->search, fn($q) => $q->where('payment_no','like',"%{$this->search}%")->orWhereHas('customer',fn($c)=>$c->where('customer_name','like',"%{$this->search}%")))
            ->latest('payment_date')->paginate(15);
        $company = Company::current();
        $total = Payment::sum('amount');
        return view('livewire.sales.payment-list',compact('payments','company','total'))->layout('layouts.app',['title'=>'Payments']);
    }
}
