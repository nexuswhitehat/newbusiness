<?php
namespace App\Livewire\Sales;
use Livewire\Component;
use Livewire\WithPagination;
use App\Models\Quotation;
use App\Models\Company;
use App\Models\ActivityLog;

class QuotationList extends Component {
    use WithPagination;
    public string $search = ''; public string $status = '';
    public bool $showDeleteModal = false; public ?int $deleteId = null;
    public function updatingSearch() { $this->resetPage(); }
    public function confirmDelete(int $id) { $this->deleteId=$id; $this->showDeleteModal=true; }
    public function delete() { $q=Quotation::findOrFail($this->deleteId); $q->delete(); ActivityLog::log('quotations','deleted',"Deleted: {$q->quotation_no}"); $this->showDeleteModal=false; session()->flash('success','Quotation deleted.'); }
    public function render() {
        $quotations = Quotation::with('customer')->when($this->search,fn($q)=>$q->where('quotation_no','like',"%{$this->search}%")->orWhereHas('customer',fn($c)=>$c->where('customer_name','like',"%{$this->search}%")))->when($this->status,fn($q)=>$q->where('status',$this->status))->latest()->paginate(15);
        $company = Company::current();
        return view('livewire.sales.quotation-list',compact('quotations','company'))->layout('layouts.app',['title'=>'Quotations']);
    }
}
