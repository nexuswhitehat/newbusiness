<?php
namespace App\Livewire\Sales;

use Livewire\Component;
use App\Models\Invoice;
use App\Models\Payment;
use App\Models\Company;
use App\Models\Setting;
use App\Models\ActivityLog;
use App\Models\CustomerLedger;
use Illuminate\Support\Facades\DB;

class InvoiceShow extends Component
{
    public Invoice $invoice;
    public bool $showPaymentModal = false;

    // Payment
    public string $payment_date = '';
    public float $payment_amount = 0;
    public string $payment_method = 'cash';
    public string $payment_reference = '';
    public string $payment_notes = '';

    public function mount(Invoice $invoice)
    {
        $this->invoice = $invoice;
        $this->payment_date = now()->format('Y-m-d');
        $this->payment_amount = $invoice->due_amount;
    }

    public function markAsSent()
    {
        $this->invoice->update(['status' => 'sent']);
        ActivityLog::log('invoices', 'sent', "Invoice sent: {$this->invoice->invoice_no}");
        session()->flash('success', 'Invoice marked as sent.');
    }

    protected $rules = [
        'payment_date'      => 'required|date',
        'payment_amount'    => 'required|numeric|min:0.01',
        'payment_method'    => 'required|string',
        'payment_reference' => 'nullable|string|max:255',
        'payment_notes'     => 'nullable|string',
    ];

    public function recordPayment()
    {
        $this->validate();

        if ($this->payment_amount > $this->invoice->due_amount) {
            $this->addError('payment_amount', 'Amount exceeds the due amount of ' . $this->invoice->due_amount);
            return;
        }

        DB::transaction(function () {
            $prefix = Setting::where('key','payment_prefix')->value('value') ?? 'PAY';
            $payment = Payment::create([
                'payment_no'     => Payment::generateNo($prefix),
                'customer_id'    => $this->invoice->customer_id,
                'invoice_id'     => $this->invoice->id,
                'payment_date'   => $this->payment_date,
                'amount'         => $this->payment_amount,
                'payment_method' => $this->payment_method,
                'reference'      => $this->payment_reference,
                'notes'          => $this->payment_notes,
                'created_by'     => auth('admin')->id(),
            ]);

            // Update invoice
            $newPaid = $this->invoice->paid_amount + $this->payment_amount;
            $newDue  = $this->invoice->grand_total - $newPaid;
            $status  = $newDue <= 0 ? 'paid' : 'partial';
            $this->invoice->update(['paid_amount' => $newPaid, 'due_amount' => max(0, $newDue), 'status' => $status]);

            // Customer Ledger entry
            $lastBalance = CustomerLedger::where('customer_id', $this->invoice->customer_id)->latest()->value('balance') ?? 0;
            CustomerLedger::create([
                'customer_id' => $this->invoice->customer_id,
                'date'        => $this->payment_date,
                'reference'   => $payment->payment_no,
                'type'        => 'payment',
                'debit'       => 0,
                'credit'      => $this->payment_amount,
                'balance'     => $lastBalance - $this->payment_amount,
                'remarks'     => "Payment for {$this->invoice->invoice_no}",
                'created_by'  => auth('admin')->id(),
            ]);

            ActivityLog::log('payments', 'created', "Payment {$payment->payment_no} for invoice {$this->invoice->invoice_no}");
        });

        $this->invoice->refresh();
        $this->showPaymentModal = false;
        $this->payment_amount = $this->invoice->due_amount;
        session()->flash('success', 'Payment recorded successfully.');
    }

    public function render()
    {
        $invoice = $this->invoice->load(['customer', 'items.product', 'payments', 'createdBy']);
        $company = Company::current();
        return view('livewire.sales.invoice-show', compact('invoice','company'))
            ->layout('layouts.app', ['title' => $invoice->invoice_no]);
    }
}
