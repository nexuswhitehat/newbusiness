<?php
namespace App\Livewire\Sales;

use Livewire\Component;
use Livewire\WithPagination;
use App\Models\Invoice;
use App\Models\Company;
use App\Models\ActivityLog;

class InvoiceList extends Component
{
    use WithPagination;
    public string $search = '';
    public string $status = '';
    public string $dateFrom = '';
    public string $dateTo = '';
    public bool $showDeleteModal = false;
    public ?int $deleteId = null;

    public function updatingSearch() { $this->resetPage(); }
    public function updatingStatus() { $this->resetPage(); }

    public function confirmDelete(int $id) { $this->deleteId = $id; $this->showDeleteModal = true; }

    public function delete()
    {
        $inv = Invoice::findOrFail($this->deleteId);
        if (in_array($inv->status, ['paid', 'partial'])) {
            session()->flash('error', 'Cannot delete a paid/partial invoice.');
        } else {
            $inv->delete();
            ActivityLog::log('invoices', 'deleted', "Deleted invoice: {$inv->invoice_no}");
            session()->flash('success', 'Invoice deleted.');
        }
        $this->showDeleteModal = false;
    }

    public function render()
    {
        $invoices = Invoice::with('customer')
            ->when($this->search, fn($q) => $q->where('invoice_no', 'like', "%{$this->search}%")->orWhereHas('customer', fn($c) => $c->where('customer_name', 'like', "%{$this->search}%")))
            ->when($this->status, fn($q) => $q->where('status', $this->status))
            ->when($this->dateFrom, fn($q) => $q->whereDate('invoice_date', '>=', $this->dateFrom))
            ->when($this->dateTo,   fn($q) => $q->whereDate('invoice_date', '<=', $this->dateTo))
            ->latest('invoice_date')->paginate(15);

        $company = Company::current();
        $totalRevenue = Invoice::where('status', '!=', 'cancelled')->sum('grand_total');
        $totalDue = Invoice::whereNotIn('status', ['paid','cancelled'])->sum('due_amount');
        $overdueCount = Invoice::where('status', 'overdue')->count();

        return view('livewire.sales.invoice-list', compact('invoices','company','totalRevenue','totalDue','overdueCount'))
            ->layout('layouts.app', ['title' => 'Invoices']);
    }
}
