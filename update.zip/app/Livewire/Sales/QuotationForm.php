<?php
namespace App\Livewire\Sales;
use Livewire\Component;
use App\Models\Quotation;
use App\Models\QuotationItem;
use App\Models\Customer;
use App\Models\Product;
use App\Models\Setting;
use App\Models\Company;
use App\Models\Invoice;
use App\Models\ActivityLog;
use Illuminate\Support\Facades\DB;

class QuotationForm extends Component {
    public ?Quotation $quotation = null; public bool $editing = false;
    public ?int $customer_id=null; public string $quotation_date=''; public string $valid_until='';
    public array $items=[]; public float $discount_value=0; public float $tax_rate=0;
    public float $subtotal=0; public float $discount_amount=0; public float $tax_amount=0; public float $grand_total=0;
    public string $notes=''; public string $terms=''; public string $status='draft';

    public function mount(?Quotation $quotation=null) {
        $this->quotation_date=now()->format('Y-m-d'); $this->valid_until=now()->addDays(30)->format('Y-m-d');
        $s=Setting::whereIn('key',['default_tax_rate','invoice_terms','invoice_notes'])->pluck('value','key');
        $this->tax_rate=$s['default_tax_rate']??0; $this->terms=$s['invoice_terms']??''; $this->notes=$s['invoice_notes']??'';
        if ($quotation && $quotation->exists) {
            $this->quotation=$quotation; $this->editing=true;
            $this->fill($quotation->only(['customer_id','quotation_date','valid_until','discount_value','tax_rate','notes','terms','status']));
            $this->quotation_date=$quotation->quotation_date->format('Y-m-d'); $this->valid_until=$quotation->valid_until?->format('Y-m-d')??'';
            $this->items=$quotation->items->map(fn($i)=>['id'=>$i->id,'product_id'=>$i->product_id,'description'=>$i->description,'qty'=>$i->qty,'unit_price'=>$i->unit_price,'discount'=>$i->discount,'total'=>$i->total])->toArray();
        } else { $this->addItem(); }
        $this->recalculate();
    }
    public function addItem() { $this->items[]=['id'=>null,'product_id'=>null,'description'=>'','qty'=>1,'unit_price'=>0,'discount'=>0,'total'=>0]; }
    public function removeItem(int $i) { unset($this->items[$i]); $this->items=array_values($this->items); $this->recalculate(); }
    public function productSelected(int $i) { $p=Product::find($this->items[$i]['product_id']??null); if($p){$this->items[$i]['description']=$p->name;$this->items[$i]['unit_price']=$p->selling_price;$this->recalculateItem($i);} }
    public function recalculateItem(int $i) { $it=&$this->items[$i];$sub=(float)$it['qty']*(float)$it['unit_price'];$it['total']=round($sub*(1-($it['discount']/100)),2);$this->recalculate(); }
    public function updated($prop) { if(str_starts_with($prop,'items.')){[$_,$i]=explode('.',$prop);if(isset($this->items[(int)$i]))$this->recalculateItem((int)$i);} if(in_array($prop,['discount_value','tax_rate']))$this->recalculate(); }
    public function recalculate() { $this->subtotal=collect($this->items)->sum('total');$this->discount_amount=round($this->subtotal*($this->discount_value/100),2);$ad=$this->subtotal-$this->discount_amount;$this->tax_amount=round($ad*($this->tax_rate/100),2);$this->grand_total=round($ad+$this->tax_amount,2); }

    protected $rules = ['customer_id'=>'required|exists:customers,id','quotation_date'=>'required|date','items'=>'required|array|min:1','items.*.description'=>'required|string','items.*.qty'=>'required|numeric|min:0.01','items.*.unit_price'=>'required|numeric|min:0'];

    public function save() {
        $this->validate(); $this->recalculate();
        DB::transaction(function() {
            $c=Company::current();
            $data=['customer_id'=>$this->customer_id,'quotation_date'=>$this->quotation_date,'valid_until'=>$this->valid_until?:null,'status'=>$this->status,'discount_value'=>$this->discount_value,'discount_amount'=>$this->discount_amount,'tax_rate'=>$this->tax_rate,'tax_amount'=>$this->tax_amount,'subtotal'=>$this->subtotal,'grand_total'=>$this->grand_total,'notes'=>$this->notes,'terms'=>$this->terms,'currency'=>$c->currency,'currency_symbol'=>$c->currency_symbol];
            if($this->editing){$this->quotation->update($data);$this->quotation->items()->delete();}
            else{$pfx=Setting::where('key','quotation_prefix')->value('value')?:'QUO';$data['quotation_no']=Quotation::generateNo($pfx);$data['created_by']=auth('admin')->id();$this->quotation=Quotation::create($data);}
            foreach($this->items as $it){$this->quotation->items()->create(['product_id'=>$it['product_id']?:null,'description'=>$it['description'],'qty'=>$it['qty'],'unit_price'=>$it['unit_price'],'discount'=>$it['discount']??0,'total'=>$it['total']]);}
            ActivityLog::log('quotations',$this->editing?'updated':'created',"Quotation: {$this->quotation->quotation_no}");
        });
        return redirect()->route('quotations.index', Company::current()->slug)->with('success','Quotation '.($this->editing?'updated':'created').'.');
    }
    public function convertToInvoice() {
        // Create invoice from quotation
        $pfx=Setting::where('key','invoice_prefix')->value('value')?:'INV';
        $c=Company::current();
        $inv=Invoice::create(['invoice_no'=>Invoice::generateNo($pfx),'customer_id'=>$this->quotation->customer_id,'invoice_date'=>now()->format('Y-m-d'),'status'=>'draft','discount_value'=>$this->quotation->discount_value,'discount_amount'=>$this->quotation->discount_amount,'tax_rate'=>$this->quotation->tax_rate,'tax_amount'=>$this->quotation->tax_amount,'subtotal'=>$this->quotation->subtotal,'grand_total'=>$this->quotation->grand_total,'due_amount'=>$this->quotation->grand_total,'currency'=>$c->currency,'currency_symbol'=>$c->currency_symbol,'created_by'=>auth('admin')->id()]);
        foreach($this->quotation->items as $it){$inv->items()->create(['product_id'=>$it->product_id,'description'=>$it->description,'qty'=>$it->qty,'unit_price'=>$it->unit_price,'discount'=>$it->discount,'total'=>$it->total]);}
        $this->quotation->update(['status'=>'converted']);
        return redirect()->route('invoices.show',[$c->slug,$inv->id])->with('success','Quotation converted to invoice.');
    }
    public function render() {
        $customers=Customer::where('status','active')->get(['id','customer_name','company_name']);
        $products=Product::where('status','active')->get(['id','name','sku','selling_price']);
        $company=Company::current();
        return view('livewire.sales.quotation-form',compact('customers','products','company'))->layout('layouts.app',['title'=>$this->editing?'Edit Quotation':'Create Quotation']);
    }
}
