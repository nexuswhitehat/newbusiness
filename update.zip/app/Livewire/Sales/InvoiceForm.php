<?php
namespace App\Livewire\Sales;

use Livewire\Component;
use App\Models\Invoice;
use App\Models\InvoiceItem;
use App\Models\Customer;
use App\Models\Product;
use App\Models\Setting;
use App\Models\Company;
use App\Models\ActivityLog;
use App\Services\InvoiceService;
use Illuminate\Support\Facades\DB;

class InvoiceForm extends Component
{
    public ?Invoice $invoice = null;
    public bool $editing = false;

    // Header
    public ?int $customer_id = null;
    public string $invoice_date = '';
    public string $due_date = '';
    public string $reference = '';
    public string $status = 'draft';
    public string $payment_terms = 'net30';

    // Line items
    public array $items = [];

    // Totals
    public float $discount_type = 0; // 0=flat 1=percentage
    public float $discount_value = 0;
    public float $tax_rate = 0;
    public string $notes = '';
    public string $terms = '';

    // Computed
    public float $subtotal = 0;
    public float $discount_amount = 0;
    public float $tax_amount = 0;
    public float $grand_total = 0;

    public function mount(?Invoice $invoice = null)
    {
        $settings = Setting::whereIn('key', ['default_tax_rate','invoice_terms','invoice_notes'])->pluck('value','key');
        $this->tax_rate = $settings['default_tax_rate'] ?? 0;
        $this->terms    = $settings['invoice_terms'] ?? '';
        $this->notes    = $settings['invoice_notes'] ?? '';
        $this->invoice_date = now()->format('Y-m-d');
        $this->due_date = now()->addDays(30)->format('Y-m-d');

        if ($invoice && $invoice->exists) {
            $this->invoice = $invoice;
            $this->editing = true;
            $this->fill($invoice->only(['customer_id','invoice_date','due_date','reference','status','payment_terms','discount_value','tax_rate','notes','terms']));
            $this->invoice_date = $invoice->invoice_date->format('Y-m-d');
            $this->due_date     = $invoice->due_date?->format('Y-m-d') ?? '';
            $this->items = $invoice->items->map(fn($i) => [
                'id' => $i->id, 'product_id' => $i->product_id, 'description' => $i->description,
                'qty' => $i->qty, 'unit_price' => $i->unit_price, 'discount' => $i->discount,
                'tax_rate' => $i->tax_rate, 'total' => $i->total,
            ])->toArray();
        } else {
            $this->addItem();
        }
        $this->recalculate();
    }

    public function addItem()
    {
        $this->items[] = [
            'id' => null, 'product_id' => null, 'description' => '',
            'qty' => 1, 'unit_price' => 0, 'discount' => 0, 'tax_rate' => 0, 'total' => 0,
        ];
    }

    public function removeItem(int $index)
    {
        unset($this->items[$index]);
        $this->items = array_values($this->items);
        $this->recalculate();
    }

    public function productSelected(int $index)
    {
        $productId = $this->items[$index]['product_id'] ?? null;
        if ($productId) {
            $product = Product::find($productId);
            if ($product) {
                $this->items[$index]['description'] = $product->name;
                $this->items[$index]['unit_price']  = $product->selling_price;
                $this->items[$index]['tax_rate']     = $product->tax ?? 0;
                $this->recalculateItem($index);
            }
        }
    }

    public function recalculateItem(int $index)
    {
        $item = &$this->items[$index];
        $qty        = (float)($item['qty'] ?? 0);
        $price      = (float)($item['unit_price'] ?? 0);
        $discount   = (float)($item['discount'] ?? 0);
        $subtotal   = $qty * $price;
        $disc       = $subtotal * ($discount / 100);
        $item['total'] = round($subtotal - $disc, 2);
        $this->recalculate();
    }

    public function updated($prop)
    {
        if (str_starts_with($prop, 'items.')) {
            [$_, $index] = explode('.', $prop);
            if (isset($this->items[(int)$index])) {
                $this->recalculateItem((int)$index);
            }
        }
        if (in_array($prop, ['discount_value', 'tax_rate'])) {
            $this->recalculate();
        }
    }

    public function recalculate()
    {
        $this->subtotal = collect($this->items)->sum('total');
        $this->discount_amount = round($this->subtotal * ($this->discount_value / 100), 2);
        $afterDiscount = $this->subtotal - $this->discount_amount;
        $this->tax_amount = round($afterDiscount * ($this->tax_rate / 100), 2);
        $this->grand_total = round($afterDiscount + $this->tax_amount, 2);
    }

    protected $rules = [
        'customer_id'   => 'required|exists:customers,id',
        'invoice_date'  => 'required|date',
        'due_date'      => 'nullable|date|after_or_equal:invoice_date',
        'items'         => 'required|array|min:1',
        'items.*.description' => 'required|string',
        'items.*.qty'         => 'required|numeric|min:0.01',
        'items.*.unit_price'  => 'required|numeric|min:0',
    ];

    public function save()
    {
        $this->validate();
        $this->recalculate();

        DB::transaction(function () {
            $company = Company::current();
            $data = [
                'customer_id'     => $this->customer_id,
                'invoice_date'    => $this->invoice_date,
                'due_date'        => $this->due_date ?: null,
                'reference'       => $this->reference,
                'status'          => $this->status,
                'payment_terms'   => $this->payment_terms,
                'discount_value'  => $this->discount_value,
                'discount_amount' => $this->discount_amount,
                'tax_rate'        => $this->tax_rate,
                'tax_amount'      => $this->tax_amount,
                'subtotal'        => $this->subtotal,
                'grand_total'     => $this->grand_total,
                'due_amount'      => $this->grand_total,
                'notes'           => $this->notes,
                'terms'           => $this->terms,
                'currency'        => $company->currency,
                'currency_symbol' => $company->currency_symbol,
            ];

            if ($this->editing) {
                $this->invoice->update($data);
                $this->invoice->items()->delete();
            } else {
                $prefix = Setting::where('key','invoice_prefix')->value('value') ?? 'INV';
                $data['invoice_no']  = Invoice::generateNo($prefix);
                $data['created_by']  = auth('admin')->id();
                $this->invoice = Invoice::create($data);
            }

            foreach ($this->items as $item) {
                $this->invoice->items()->create([
                    'product_id'  => $item['product_id'] ?: null,
                    'description' => $item['description'],
                    'qty'         => $item['qty'],
                    'unit_price'  => $item['unit_price'],
                    'discount'    => $item['discount'] ?? 0,
                    'tax_rate'    => $item['tax_rate'] ?? 0,
                    'total'       => $item['total'],
                ]);
            }

            ActivityLog::log('invoices', $this->editing ? 'updated' : 'created', "Invoice: {$this->invoice->invoice_no}");

            // Send email if enabled and status = sent
            if ($this->status === 'sent') {
                $emailOn = Setting::where('key','email_notifications')->value('value') === 'on'
                        && Setting::where('key','email_on_invoice')->value('value') === 'on';
                if ($emailOn && $this->invoice->customer?->email) {
                    \Illuminate\Support\Facades\Mail::to($this->invoice->customer->email)->queue(new \App\Mail\InvoiceMail($this->invoice, $company));
                }
            }
        });

        $company = Company::current();
        return redirect()->route('invoices.show', [$company->slug, $this->invoice->id])
            ->with('success', 'Invoice ' . ($this->editing ? 'updated' : 'created') . ' successfully.');
    }

    public function render()
    {
        $customers = Customer::where('status','active')->get(['id','customer_name','company_name','billing_address','phone','email','vat_number']);
        $products  = Product::where('status','active')->get(['id','name','sku','selling_price','tax']);
        $company   = Company::current();
        return view('livewire.sales.invoice-form', compact('customers','products','company'))
            ->layout('layouts.app', ['title' => $this->editing ? 'Edit Invoice' : 'Create Invoice']);
    }
}
