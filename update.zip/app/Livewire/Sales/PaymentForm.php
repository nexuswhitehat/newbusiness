<?php
namespace App\Livewire\Sales;
use Livewire\Component;
use App\Models\Payment;
use App\Models\Customer;
use App\Models\Invoice;
use App\Models\Setting;
use App\Models\Company;
use App\Models\ActivityLog;
use App\Models\CustomerLedger;
use Illuminate\Support\Facades\DB;

class PaymentForm extends Component {
    public ?int $customer_id = null;
    public ?int $invoice_id = null;
    public string $payment_date = '';
    public float $amount = 0;
    public string $payment_method = 'cash';
    public string $reference = '';
    public string $notes = '';
    public array $customerInvoices = [];

    public function mount() { $this->payment_date = now()->format('Y-m-d'); }

    public function updatedCustomerId() {
        $this->customerInvoices = Invoice::where('customer_id',$this->customer_id)->whereNotIn('status',['paid','cancelled'])->get(['id','invoice_no','due_amount'])->toArray();
        $this->invoice_id = null; $this->amount = 0;
    }
    public function updatedInvoiceId() {
        $inv = Invoice::find($this->invoice_id);
        if ($inv) $this->amount = $inv->due_amount;
    }

    protected $rules = ['customer_id'=>'required|exists:customers,id','payment_date'=>'required|date','amount'=>'required|numeric|min:0.01','payment_method'=>'required|string'];

    public function save() {
        $this->validate();
        DB::transaction(function() {
            $prefix = Setting::where('key','payment_prefix')->value('value') ?? 'PAY';
            $payment = Payment::create(['payment_no'=>Payment::generateNo($prefix),'customer_id'=>$this->customer_id,'invoice_id'=>$this->invoice_id,'payment_date'=>$this->payment_date,'amount'=>$this->amount,'payment_method'=>$this->payment_method,'reference'=>$this->reference,'notes'=>$this->notes,'created_by'=>auth('admin')->id()]);
            if ($this->invoice_id) {
                $inv = Invoice::find($this->invoice_id);
                $newPaid = $inv->paid_amount + $this->amount;
                $newDue  = $inv->grand_total - $newPaid;
                $inv->update(['paid_amount'=>$newPaid,'due_amount'=>max(0,$newDue),'status'=>$newDue<=0?'paid':'partial']);
            }
            $lastBal = CustomerLedger::where('customer_id',$this->customer_id)->latest()->value('balance') ?? 0;
            CustomerLedger::create(['customer_id'=>$this->customer_id,'date'=>$this->payment_date,'reference'=>$payment->payment_no,'type'=>'payment','debit'=>0,'credit'=>$this->amount,'balance'=>$lastBal-$this->amount,'created_by'=>auth('admin')->id()]);
            ActivityLog::log('payments','created',"Payment: {$payment->payment_no}");
        });
        return redirect()->route('payments.index', Company::current()->slug)->with('success','Payment recorded.');
    }
    public function render() {
        $customers = Customer::where('status','active')->get(['id','customer_name','company_name']);
        $company = Company::current();
        return view('livewire.sales.payment-form',compact('customers','company'))->layout('layouts.app',['title'=>'Record Payment']);
    }
}
