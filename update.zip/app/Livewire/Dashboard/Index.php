<?php

namespace App\Livewire\Dashboard;

use Livewire\Component;
use App\Models\Customer;
use App\Models\Vendor;
use App\Models\Invoice;
use App\Models\Payment;
use App\Models\PurchaseBill;
use App\Models\Expense;
use App\Models\Product;
use App\Models\Lead;
use App\Models\Project;
use App\Models\Employee;

class Index extends Component
{
    public function render()
    {
        $currentMonth = now()->month;
        $currentYear = now()->year;

        // KPI Data
        $totalCustomers = Customer::count();
        $totalVendors = Vendor::count();
        $totalProducts = Product::count();
        $activeLeads = Lead::whereNotIn('status', ['won', 'lost'])->count();
        $activeProjects = Project::where('status', 'active')->count();
        $totalEmployees = Employee::where('status', 'active')->count();

        // Financial
        $monthlyRevenue = Invoice::whereMonth('invoice_date', $currentMonth)
            ->whereYear('invoice_date', $currentYear)
            ->where('status', '!=', 'cancelled')
            ->sum('grand_total');

        $monthlyPayments = Payment::whereMonth('payment_date', $currentMonth)
            ->whereYear('payment_date', $currentYear)
            ->sum('amount');

        $monthlyExpenses = Expense::whereMonth('date', $currentMonth)
            ->whereYear('date', $currentYear)
            ->sum('amount');

        $monthlyPurchases = PurchaseBill::whereMonth('bill_date', $currentMonth)
            ->whereYear('bill_date', $currentYear)
            ->sum('grand_total');

        $totalReceivable = Invoice::where('status', '!=', 'cancelled')
            ->where('status', '!=', 'paid')
            ->sum('due_amount');

        $totalPayable = PurchaseBill::where('status', '!=', 'paid')
            ->sum('due_amount');

        // Recent activity
        $recentInvoices = Invoice::with('customer')
            ->latest()
            ->take(5)
            ->get();

        $recentPayments = Payment::with('customer')
            ->latest()
            ->take(5)
            ->get();

        // Monthly revenue chart (last 6 months)
        $chartLabels = [];
        $chartRevenue = [];
        $chartExpenses = [];
        for ($i = 5; $i >= 0; $i--) {
            $date = now()->subMonths($i);
            $chartLabels[] = $date->format('M Y');
            $chartRevenue[] = Invoice::whereMonth('invoice_date', $date->month)
                ->whereYear('invoice_date', $date->year)
                ->where('status', '!=', 'cancelled')
                ->sum('grand_total');
            $chartExpenses[] = Expense::whereMonth('date', $date->month)
                ->whereYear('date', $date->year)
                ->sum('amount') + PurchaseBill::whereMonth('bill_date', $date->month)
                ->whereYear('bill_date', $date->year)
                ->sum('grand_total');
        }

        // Low stock products
        $lowStockProducts = Product::where('status', 'active')
            ->get()
            ->filter(fn($p) => $p->is_low_stock)
            ->take(5);

        // Lead status breakdown
        $leadsByStatus = Lead::selectRaw('status, count(*) as total')
            ->groupBy('status')
            ->pluck('total', 'status');

        return view('livewire.dashboard.index', compact(
            'totalCustomers', 'totalVendors', 'totalProducts', 'activeLeads',
            'activeProjects', 'totalEmployees',
            'monthlyRevenue', 'monthlyPayments', 'monthlyExpenses', 'monthlyPurchases',
            'totalReceivable', 'totalPayable',
            'recentInvoices', 'recentPayments',
            'chartLabels', 'chartRevenue', 'chartExpenses',
            'lowStockProducts', 'leadsByStatus'
        ))->layout('layouts.app', ['title' => 'Dashboard']);
    }
}
