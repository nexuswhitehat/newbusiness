<?php
namespace App\Livewire\Projects;
use Livewire\Component; use Livewire\WithPagination; use App\Models\Project; use App\Models\Company;
class ProjectList extends Component {
    use WithPagination; public string $search=''; public string $status='';
    public function render(){$projects=Project::with('customer')->when($this->search,fn($q)=>$q->where('name','like',"%{$this->search}%"))->when($this->status,fn($q)=>$q->where('status',$this->status))->latest()->paginate(15);$company=Company::current();return view('livewire.projects.project-list',compact('projects','company'))->layout('layouts.app',['title'=>'Projects']);}
}
