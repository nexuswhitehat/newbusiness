<?php
namespace App\Livewire\Projects;
use Livewire\Component; use App\Models\Project; use App\Models\Customer; use App\Models\Company; use App\Models\ActivityLog;
class ProjectForm extends Component {
    public ?Project $project=null; public bool $editing=false;
    public string $name=''; public ?int $customer_id=null; public string $status='active'; public string $start_date=''; public ?string $end_date=null; public float $budget=0; public string $description='';
    public function mount(?Project $project=null){$this->start_date=now()->format('Y-m-d');if($project&&$project->exists){$this->project=$project;$this->editing=true;$this->fill($project->only(['name','customer_id','status','start_date','end_date','budget','description']));$this->start_date=$project->start_date->format('Y-m-d');$this->end_date=$project->end_date?->format('Y-m-d');}}
    protected $rules=['name'=>'required|string|max:255','status'=>'required','start_date'=>'required|date'];
    public function save(){$this->validate();$data=$this->only(['name','customer_id','status','start_date','end_date','budget','description']);if($this->editing){$this->project->update($data);}else{$data['created_by']=auth('admin')->id();Project::create($data);}ActivityLog::log('projects',$this->editing?'updated':'created',"Project: {$this->name}");return redirect()->route('projects.index',Company::current()->slug)->with('success','Project saved.');}
    public function render(){$customers=Customer::where('status','active')->get(['id','customer_name']);$company=Company::current();return view('livewire.projects.project-form',compact('customers','company'))->layout('layouts.app',['title'=>$this->editing?'Edit Project':'New Project']);}
}
