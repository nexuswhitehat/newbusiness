<?php
namespace App\Livewire\Projects;
use Livewire\Component; use App\Models\Project; use App\Models\Company;
class ProjectShow extends Component {
    public Project $project; public string $tab='tasks';
    public string $taskTitle=''; public string $taskDueDate=''; public ?int $taskAssignedTo=null;
    public function mount(Project $project){$this->project=$project;}
    public function addTask(){$this->validate(['taskTitle'=>'required|string|max:255']);$this->project->tasks()->create(['title'=>$this->taskTitle,'due_date'=>$this->taskDueDate?:null,'assigned_to'=>$this->taskAssignedTo,'created_by'=>auth('admin')->id()]);$this->reset('taskTitle','taskDueDate','taskAssignedTo');session()->flash('success','Task added.');}
    public function toggleTask(int $id){$task=$this->project->tasks()->find($id);if($task)$task->update(['status'=>$task->status==='done'?'todo':'done']);}
    public function render(){$project=$this->project->load(['customer','tasks.assignedTo']);$company=Company::current();$admins=\App\Models\Admin::where('status','active')->get(['id','name']);return view('livewire.projects.project-show',compact('project','company','admins'))->layout('layouts.app',['title'=>$project->name]);}
}
