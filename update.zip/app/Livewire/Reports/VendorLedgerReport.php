<?php
namespace App\Livewire\Reports;
use Livewire\Component; use App\Models\Vendor; use App\Models\VendorLedger; use App\Models\Company;
class VendorLedgerReport extends Component {
    public ?int $vendor_id=null; public string $from=''; public string $to='';
    public function mount(){$this->from=now()->startOfMonth()->format('Y-m-d');$this->to=now()->format('Y-m-d');}
    public function render(){$vendors=Vendor::where('status','active')->get(['id','contact_name','company_name']);$ledger=[];$vendor=null;if($this->vendor_id){$vendor=Vendor::find($this->vendor_id);$ledger=VendorLedger::where('vendor_id',$this->vendor_id)->whereBetween('date',[$this->from,$this->to])->orderBy('date')->get();}$company=Company::current();return view('livewire.reports.vendor-ledger-report',compact('vendors','ledger','vendor','company'))->layout('layouts.app',['title'=>'Vendor Ledger']);}
}
