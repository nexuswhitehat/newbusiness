<?php
namespace App\Livewire\Reports;
use Livewire\Component; use App\Models\PurchaseBill; use App\Models\Expense; use App\Models\Company;
class PurchaseReport extends Component {
    public string $from=''; public string $to='';
    public function mount(){$this->from=now()->startOfMonth()->format('Y-m-d');$this->to=now()->format('Y-m-d');}
    public function render(){$bills=PurchaseBill::with('vendor')->whereBetween('bill_date',[$this->from,$this->to])->latest('bill_date')->get();$expenses=Expense::with('category')->whereBetween('date',[$this->from,$this->to])->latest('date')->get();$totalBills=$bills->sum('grand_total');$totalExpenses=$expenses->sum('amount');$company=Company::current();return view('livewire.reports.purchase-report',compact('bills','expenses','totalBills','totalExpenses','company'))->layout('layouts.app',['title'=>'Purchase Report']);}
}
