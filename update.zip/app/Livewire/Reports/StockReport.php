<?php
namespace App\Livewire\Reports;
use Livewire\Component; use App\Models\Product; use App\Models\Company;
class StockReport extends Component {
    public string $filter='all';
    public function render(){$products=Product::with('category','unit')->when($this->filter==='low',fn($q)=>$q->whereRaw('stock_quantity <= alert_quantity')->where('stock_quantity','>',0))->when($this->filter==='out',fn($q)=>$q->where('stock_quantity','<=',0))->orderBy('name')->get();$company=Company::current();$totalValue=$products->sum(fn($p)=>$p->stock_quantity*$p->cost_price);return view('livewire.reports.stock-report',compact('products','company','totalValue'))->layout('layouts.app',['title'=>'Stock Report']);}
}
