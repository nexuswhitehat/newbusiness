<?php
namespace App\Livewire\Reports;
use Livewire\Component; use App\Models\Customer; use App\Models\CustomerLedger; use App\Models\Company;
class CustomerLedgerReport extends Component {
    public ?int $customer_id=null; public string $from=''; public string $to='';
    public function mount(){$this->from=now()->startOfMonth()->format('Y-m-d');$this->to=now()->format('Y-m-d');}
    public function render(){$customers=Customer::where('status','active')->get(['id','customer_name','company_name']);$ledger=[];$customer=null;if($this->customer_id){$customer=Customer::find($this->customer_id);$ledger=CustomerLedger::where('customer_id',$this->customer_id)->whereBetween('date',[$this->from,$this->to])->orderBy('date')->get();}$company=Company::current();return view('livewire.reports.customer-ledger-report',compact('customers','ledger','customer','company'))->layout('layouts.app',['title'=>'Customer Ledger']);}
}
