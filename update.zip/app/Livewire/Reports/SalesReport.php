<?php
namespace App\Livewire\Reports;
use Livewire\Component; use App\Models\Invoice; use App\Models\Payment; use App\Models\Company;
class SalesReport extends Component {
    public string $from=''; public string $to=''; public string $groupBy='month';
    public function mount(){$this->from=now()->startOfMonth()->format('Y-m-d');$this->to=now()->format('Y-m-d');}
    public function render(){$invoices=Invoice::with('customer')->whereBetween('invoice_date',[$this->from,$this->to])->where('status','!=','cancelled')->latest('invoice_date')->get();$totalRevenue=$invoices->sum('grand_total');$totalPaid=$invoices->sum('paid_amount');$totalDue=$invoices->sum('due_amount');$company=Company::current();return view('livewire.reports.sales-report',compact('invoices','totalRevenue','totalPaid','totalDue','company'))->layout('layouts.app',['title'=>'Sales Report']);}
}
