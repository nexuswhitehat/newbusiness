<?php
namespace App\Livewire\Reports;
use Livewire\Component; use App\Models\Invoice; use App\Models\PurchaseBill; use App\Models\Expense; use App\Models\Payment; use App\Models\Company;
class ProfitReport extends Component {
    public string $from=''; public string $to='';
    public function mount(){$this->from=now()->startOfYear()->format('Y-m-d');$this->to=now()->format('Y-m-d');}
    public function render(){$revenue=Invoice::whereBetween('invoice_date',[$this->from,$this->to])->where('status','!=','cancelled')->sum('grand_total');$purchases=PurchaseBill::whereBetween('bill_date',[$this->from,$this->to])->sum('grand_total');$expenses=Expense::whereBetween('date',[$this->from,$this->to])->sum('amount');$grossProfit=$revenue-$purchases;$netProfit=$grossProfit-$expenses;$company=Company::current();return view('livewire.reports.profit-report',compact('revenue','purchases','expenses','grossProfit','netProfit','company'))->layout('layouts.app',['title'=>'Profit & Loss']);}
}
