<?php
namespace App\Livewire\Reports;
use Livewire\Component; use App\Models\Company;
class ReportIndex extends Component {
    public function render(){$company=Company::current();return view('livewire.reports.report-index',compact('company'))->layout('layouts.app',['title'=>'Reports']);}
}
