<?php
namespace App\Livewire\Purchase;
use Livewire\Component; use Livewire\WithPagination; use App\Models\Expense; use App\Models\Company;
class ExpenseList extends Component {
    use WithPagination; public string $search=''; public string $category='';
    public function render(){$expenses=Expense::with('category')->when($this->search,fn($q)=>$q->where('expense_no','like',"%{$this->search}%"))->when($this->category,fn($q)=>$q->where('category_id',$this->category))->latest('date')->paginate(15);$company=Company::current();$totalMonth=Expense::whereMonth('date',now()->month)->whereYear('date',now()->year)->sum('amount');return view('livewire.purchase.expense-list',compact('expenses','company','totalMonth'))->layout('layouts.app',['title'=>'Expenses']);}
}
