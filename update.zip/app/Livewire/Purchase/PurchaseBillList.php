<?php
namespace App\Livewire\Purchase;
use Livewire\Component; use Livewire\WithPagination; use App\Models\PurchaseBill; use App\Models\Company;
class PurchaseBillList extends Component {
    use WithPagination; public string $search=''; public string $status='';
    public function render(){$bills=PurchaseBill::with('vendor')->when($this->search,fn($q)=>$q->where('bill_no','like',"%{$this->search}%")->orWhereHas('vendor',fn($v)=>$v->where('contact_name','like',"%{$this->search}%")))->when($this->status,fn($q)=>$q->where('status',$this->status))->latest('bill_date')->paginate(15);$company=Company::current();$totalDue=PurchaseBill::whereNotIn('status',['paid','cancelled'])->sum('due_amount');return view('livewire.purchase.purchase-bill-list',compact('bills','company','totalDue'))->layout('layouts.app',['title'=>'Bills']);}
}
