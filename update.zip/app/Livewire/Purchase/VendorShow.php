<?php
namespace App\Livewire\Purchase;
use Livewire\Component; use App\Models\Vendor; use App\Models\Company;
class VendorShow extends Component {
    public Vendor $vendor; public string $tab='overview';
    public function mount(Vendor $vendor){$this->vendor=$vendor;}
    public function render(){$vendor=$this->vendor->load(['purchaseOrders'=>fn($q)=>$q->latest()->take(10),'bills'=>fn($q)=>$q->latest()->take(10)]);$company=Company::current();return view('livewire.purchase.vendor-show',compact('vendor','company'))->layout('layouts.app',['title'=>$vendor->contact_name]);}
}
