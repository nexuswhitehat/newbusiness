<?php
namespace App\Livewire\Purchase;
use Livewire\Component; use Livewire\WithPagination; use App\Models\PurchaseOrder; use App\Models\Company;
class PurchaseOrderList extends Component {
    use WithPagination; public string $search=''; public string $status='';
    public function render(){$pos=PurchaseOrder::with('vendor')->when($this->search,fn($q)=>$q->where('po_no','like',"%{$this->search}%")->orWhereHas('vendor',fn($v)=>$v->where('contact_name','like',"%{$this->search}%")))->when($this->status,fn($q)=>$q->where('status',$this->status))->latest()->paginate(15);$company=Company::current();return view('livewire.purchase.purchase-order-list',compact('pos','company'))->layout('layouts.app',['title'=>'Purchase Orders']);}
}
