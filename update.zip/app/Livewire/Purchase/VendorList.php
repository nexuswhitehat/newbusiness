<?php
namespace App\Livewire\Purchase;
use Livewire\Component; use Livewire\WithPagination;
use App\Models\Vendor; use App\Models\Company; use App\Models\ActivityLog;
class VendorList extends Component {
    use WithPagination; public string $search=''; public bool $showDeleteModal=false; public ?int $deleteId=null;
    public function confirmDelete(int $id){$this->deleteId=$id;$this->showDeleteModal=true;}
    public function delete(){$v=Vendor::findOrFail($this->deleteId);$v->delete();ActivityLog::log('vendors','deleted',"Deleted vendor: {$v->contact_name}");$this->showDeleteModal=false;session()->flash('success','Vendor deleted.');}
    public function render(){$vendors=Vendor::when($this->search,fn($q)=>$q->where('contact_name','like',"%{$this->search}%")->orWhere('phone','like',"%{$this->search}%"))->latest()->paginate(15);$company=Company::current();return view('livewire.purchase.vendor-list',compact('vendors','company'))->layout('layouts.app',['title'=>'Vendors']);}
}
