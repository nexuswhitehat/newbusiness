<?php
namespace App\Livewire\Purchase;
use Livewire\Component; use App\Models\Vendor; use App\Models\Company; use App\Models\ActivityLog;
class VendorForm extends Component {
    public ?Vendor $vendor=null; public bool $editing=false;
    public string $contact_name=''; public string $company_name=''; public string $phone=''; public string $email=''; public string $address=''; public float $opening_balance=0; public string $status='active';
    public function mount(?Vendor $vendor=null){if($vendor&&$vendor->exists){$this->vendor=$vendor;$this->editing=true;$this->fill($vendor->only(['contact_name','company_name','phone','email','address','opening_balance','status']));}}
    protected $rules=['contact_name'=>'required|string|max:255','phone'=>'nullable|string','email'=>'nullable|email','status'=>'required'];
    public function save(){$this->validate();$data=$this->only(['contact_name','company_name','phone','email','address','opening_balance','status']);if($this->editing){$this->vendor->update($data);}else{$data['vendor_code']=Vendor::generateCode();$data['created_by']=auth('admin')->id();Vendor::create($data);}ActivityLog::log('vendors',$this->editing?'updated':'created',"Vendor: {$this->contact_name}");return redirect()->route('vendors.index',Company::current()->slug)->with('success','Vendor '.($this->editing?'updated':'created').'.');}
    public function render(){$company=Company::current();return view('livewire.purchase.vendor-form',compact('company'))->layout('layouts.app',['title'=>$this->editing?'Edit Vendor':'Add Vendor']);}
}
