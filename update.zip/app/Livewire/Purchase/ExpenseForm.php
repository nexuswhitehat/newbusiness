<?php
namespace App\Livewire\Purchase;
use Livewire\Component; use App\Models\Expense; use App\Models\ExpenseCategory; use App\Models\Company; use App\Models\ActivityLog;
class ExpenseForm extends Component {
    public ?Expense $expense=null; public bool $editing=false;
    public ?int $category_id=null; public float $amount=0; public string $date=''; public string $payment_method='cash'; public string $reference=''; public string $contact_name=''; public string $remarks='';
    public function mount(?Expense $expense=null){$this->date=now()->format('Y-m-d');if($expense&&$expense->exists){$this->expense=$expense;$this->editing=true;$this->fill($expense->only(['category_id','amount','date','payment_method','reference','contact_name','remarks']));$this->date=$expense->date->format('Y-m-d');}}
    protected $rules=['category_id'=>'required|exists:expense_categories,id','amount'=>'required|numeric|min:0.01','date'=>'required|date','payment_method'=>'required'];
    public function save(){$this->validate();$data=$this->only(['category_id','amount','date','payment_method','reference','contact_name','remarks']);if($this->editing){$this->expense->update($data);}else{$data['expense_no']=Expense::generateNo();$data['created_by']=auth('admin')->id();Expense::create($data);}ActivityLog::log('expenses',$this->editing?'updated':'created',"Expense: ".$this->amount);return redirect()->route('expenses.index',Company::current()->slug)->with('success','Expense saved.');}
    public function render(){$categories=ExpenseCategory::orderBy('name')->get(['id','name']);$company=Company::current();return view('livewire.purchase.expense-form',compact('categories','company'))->layout('layouts.app',['title'=>$this->editing?'Edit Expense':'Add Expense']);}
}
