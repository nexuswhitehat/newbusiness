<?php
namespace App\Livewire\Inventory;
use Livewire\Component; use App\Models\Warehouse; use App\Models\Company;
class WarehouseList extends Component {
    public string $name=''; public string $location=''; public bool $showForm=false; public ?int $editingId=null;
    public function startEdit(int $id){$w=Warehouse::find($id);$this->editingId=$id;$this->name=$w->name;$this->location=$w->location??'';$this->showForm=true;}
    public function save(){$this->validate(['name'=>'required|string|max:255']);$data=['name'=>$this->name,'location'=>$this->location];if($this->editingId){Warehouse::find($this->editingId)->update($data);}else{Warehouse::create($data);}$this->reset('name','location','showForm','editingId');session()->flash('success','Warehouse saved.');}
    public function render(){$warehouses=Warehouse::withCount('stockMovements')->get();$company=Company::current();return view('livewire.inventory.warehouse-list',compact('warehouses','company'))->layout('layouts.app',['title'=>'Warehouses']);}
}
