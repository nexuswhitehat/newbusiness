<?php
namespace App\Livewire\Inventory;
use Livewire\Component; use App\Models\Category; use App\Models\Company; use App\Models\ActivityLog;
class CategoryList extends Component {
    public string $name=''; public string $description=''; public bool $showForm=false; public ?int $editingId=null;
    public function startEdit(int $id){$cat=Category::find($id);$this->editingId=$id;$this->name=$cat->name;$this->description=$cat->description??'';$this->showForm=true;}
    public function save(){$this->validate(['name'=>'required|string|max:255']);$data=['name'=>$this->name,'description'=>$this->description];if($this->editingId){Category::find($this->editingId)->update($data);$msg='Category updated.';}else{Category::create($data);$msg='Category created.';}$this->reset('name','description','showForm','editingId');session()->flash('success',$msg);}
    public function delete(int $id){Category::find($id)->delete();session()->flash('success','Category deleted.');}
    public function render(){$cats=Category::withCount('products')->orderBy('name')->get();$company=Company::current();return view('livewire.inventory.category-list',compact('cats','company'))->layout('layouts.app',['title'=>'Categories']);}
}
