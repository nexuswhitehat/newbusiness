<?php
namespace App\Livewire\Inventory;
use Livewire\Component; use Livewire\WithPagination; use App\Models\Product; use App\Models\Company; use App\Models\ActivityLog;
class ProductList extends Component {
    use WithPagination; public string $search=''; public string $category=''; public string $stockFilter='';
    public bool $showDeleteModal=false; public ?int $deleteId=null;
    public function updatingSearch(){$this->resetPage();}
    public function confirmDelete(int $id){$this->deleteId=$id;$this->showDeleteModal=true;}
    public function delete(){$p=Product::findOrFail($this->deleteId);$p->delete();ActivityLog::log('products','deleted',"Deleted: {$p->name}");$this->showDeleteModal=false;session()->flash('success','Product deleted.');}
    public function render(){$products=Product::with('category','brand','unit')->when($this->search,fn($q)=>$q->where('name','like',"%{$this->search}%")->orWhere('sku','like',"%{$this->search}%")->orWhere('barcode','like',"%{$this->search}%"))->when($this->category,fn($q)=>$q->where('category_id',$this->category))->when($this->stockFilter==='low',fn($q)=>$q->whereRaw('stock_quantity <= minimum_stock'))->when($this->stockFilter==='out',fn($q)=>$q->where('stock_quantity','<=',0))->latest()->paginate(15);$company=Company::current();$categories=\App\Models\Category::orderBy('name')->get(['id','name']);return view('livewire.inventory.product-list',compact('products','company','categories'))->layout('layouts.app',['title'=>'Products']);}
}
