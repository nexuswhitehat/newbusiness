<?php
namespace App\Livewire\Inventory;
use Livewire\Component; use Livewire\WithFileUploads; use App\Models\Product; use App\Models\Category; use App\Models\Brand; use App\Models\Unit; use App\Models\Company; use App\Models\ActivityLog;
class ProductForm extends Component {
    use WithFileUploads;
    public ?Product $product=null; public bool $editing=false;
    public string $name=''; public string $sku=''; public string $barcode=''; public ?int $category_id=null; public ?int $brand_id=null; public ?int $unit_id=null;
    public float $purchase_price=0; public float $selling_price=0; public float $tax=0;
    public float $stock_quantity=0; public float $minimum_stock=5;
    public string $type='product'; public string $status='active'; public string $description=''; public $photo=null;
    public function mount(?Product $product=null){if($product&&$product->exists){$this->product=$product;$this->editing=true;$this->fill($product->only(['name','sku','barcode','category_id','brand_id','unit_id','purchase_price','selling_price','tax','stock_quantity','minimum_stock','type','status','description']));}}
    protected $rules=['name'=>'required|string|max:255','sku'=>'nullable|string|max:100','purchase_price'=>'required|numeric|min:0','selling_price'=>'required|numeric|min:0','type'=>'required|in:product,service','status'=>'required'];
    public function save(){$this->validate();$data=$this->only(['name','sku','barcode','category_id','brand_id','unit_id','purchase_price','selling_price','tax','stock_quantity','minimum_stock','type','status','description']);if(empty($data['sku']))$data['sku']=Product::generateSku();if($this->editing){$this->product->update($data);}else{$data['created_by']=auth('admin')->id();Product::create($data);}ActivityLog::log('products',$this->editing?'updated':'created',"Product: {$this->name}");return redirect()->route('products.index',Company::current()->slug)->with('success','Product saved.');}
    public function render(){$categories=Category::orderBy('name')->get(['id','name']);$brands=Brand::orderBy('name')->get(['id','name']);$units=Unit::orderBy('name')->get(['id','name','short_name']);$company=Company::current();return view('livewire.inventory.product-form',compact('categories','brands','units','company'))->layout('layouts.app',['title'=>$this->editing?'Edit Product':'Add Product']);}
}
