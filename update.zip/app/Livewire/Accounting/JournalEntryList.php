<?php
namespace App\Livewire\Accounting;
use Livewire\Component; use Livewire\WithPagination; use App\Models\JournalEntry; use App\Models\Company;
class JournalEntryList extends Component {
    use WithPagination; public string $search='';
    public function render(){$entries=JournalEntry::with('lines.account')->when($this->search,fn($q)=>$q->where('reference','like',"%{$this->search}%")->orWhere('description','like',"%{$this->search}%"))->latest('date')->paginate(15);$company=Company::current();return view('livewire.accounting.journal-entry-list',compact('entries','company'))->layout('layouts.app',['title'=>'Journal Entries']);}
}
