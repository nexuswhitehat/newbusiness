<?php
namespace App\Livewire\Accounting;
use Livewire\Component; use App\Models\Account; use App\Models\Company;
class AccountList extends Component {
    public string $type=''; public string $search='';
    public function render(){$accounts=Account::with('children')->whereNull('parent_id')->when($this->type,fn($q)=>$q->where('account_type',$this->type))->when($this->search,fn($q)=>$q->where('account_name','like',"%{$this->search}%")->orWhere('account_code','like',"%{$this->search}%"))->orderBy('account_code')->get();$company=Company::current();return view('livewire.accounting.account-list',compact('accounts','company'))->layout('layouts.app',['title'=>'Chart of Accounts']);}
}
