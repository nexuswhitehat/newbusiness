<?php
namespace App\Livewire\Accounting;
use Livewire\Component; use App\Models\JournalEntry; use App\Models\JournalEntryLine; use App\Models\Account; use App\Models\Company; use App\Models\ActivityLog; use Illuminate\Support\Facades\DB;
class JournalEntryForm extends Component {
    public string $date=''; public string $reference=''; public string $description=''; public string $type='general';
    public array $lines=[];
    public float $totalDebit=0; public float $totalCredit=0; public bool $balanced=false;
    public function mount(){$this->date=now()->format('Y-m-d');$this->addLine();$this->addLine();}
    public function addLine(){$this->lines[]=['account_id'=>null,'description'=>'','debit'=>0,'credit'=>0];}
    public function removeLine(int $i){if(count($this->lines)>2){unset($this->lines[$i]);$this->lines=array_values($this->lines);}$this->recalculate();}
    public function updated($prop){if(str_starts_with($prop,'lines.'))$this->recalculate();}
    public function recalculate(){$this->totalDebit=collect($this->lines)->sum('debit');$this->totalCredit=collect($this->lines)->sum('credit');$this->balanced=abs($this->totalDebit-$this->totalCredit)<0.01;}
    protected $rules=['date'=>'required|date','lines'=>'required|array|min:2','lines.*.account_id'=>'required|exists:accounts,id'];
    public function save(){$this->validate();$this->recalculate();if(!$this->balanced){$this->addError('lines','Journal entry must be balanced (debits must equal credits).');return;}DB::transaction(function(){$je=JournalEntry::create(['date'=>$this->date,'reference'=>$this->reference,'description'=>$this->description,'type'=>$this->type,'total_debit'=>$this->totalDebit,'status'=>'posted','created_by'=>auth('admin')->id()]);foreach($this->lines as $line){$je->lines()->create($line);}ActivityLog::log('journal','created',"Journal Entry: {$je->reference}");});return redirect()->route('journal-entries.index',Company::current()->slug)->with('success','Journal entry posted.');}
    public function render(){$accounts=Account::orderBy('account_code')->get(['id','account_code','account_name','account_type']);$company=Company::current();return view('livewire.accounting.journal-entry-form',compact('accounts','company'))->layout('layouts.app',['title'=>'New Journal Entry']);}
}
