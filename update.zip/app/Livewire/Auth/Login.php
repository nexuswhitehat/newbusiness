<?php

namespace App\Livewire\Auth;

use Livewire\Component;
use App\Models\ActivityLog;

class Login extends Component
{
    public string $email = '';
    public string $password = '';
    public bool $remember = false;

    protected $rules = [
        'email'    => 'required|email',
        'password' => 'required|min:4',
    ];

    public function login()
    {
        $this->validate();

        if (auth('admin')->attempt([
            'email'    => $this->email,
            'password' => $this->password,
        ], $this->remember)) {

            $admin = auth('admin')->user();

            if ($admin->status !== 'active') {
                auth('admin')->logout();
                $this->addError('email', 'Your account has been deactivated.');
                return;
            }

            $admin->update(['last_login' => now()]);

            ActivityLog::log('auth', 'login', 'Admin logged in: ' . $admin->name);

            session()->regenerate();

            // Redirect to default company or company selector
            $defaultCompany = $admin->defaultCompany();
            if ($defaultCompany) {
                return redirect()->route('dashboard', $defaultCompany->slug);
            }

            // Super admin with no companies? Go create one
            if ($admin->isSuperAdmin() && \App\Models\Company::count() === 0) {
                return redirect()->route('company.create');
            }

            return redirect()->route('company.select');
        }

        $this->addError('email', 'Invalid credentials. Please try again.');
    }

    public function render()
    {
        return view('livewire.auth.login')
            ->layout('layouts.guest', ['title' => 'Login']);
    }
}
