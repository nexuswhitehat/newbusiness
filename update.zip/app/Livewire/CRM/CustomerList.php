<?php

namespace App\Livewire\CRM;

use Livewire\Component;
use Livewire\WithPagination;
use App\Models\Customer;
use App\Models\ActivityLog;

class CustomerList extends Component
{
    use WithPagination;

    public string $search = '';
    public string $status = '';
    public bool $showDeleteModal = false;
    public ?int $deleteId = null;

    public function updatingSearch() { $this->resetPage(); }
    public function updatingStatus() { $this->resetPage(); }

    public function confirmDelete(int $id)
    {
        $this->deleteId = $id;
        $this->showDeleteModal = true;
    }

    public function delete()
    {
        $customer = Customer::findOrFail($this->deleteId);
        $customer->delete();
        ActivityLog::log('customers', 'deleted', "Deleted customer: {$customer->customer_name}");
        $this->showDeleteModal = false;
        session()->flash('success', 'Customer deleted successfully.');
    }

    public function render()
    {
        $customers = Customer::query()
            ->when($this->search, fn($q) => $q->where('customer_name', 'like', "%{$this->search}%")
                ->orWhere('customer_code', 'like', "%{$this->search}%")
                ->orWhere('phone', 'like', "%{$this->search}%")
                ->orWhere('email', 'like', "%{$this->search}%"))
            ->when($this->status, fn($q) => $q->where('status', $this->status))
            ->latest()
            ->paginate(15);

        $company = \App\Models\Company::current();

        return view('livewire.crm.customer-list', compact('customers', 'company'))
            ->layout('layouts.app', ['title' => 'Customers']);
    }
}
