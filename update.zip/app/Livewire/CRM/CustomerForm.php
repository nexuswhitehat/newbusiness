<?php

namespace App\Livewire\CRM;

use Livewire\Component;
use App\Models\Customer;
use App\Models\Company;
use App\Models\CustomerContact;
use App\Models\CustomerLedger;
use App\Models\ActivityLog;

class CustomerForm extends Component
{
    public ?Customer $customer = null;
    public bool $editing = false;

    public string $customer_name = '';
    public string $company_name = '';
    public string $phone = '';
    public string $email = '';
    public string $vat_number = '';
    public string $billing_address = '';
    public string $shipping_address = '';
    public float $opening_balance = 0;
    public float $credit_limit = 0;
    public string $status = 'active';
    public string $remarks = '';

    // Contacts
    public array $contacts = [];

    public function mount(?Customer $customer = null)
    {
        if ($customer && $customer->exists) {
            $this->customer = $customer;
            $this->editing = true;
            $this->fill($customer->only([
                'customer_name', 'company_name', 'phone', 'email', 'vat_number',
                'billing_address', 'shipping_address', 'opening_balance', 'credit_limit',
                'status', 'remarks',
            ]));
            $this->contacts = $customer->contacts->map(fn($c) => $c->only(['id', 'name', 'phone', 'email', 'designation']))->toArray();
        }
    }

    public function addContact()
    {
        $this->contacts[] = ['id' => null, 'name' => '', 'phone' => '', 'email' => '', 'designation' => ''];
    }

    public function removeContact(int $index)
    {
        unset($this->contacts[$index]);
        $this->contacts = array_values($this->contacts);
    }

    protected function rules(): array
    {
        return [
            'customer_name' => 'required|string|max:255',
            'company_name'  => 'nullable|string|max:255',
            'phone'         => 'nullable|string|max:50',
            'email'         => 'nullable|email|max:255',
            'vat_number'    => 'nullable|string|max:100',
            'billing_address'  => 'nullable|string',
            'shipping_address' => 'nullable|string',
            'opening_balance'  => 'numeric|min:0',
            'credit_limit'     => 'numeric|min:0',
            'status'           => 'required|in:active,inactive,blocked',
            'remarks'          => 'nullable|string',
            'contacts.*.name'  => 'required|string|max:255',
        ];
    }

    public function save()
    {
        $this->validate();

        $data = [
            'customer_name'    => $this->customer_name,
            'company_name'     => $this->company_name,
            'phone'            => $this->phone,
            'email'            => $this->email,
            'vat_number'       => $this->vat_number,
            'billing_address'  => $this->billing_address,
            'shipping_address' => $this->shipping_address,
            'opening_balance'  => $this->opening_balance,
            'credit_limit'     => $this->credit_limit,
            'status'           => $this->status,
            'remarks'          => $this->remarks,
        ];

        if ($this->editing) {
            $this->customer->update($data);
            $action = 'updated';
        } else {
            $data['customer_code'] = Customer::generateCode();
            $data['created_by'] = auth('admin')->id();
            $this->customer = Customer::create($data);

            // Create opening balance ledger entry
            if ($this->opening_balance > 0) {
                CustomerLedger::create([
                    'customer_id' => $this->customer->id,
                    'date'        => now(),
                    'reference'   => $this->customer->customer_code,
                    'type'        => 'opening_balance',
                    'debit'       => $this->opening_balance,
                    'credit'      => 0,
                    'balance'     => $this->opening_balance,
                    'remarks'     => 'Opening balance',
                    'created_by'  => auth('admin')->id(),
                ]);
            }
            $action = 'created';
        }

        // Sync contacts
        $existingIds = [];
        foreach ($this->contacts as $contact) {
            if (!empty($contact['name'])) {
                if (!empty($contact['id'])) {
                    CustomerContact::where('id', $contact['id'])->update([
                        'name' => $contact['name'], 'phone' => $contact['phone'] ?? '',
                        'email' => $contact['email'] ?? '', 'designation' => $contact['designation'] ?? '',
                    ]);
                    $existingIds[] = $contact['id'];
                } else {
                    $c = $this->customer->contacts()->create($contact);
                    $existingIds[] = $c->id;
                }
            }
        }
        $this->customer->contacts()->whereNotIn('id', $existingIds)->delete();

        ActivityLog::log('customers', $action, "Customer {$action}: {$this->customer->customer_name}");

        $company = Company::current();
        return redirect()->route('customers.index', $company->slug)->with('success', "Customer {$action} successfully.");
    }

    public function render()
    {
        $company = Company::current();
        return view('livewire.crm.customer-form', compact('company'))
            ->layout('layouts.app', ['title' => $this->editing ? 'Edit Customer' : 'Create Customer']);
    }
}
