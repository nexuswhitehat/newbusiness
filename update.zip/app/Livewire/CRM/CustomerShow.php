<?php
namespace App\Livewire\CRM;

use Livewire\Component;
use App\Models\Customer;
use App\Models\Company;

class CustomerShow extends Component
{
    public Customer $customer;
    public string $tab = 'overview';

    public function mount(Customer $customer) { $this->customer = $customer; }

    public function render()
    {
        $customer = $this->customer->load(['contacts', 'invoices' => fn($q) => $q->latest()->take(10), 'payments' => fn($q) => $q->latest()->take(10), 'ledger']);
        $company = Company::current();
        return view('livewire.crm.customer-show', compact('customer', 'company'))
            ->layout('layouts.app', ['title' => $customer->customer_name]);
    }
}
