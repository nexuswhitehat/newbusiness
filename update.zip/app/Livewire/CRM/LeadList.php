<?php
namespace App\Livewire\CRM;

use Livewire\Component;
use Livewire\WithPagination;
use App\Models\Lead;
use App\Models\Company;
use App\Models\ActivityLog;

class LeadList extends Component
{
    use WithPagination;
    public string $search = '';
    public string $status = '';

    public bool $showDeleteModal = false;
    public ?int $deleteId = null;

    public function updatingSearch() { $this->resetPage(); }
    public function updatingStatus() { $this->resetPage(); }

    public function confirmDelete(int $id) { $this->deleteId = $id; $this->showDeleteModal = true; }

    public function delete()
    {
        $lead = Lead::findOrFail($this->deleteId);
        $lead->delete();
        ActivityLog::log('leads', 'deleted', "Deleted lead: {$lead->name}");
        $this->showDeleteModal = false;
        session()->flash('success', 'Lead deleted.');
    }

    public function render()
    {
        $leads = Lead::with('assignedTo')
            ->when($this->search, fn($q) => $q->where('name', 'like', "%{$this->search}%")->orWhere('email', 'like', "%{$this->search}%")->orWhere('company_name', 'like', "%{$this->search}%"))
            ->when($this->status, fn($q) => $q->where('status', $this->status))
            ->latest()->paginate(15);
        $company = Company::current();
        return view('livewire.crm.lead-list', compact('leads', 'company'))->layout('layouts.app', ['title' => 'Leads']);
    }
}
