<?php
namespace App\Livewire\CRM;
use Livewire\Component;
use App\Models\Lead;
use App\Models\Admin;
use App\Models\Company;
use App\Models\ActivityLog;

class LeadForm extends Component
{
    public ?Lead $lead = null;
    public bool $editing = false;
    public string $name = '';
    public string $company_name = '';
    public string $phone = '';
    public string $email = '';
    public string $source = 'manual';
    public string $status = 'new';
    public float $estimated_value = 0;
    public string $notes = '';
    public ?int $assigned_to = null;
    public ?string $expected_close_date = null;

    public function mount(?Lead $lead = null)
    {
        if ($lead && $lead->exists) {
            $this->lead = $lead;
            $this->editing = true;
            $this->fill($lead->only(['name','company_name','phone','email','source','status','estimated_value','notes','assigned_to','expected_close_date']));
        }
    }

    protected $rules = [
        'name'        => 'required|string|max:255',
        'phone'       => 'nullable|string|max:50',
        'email'       => 'nullable|email|max:255',
        'source'      => 'required|string',
        'status'      => 'required|string',
        'estimated_value'      => 'nullable|numeric|min:0',
        'expected_close_date'  => 'nullable|date',
        'assigned_to' => 'nullable|exists:admins,id',
    ];

    public function save()
    {
        $this->validate();
        $data = $this->only(['name','company_name','phone','email','source','status','estimated_value','notes','assigned_to','expected_close_date']);
        if ($this->editing) {
            $this->lead->update($data);
            $msg = 'Lead updated.';
        } else {
            $data['created_by'] = auth('admin')->id();
            Lead::create($data);
            $msg = 'Lead created.';
        }
        ActivityLog::log('leads', $this->editing ? 'updated' : 'created', "Lead: {$this->name}");
        $company = Company::current();
        return redirect()->route('leads.index', $company->slug)->with('success', $msg);
    }

    public function render()
    {
        $admins = Admin::where('status','active')->get(['id','name']);
        $company = Company::current();
        return view('livewire.crm.lead-form', compact('admins','company'))
            ->layout('layouts.app', ['title' => $this->editing ? 'Edit Lead' : 'New Lead']);
    }
}
