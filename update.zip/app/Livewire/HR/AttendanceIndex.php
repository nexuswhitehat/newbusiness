<?php
namespace App\Livewire\HR;
use Livewire\Component; use App\Models\Employee; use App\Models\Attendance; use App\Models\Company;
class AttendanceIndex extends Component {
    public string $date=''; public array $attendanceData=[];
    public function mount(){$this->date=now()->format('Y-m-d');$this->loadAttendance();}
    public function updatedDate(){$this->loadAttendance();}
    public function loadAttendance(){$employees=Employee::where('status','active')->get();$existing=Attendance::where('date',$this->date)->pluck('status','employee_id');$this->attendanceData=$employees->map(fn($e)=>['id'=>$e->id,'name'=>$e->name,'code'=>$e->employee_code,'designation'=>$e->designation,'status'=>$existing[$e->id]??'present'])->toArray();}
    public function save(){Attendance::where('date',$this->date)->delete();foreach($this->attendanceData as $a){Attendance::create(['employee_id'=>$a['id'],'date'=>$this->date,'status'=>$a['status'],'marked_by'=>auth('admin')->id()]);}session()->flash('success','Attendance saved for '.date('d M Y',strtotime($this->date)).'.');}
    public function render(){$company=Company::current();$present=collect($this->attendanceData)->where('status','present')->count();$absent=collect($this->attendanceData)->where('status','absent')->count();$leave=collect($this->attendanceData)->where('status','leave')->count();return view('livewire.hr.attendance-index',compact('company','present','absent','leave'))->layout('layouts.app',['title'=>'Attendance']);}
}
