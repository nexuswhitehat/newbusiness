<?php
namespace App\Livewire\HR;
use Livewire\Component; use App\Models\Employee; use App\Models\Company; use App\Models\ActivityLog;
class EmployeeForm extends Component {
    public ?Employee $employee=null; 
    public bool $editing=false;
    public string $name='';
    public string $email=''; 
    public string $phone=''; 
    public string $designation=''; 
    public string $department=''; 
    public string $joining_date=''; 
    public float $salary = 0.00; 
    public string $status='active'; 
    public string $address='';
    
    public function mount(?Employee $employee=null)
    {
        $this->joining_date=now()->format('Y-m-d');

        if($employee&&$employee->exists){
            $this->employee=$employee;
            $this->editing=true;
            $this->fill(
                $employee->only(['name','email','phone','designation','department','joining_date','status','address','salary'])
            );

            // $this->basic_salary = $employee->basic_salary !== null ? (float) $employee->basic_salary : 0;

            $this->joining_date=$employee->joining_date->format('Y-m-d');
        }
    }

    protected $rules=[
        'name'=>'required|string|max:255',
        'designation'=>'nullable|string',
        'salary'=>'required|numeric|min:0',
        'joining_date'=>'required|date',
        'status'=>'required'
    ];
    
    public function save()
    {
        $this->validate();
        $data=$this->only([
            'name','email','phone','designation','department','joining_date','salary','status','address'
        ]);


        if($this->editing){
            $this->employee->update($data);
        }else{
            $data['employee_code'] = Employee::generateCode();
            $data['created_by']= auth('admin')->id();
            Employee::create($data);
        }

        ActivityLog::log('employees',$this->editing?'updated':'created',"Employee{$this->name}");
        return redirect()->route('employees.index',Company::current()->slug)->with('success','Employee saved.');
    }
    public function render()
    {
        $company=Company::current();
        return view('livewire.hr.employee-form',compact('company'))->layout('layouts.app',['title'=>$this->editing?'Edit Employee':'Add Employee']);
    }
}
