<?php
namespace App\Livewire\HR;
use Livewire\Component; use Livewire\WithPagination; use App\Models\Employee; use App\Models\Company;
class EmployeeList extends Component {
    use WithPagination; public string $search=''; public string $status='';

    public function delete(int $id)
    {
        $currentAdmin = auth('admin')->user();
        if (!$currentAdmin->isSuperAdmin()) {
            abort(403, 'Unauthorized action.');
        }

        $employee = Employee::findOrFail($id);
        $employee->delete();

        \App\Models\ActivityLog::log('employees', 'deleted', "Employee deleted: {$employee->name}");
        session()->flash('success', 'Employee deleted successfully.');
    }

    public function render(){$employees=Employee::when($this->search,fn($q)=>$q->where('name','like',"%{$this->search}%")->orWhere('employee_code','like',"%{$this->search}%")->orWhere('designation','like',"%{$this->search}%"))->when($this->status,fn($q)=>$q->where('status',$this->status))->latest()->paginate(15);$company=Company::current();return view('livewire.hr.employee-list',compact('employees','company'))->layout('layouts.app',['title'=>'Employees']);}
}
