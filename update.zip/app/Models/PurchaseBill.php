<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class PurchaseBill extends Model
{
    use SoftDeletes, \App\Traits\BelongsToCompany;

    protected $fillable = [
        'bill_number', 'vendor_id', 'purchase_order_id', 'warehouse_id',
        'bill_date', 'due_date', 'notes', 'subtotal', 'discount', 'tax',
        'grand_total', 'paid_amount', 'due_amount', 'status', 'created_by',
    ];

    protected $casts = ['bill_date' => 'date', 'due_date' => 'date'];

    public function vendor(): BelongsTo { return $this->belongsTo(Vendor::class); }
    public function purchaseOrder(): BelongsTo { return $this->belongsTo(PurchaseOrder::class); }
    public function warehouse(): BelongsTo { return $this->belongsTo(Warehouse::class); }
    public function items(): HasMany { return $this->hasMany(PurchaseBillItem::class); }
    public function creator(): BelongsTo { return $this->belongsTo(Admin::class, 'created_by'); }

    public static function generateNo(): string
    {
        $last = self::withTrashed()->max('id') ?? 0;
        return 'BILL-' . date('Y') . '-' . str_pad($last + 1, 5, '0', STR_PAD_LEFT);
    }
}
