<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class PurchaseOrder extends Model
{
    use SoftDeletes, \App\Traits\BelongsToCompany;

    protected $fillable = [
        'po_number', 'vendor_id', 'date', 'expected_date', 'notes',
        'subtotal', 'discount', 'tax', 'grand_total', 'status', 'created_by',
    ];

    protected $casts = ['date' => 'date', 'expected_date' => 'date'];

    public function vendor(): BelongsTo { return $this->belongsTo(Vendor::class); }
    public function items(): HasMany { return $this->hasMany(PurchaseOrderItem::class); }
    public function bills(): HasMany { return $this->hasMany(PurchaseBill::class); }
    public function creator(): BelongsTo { return $this->belongsTo(Admin::class, 'created_by'); }

    public static function generateNo(): string
    {
        $last = self::withTrashed()->max('id') ?? 0;
        return 'PO-' . date('Y') . '-' . str_pad($last + 1, 5, '0', STR_PAD_LEFT);
    }
}
