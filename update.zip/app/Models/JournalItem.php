<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class JournalItem extends Model
{
    public $timestamps = false;
    protected $table = 'journal_items';
    protected $fillable = ['journal_entry_id', 'account_id', 'debit', 'credit', 'description'];

    public function entry() { return $this->belongsTo(JournalEntry::class, 'journal_entry_id'); }
    public function account() { return $this->belongsTo(Account::class); }
}
