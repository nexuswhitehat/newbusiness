<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Account extends Model
{
    use \App\Traits\BelongsToCompany;

    protected $fillable = [
        'account_code', 'account_name', 'account_type', 'parent_id',
        'opening_balance', 'is_system', 'status',
    ];

    public function parent(): BelongsTo { return $this->belongsTo(Account::class, 'parent_id'); }
    public function children(): HasMany { return $this->hasMany(Account::class, 'parent_id'); }
    public function journalItems(): HasMany { return $this->hasMany(JournalItem::class); }
}
