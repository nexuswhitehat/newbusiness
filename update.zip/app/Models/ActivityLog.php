<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ActivityLog extends Model
{
    public $timestamps = false;
    protected $table = 'activity_logs';
    protected $fillable = [
        'admin_id', 'module', 'action', 'description',
        'model_type', 'model_id', 'old_values', 'new_values',
        'ip_address', 'browser',
    ];

    protected $casts = [
        'old_values'  => 'array',
        'new_values'  => 'array',
        'created_at'  => 'datetime',
    ];

    public function admin() { return $this->belongsTo(Admin::class); }

    public static function log(string $module, string $action, string $description = '', array $extra = []): void
    {
        $admin = auth('admin')->user();
        self::create(array_merge([
            'admin_id'    => $admin?->id,
            'module'      => $module,
            'action'      => $action,
            'description' => $description,
            'ip_address'  => request()->ip(),
            'browser'     => substr(request()->userAgent() ?? '', 0, 200),
        ], $extra));
    }
}
