<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Notification extends Model
{
    protected $fillable = ['admin_id', 'title', 'message', 'type', 'link', 'read_at'];
    protected $casts = ['read_at' => 'datetime'];

    public function admin() { return $this->belongsTo(Admin::class); }
    public function isRead(): bool { return !is_null($this->read_at); }
}
