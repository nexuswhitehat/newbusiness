<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PurchaseOrderItem extends Model
{
    public $timestamps = false;
    protected $table = 'purchase_order_items';
    protected $fillable = ['purchase_order_id', 'product_id', 'product_name', 'qty', 'price', 'tax', 'total'];
    public function product() { return $this->belongsTo(Product::class); }
}
