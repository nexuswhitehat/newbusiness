<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VendorPayment extends Model
{
    use \App\Traits\BelongsToCompany;

    protected $fillable = [
        'payment_no', 'purchase_bill_id', 'vendor_id', 'payment_date',
        'payment_method', 'reference', 'amount', 'remarks', 'paid_by',
    ];
    protected $casts = ['payment_date' => 'date', 'amount' => 'decimal:2'];

    public function bill() { return $this->belongsTo(PurchaseBill::class, 'purchase_bill_id'); }
    public function vendor() { return $this->belongsTo(Vendor::class); }
    public function payer() { return $this->belongsTo(Admin::class, 'paid_by'); }

    public static function generateNo(): string
    {
        $last = self::max('id') ?? 0;
        return 'VPAY-' . date('Y') . '-' . str_pad($last + 1, 5, '0', STR_PAD_LEFT);
    }
}
