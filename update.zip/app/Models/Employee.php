<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Employee extends Model
{
    use SoftDeletes, \App\Traits\BelongsToCompany;

    protected $fillable = [
        'employee_code', 'name', 'phone', 'email', 'designation', 'department',
        'salary', 'joining_date', 'photo', 'address', 'emergency_contact', 'status',
    ];

    protected $casts = ['joining_date' => 'date', 'salary' => 'decimal:2'];

    public function attendance(): HasMany { return $this->hasMany(Attendance::class); }
    public function salaries(): HasMany { return $this->hasMany(Salary::class); }

    public function getPhotoUrlAttribute(): string
    {
        if ($this->photo) return asset('storage/' . $this->photo);
        return 'https://ui-avatars.com/api/?name=' . urlencode($this->name) . '&background=6366f1&color=fff';
    }

    public static function generateCode(): string
    {
        $last = self::withTrashed()->max('id') ?? 0;
        return 'EMP-' . str_pad($last + 1, 5, '0', STR_PAD_LEFT);
    }
}
