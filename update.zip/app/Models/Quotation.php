<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Quotation extends Model
{
    use SoftDeletes, \App\Traits\BelongsToCompany;

    protected $fillable = [
        'quotation_no', 'customer_id', 'date', 'valid_until', 'notes',
        'subtotal', 'discount', 'tax', 'grand_total', 'status', 'created_by',
    ];

    protected $casts = [
        'date'        => 'date',
        'valid_until' => 'date',
        'subtotal'    => 'decimal:2',
        'discount'    => 'decimal:2',
        'tax'         => 'decimal:2',
        'grand_total' => 'decimal:2',
    ];

    public function customer(): BelongsTo { return $this->belongsTo(Customer::class); }
    public function items(): HasMany { return $this->hasMany(QuotationItem::class); }
    public function creator(): BelongsTo { return $this->belongsTo(Admin::class, 'created_by'); }

    public static function generateNo(): string
    {
        $last = self::withTrashed()->max('id') ?? 0;
        return 'QUO-' . date('Y') . '-' . str_pad($last + 1, 5, '0', STR_PAD_LEFT);
    }
}
