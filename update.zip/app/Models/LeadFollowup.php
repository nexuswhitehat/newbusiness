<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class LeadFollowup extends Model
{
    protected $table = 'lead_followups';
    protected $fillable = ['lead_id', 'followup_date', 'remarks', 'next_followup', 'status', 'created_by'];
    protected $casts = ['followup_date' => 'date', 'next_followup' => 'date'];

    public function lead(): BelongsTo
    {
        return $this->belongsTo(Lead::class);
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(Admin::class, 'created_by');
    }
}
