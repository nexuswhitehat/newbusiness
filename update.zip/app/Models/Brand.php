<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Brand extends Model
{
    use \App\Traits\BelongsToCompany;

    protected $fillable = ['name', 'logo', 'status'];
    public function products() { return $this->hasMany(Product::class); }
}
