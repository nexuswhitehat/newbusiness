<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Attendance extends Model
{
    protected $table = 'attendance';
    protected $fillable = ['employee_id', 'date', 'check_in', 'check_out', 'status', 'remarks'];
    protected $casts = ['date' => 'date'];

    public function employee() { return $this->belongsTo(Employee::class); }
}
