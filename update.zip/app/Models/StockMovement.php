<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class StockMovement extends Model
{
    public $timestamps = false;
    protected $table = 'stock_movements';
    protected $fillable = [
        'warehouse_id', 'product_id', 'type', 'reference',
        'quantity', 'balance', 'unit_cost', 'remarks', 'created_by',
    ];
    protected $casts = ['created_at' => 'datetime'];

    public function warehouse(): BelongsTo { return $this->belongsTo(Warehouse::class); }
    public function product(): BelongsTo { return $this->belongsTo(Product::class); }
    public function creator(): BelongsTo { return $this->belongsTo(Admin::class, 'created_by'); }
}
