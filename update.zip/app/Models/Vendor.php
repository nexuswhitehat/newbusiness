<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Vendor extends Model
{
    use SoftDeletes, \App\Traits\BelongsToCompany;

    protected $fillable = [
        'vendor_code', 'company_name', 'contact_name', 'phone', 'email',
        'vat_number', 'address', 'opening_balance', 'status', 'remarks',
    ];

    protected $casts = ['opening_balance' => 'decimal:2'];

    public function purchaseOrders(): HasMany
    {
        return $this->hasMany(PurchaseOrder::class);
    }

    public function bills(): HasMany
    {
        return $this->hasMany(PurchaseBill::class);
    }

    public function ledger(): HasMany
    {
        return $this->hasMany(VendorLedger::class)->orderBy('id');
    }

    public function getCurrentBalanceAttribute(): float
    {
        $last = $this->ledger()->latest('id')->first();
        return $last ? (float)$last->balance : 0;
    }

    public static function generateCode(): string
    {
        $last = self::withTrashed()->max('id') ?? 0;
        return 'VEND-' . str_pad($last + 1, 5, '0', STR_PAD_LEFT);
    }
}
