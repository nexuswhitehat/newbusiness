<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Lead extends Model
{
    use SoftDeletes, \App\Traits\BelongsToCompany;

    protected $fillable = [
        'lead_no', 'company', 'name', 'phone', 'email', 'address',
        'source', 'status', 'priority', 'assigned_to', 'remarks', 'created_by',
    ];

    public function followups(): HasMany
    {
        return $this->hasMany(LeadFollowup::class)->orderByDesc('created_at');
    }

    public function assignedTo(): BelongsTo
    {
        return $this->belongsTo(Admin::class, 'assigned_to');
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(Admin::class, 'created_by');
    }

    public function getStatusColorAttribute(): string
    {
        return match($this->status) {
            'new'         => 'blue',
            'contacted'   => 'yellow',
            'qualified'   => 'indigo',
            'proposal'    => 'purple',
            'negotiation' => 'orange',
            'won'         => 'green',
            'lost'        => 'red',
            default       => 'gray',
        };
    }

    public static function generateNo(): string
    {
        $last = self::withTrashed()->max('id') ?? 0;
        return 'LEAD-' . str_pad($last + 1, 5, '0', STR_PAD_LEFT);
    }
}
