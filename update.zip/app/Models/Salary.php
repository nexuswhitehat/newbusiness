<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Salary extends Model
{
    protected $fillable = [
        'employee_id', 'month', 'year', 'basic_salary', 'allowances',
        'deductions', 'net_salary', 'payment_date', 'payment_method', 'status', 'remarks', 'created_by',
    ];
    protected $casts = ['payment_date' => 'date'];

    public function employee() { return $this->belongsTo(Employee::class); }
    public function creator() { return $this->belongsTo(Admin::class, 'created_by'); }
}
