<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use App\Traits\BelongsToCompany;

class Customer extends Model
{
    use SoftDeletes, BelongsToCompany;

    protected $fillable = [
        'customer_code', 'company_name', 'customer_name', 'phone', 'email',
        'vat_number', 'billing_address', 'shipping_address', 'opening_balance',
        'credit_limit', 'status', 'remarks', 'created_by',
    ];

    protected $casts = [
        'opening_balance' => 'decimal:2',
        'credit_limit' => 'decimal:2',
    ];

    public function contacts(): HasMany
    {
        return $this->hasMany(CustomerContact::class);
    }

    public function invoices(): HasMany
    {
        return $this->hasMany(Invoice::class);
    }

    public function payments(): HasMany
    {
        return $this->hasMany(Payment::class);
    }

    public function ledger(): HasMany
    {
        return $this->hasMany(CustomerLedger::class)->orderBy('id');
    }

    public function getCurrentBalanceAttribute(): float
    {
        $last = $this->ledger()->latest('id')->first();
        return $last ? (float)$last->balance : 0;
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(Admin::class, 'created_by');
    }

    public static function generateCode(): string
    {
        $last = self::withTrashed()->max('id') ?? 0;
        return 'CUST-' . str_pad($last + 1, 5, '0', STR_PAD_LEFT);
    }
}
