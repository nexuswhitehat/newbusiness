<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Expense extends Model
{
    use \App\Traits\BelongsToCompany;

    protected $fillable = [
        'expense_no', 'category_id', 'amount', 'date', 'payment_method',
        'reference', 'vendor_name', 'remarks', 'attachment', 'created_by',
    ];
    protected $casts = ['date' => 'date', 'amount' => 'decimal:2'];

    public function category() { return $this->belongsTo(ExpenseCategory::class); }
    public function creator() { return $this->belongsTo(Admin::class, 'created_by'); }

    public static function generateNo(): string
    {
        $last = self::max('id') ?? 0;
        return 'EXP-' . date('Y') . '-' . str_pad($last + 1, 5, '0', STR_PAD_LEFT);
    }
}
