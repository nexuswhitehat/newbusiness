<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Task extends Model
{
    protected $fillable = [
        'project_id', 'assigned_to', 'title', 'description',
        'priority', 'status', 'deadline', 'estimated_hours',
    ];

    protected $casts = ['deadline' => 'date'];

    public function project(): BelongsTo { return $this->belongsTo(Project::class); }
    public function assignee(): BelongsTo { return $this->belongsTo(Admin::class, 'assigned_to'); }
}
