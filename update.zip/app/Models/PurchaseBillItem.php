<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PurchaseBillItem extends Model
{
    public $timestamps = false;
    protected $table = 'purchase_bill_items';
    protected $fillable = ['purchase_bill_id', 'product_id', 'warehouse_id', 'product_name', 'qty', 'price', 'tax', 'total'];
    public function product() { return $this->belongsTo(Product::class); }
    public function warehouse() { return $this->belongsTo(Warehouse::class); }
}
