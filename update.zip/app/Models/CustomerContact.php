<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CustomerContact extends Model
{
    protected $table = 'customer_contacts';
    protected $fillable = ['customer_id', 'name', 'phone', 'email', 'designation', 'is_primary'];

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }
}
