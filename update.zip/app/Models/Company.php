<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Support\Str;

class Company extends Model
{
    protected $fillable = [
        'name', 'slug', 'owner', 'email', 'phone', 'website', 'vat_number',
        'registration_number', 'address', 'country', 'currency',
        'currency_symbol', 'timezone', 'logo', 'fiscal_year_start',
    ];

    public function getRouteKeyName(): string
    {
        return 'slug';
    }

    public function admins(): BelongsToMany
    {
        return $this->belongsToMany(Admin::class, 'admin_company')->withPivot('is_default')->withTimestamps();
    }

    public static function current(): ?self
    {
        if (app()->bound('current_company')) {
            return app('current_company');
        }

        $id = session('current_company_id');
        if ($id) {
            $company = self::find($id);
            if ($company) {
                app()->instance('current_company', $company);
                return $company;
            }
        }
        
        return null;
    }

    public function getLogoUrlAttribute(): string
    {
        if ($this->logo) {
            return asset('storage/' . $this->logo);
        }
        return '';
    }

    protected static function boot()
    {
        parent::boot();
        static::creating(function ($company) {
            if (empty($company->slug)) {
                $company->slug = Str::slug($company->name);
                $i = 1;
                while (self::where('slug', $company->slug)->exists()) {
                    $company->slug = Str::slug($company->name) . '-' . $i++;
                }
            }
        });
    }
}
