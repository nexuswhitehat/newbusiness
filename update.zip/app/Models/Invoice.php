<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Invoice extends Model
{
    use SoftDeletes, \App\Traits\BelongsToCompany;

    protected $fillable = [
        'invoice_no', 'customer_id', 'quotation_id', 'invoice_date', 'due_date',
        'reference', 'payment_terms', 'notes', 'terms', 'status',
        'subtotal', 'discount_value', 'discount_amount',
        'tax_rate', 'tax_amount', 'grand_total',
        'paid_amount', 'due_amount',
        'currency', 'currency_symbol', 'created_by',
    ];

    protected $casts = [
        'invoice_date'    => 'date',
        'due_date'        => 'date',
        'subtotal'        => 'decimal:2',
        'discount_value'  => 'decimal:2',
        'discount_amount' => 'decimal:2',
        'tax_rate'        => 'decimal:2',
        'tax_amount'      => 'decimal:2',
        'grand_total'     => 'decimal:2',
        'paid_amount'     => 'decimal:2',
        'due_amount'      => 'decimal:2',
    ];

    public function customer(): BelongsTo   { return $this->belongsTo(Customer::class); }
    public function quotation(): BelongsTo  { return $this->belongsTo(Quotation::class); }
    public function items(): HasMany        { return $this->hasMany(InvoiceItem::class); }
    public function payments(): HasMany     { return $this->hasMany(Payment::class); }
    public function createdBy(): BelongsTo  { return $this->belongsTo(Admin::class, 'created_by'); }

    // Backward compat alias
    public function creator(): BelongsTo    { return $this->createdBy(); }

    public function getStatusColorAttribute(): string
    {
        return match($this->status) {
            'draft'     => 'gray',
            'sent'      => 'blue',
            'partial'   => 'orange',
            'paid'      => 'green',
            'overdue'   => 'red',
            'cancelled' => 'gray',
            default     => 'gray',
        };
    }

    public static function generateNo(string $prefix = 'INV'): string
    {
        $last = self::withTrashed()->max('id') ?? 0;
        return $prefix . '-' . date('Y') . '-' . str_pad($last + 1, 5, '0', STR_PAD_LEFT);
    }
}
