<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CustomerLedger extends Model
{
    public $timestamps = false;
    protected $table = 'customer_ledgers';
    protected $fillable = [
        'customer_id', 'date', 'reference', 'type',
        'debit', 'credit', 'balance', 'remarks', 'created_by',
    ];

    protected $casts = [
        'date'       => 'date',
        'debit'      => 'decimal:2',
        'credit'     => 'decimal:2',
        'balance'    => 'decimal:2',
        'created_at' => 'datetime',
    ];

    public function customer(): BelongsTo { return $this->belongsTo(Customer::class); }
    public function creator(): BelongsTo { return $this->belongsTo(Admin::class, 'created_by'); }
}
