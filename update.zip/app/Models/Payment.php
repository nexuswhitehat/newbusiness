<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Payment extends Model
{
    use \App\Traits\BelongsToCompany;

    protected $fillable = [
        'payment_no', 'invoice_id', 'customer_id', 'payment_date',
        'payment_method', 'reference', 'amount', 'remarks', 'received_by',
    ];

    protected $casts = [
        'payment_date' => 'date',
        'amount'       => 'decimal:2',
    ];

    public function invoice(): BelongsTo { return $this->belongsTo(Invoice::class); }
    public function customer(): BelongsTo { return $this->belongsTo(Customer::class); }
    public function receiver(): BelongsTo { return $this->belongsTo(Admin::class, 'received_by'); }

    public static function generateNo(): string
    {
        $last = self::max('id') ?? 0;
        return 'PAY-' . date('Y') . '-' . str_pad($last + 1, 5, '0', STR_PAD_LEFT);
    }
}
