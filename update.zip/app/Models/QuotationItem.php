<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class QuotationItem extends Model
{
    public $timestamps = false;
    protected $table = 'quotation_items';
    protected $fillable = [
        'quotation_id', 'product_id', 'product_name', 'description',
        'qty', 'price', 'discount', 'tax', 'total',
    ];

    public function quotation(): BelongsTo { return $this->belongsTo(Quotation::class); }
    public function product(): BelongsTo { return $this->belongsTo(Product::class); }
}
