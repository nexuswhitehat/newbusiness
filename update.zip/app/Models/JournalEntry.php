<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class JournalEntry extends Model
{
    use \App\Traits\BelongsToCompany;

    protected $fillable = ['voucher_no', 'date', 'reference', 'remarks', 'status', 'created_by'];
    protected $casts = ['date' => 'date'];

    public function items(): HasMany { return $this->hasMany(JournalItem::class); }
    public function creator(): BelongsTo { return $this->belongsTo(Admin::class, 'created_by'); }

    public static function generateNo(): string
    {
        $last = self::max('id') ?? 0;
        return 'JV-' . date('Y') . '-' . str_pad($last + 1, 5, '0', STR_PAD_LEFT);
    }
}
