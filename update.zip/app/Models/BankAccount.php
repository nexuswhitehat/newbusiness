<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BankAccount extends Model
{
    use \App\Traits\BelongsToCompany;

    protected $fillable = [
        'account_name', 'bank_name', 'account_number', 'branch',
        'opening_balance', 'current_balance', 'status',
    ];
}
