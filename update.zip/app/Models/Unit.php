<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Unit extends Model
{
    use \App\Traits\BelongsToCompany;

    protected $fillable = ['name', 'short_name'];
    public function products() { return $this->hasMany(Product::class); }
}
