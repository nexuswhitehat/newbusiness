<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Project extends Model
{
    use SoftDeletes, \App\Traits\BelongsToCompany;

    protected $fillable = [
        'project_code', 'customer_id', 'project_name', 'description',
        'start_date', 'end_date', 'budget', 'progress', 'status', 'priority', 'created_by',
    ];

    protected $casts = ['start_date' => 'date', 'end_date' => 'date', 'budget' => 'decimal:2'];

    public function customer(): BelongsTo { return $this->belongsTo(Customer::class); }
    public function tasks(): HasMany { return $this->hasMany(Task::class); }
    public function creator(): BelongsTo { return $this->belongsTo(Admin::class, 'created_by'); }

    public static function generateCode(): string
    {
        $last = self::withTrashed()->max('id') ?? 0;
        return 'PROJ-' . str_pad($last + 1, 5, '0', STR_PAD_LEFT);
    }
}
