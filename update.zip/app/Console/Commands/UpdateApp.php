<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Filesystem\Filesystem;
use App\Services\Updater;

class UpdateApp extends Command
{
    protected $signature = 'update:app {json_url} {--force}';
    protected $description = 'Check and apply application updates from a remote JSON manifest.';

    protected Updater $updater;
    protected Filesystem $files;

    public function __construct(Updater $updater, Filesystem $files)
    {
        parent::__construct();
        $this->updater = $updater;
        $this->files = $files;
    }

    public function handle()
    {
        $jsonUrl = $this->argument('json_url');
        $force = $this->option('force');

        $this->info('Fetching update metadata...');
        $meta = $this->updater->fetchMetadata($jsonUrl);
        if (! $meta) {
            $this->error('Failed to fetch update metadata.');
            return 1;
        }

        $current = config('app.version') ?? '0.0.0';
        $latest = $meta['latest_version'] ?? null;
        if (! $latest) {
            $this->error('Invalid metadata: latest_version missing.');
            return 1;
        }

        $this->info("Current version: {$current}");
        $this->info("Latest version: {$latest}");

        if (! $force && version_compare($current, $latest, '>=')) {
            $this->info('Already up-to-date.');
            return 0;
        }

        $downloadUrl = $meta['download_url'] ?? null;
        $checksum = $meta['checksum'] ?? null;
        if (! $downloadUrl) {
            $this->error('download_url missing in metadata.');
            return 1;
        }

        $tmpDir = storage_path('app/updates');
        if (! $this->files->exists($tmpDir)) {
            $this->files->makeDirectory($tmpDir, 0755, true);
        }

        $zipPath = $tmpDir.'/update_'.uniqid().'.zip';
        $this->info('Downloading update...');
        if (! $this->updater->downloadZip($downloadUrl, $zipPath)) {
            $this->error('Download failed.');
            return 1;
        }

        if ($checksum) {
            $this->info('Verifying checksum...');
            if (! $this->updater->verifyChecksum($zipPath, $checksum)) {
                $this->error('Checksum verification failed.');
                return 1;
            }
        }

        $backupDir = config('updater.backup_dir', storage_path('backups'));
        if (! $this->files->exists($backupDir)) {
            $this->files->makeDirectory($backupDir, 0755, true);
        }

        $this->info('Creating backup (excluding vendor and node_modules)...');
        $backup = $this->updater->backupCurrent($backupDir);
        if (! $backup) {
            $this->error('Backup failed.');
            return 1;
        }
        $this->info('Backup created: '.$backup);

        $this->info('Applying update...');
        if (! $this->updater->applyUpdate($zipPath)) {
            $this->error('Applying update failed.');
            return 1;
        }

        $this->info('Running post-update commands (composer & npm)...');
        if (! $this->updater->runCommands()) {
            $this->error('Post-update commands failed.');
            return 1;
        }

        $this->info('Update applied successfully to version '.$latest);
        return 0;
    }
}
