<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use App\Models\Company;
use Symfony\Component\HttpFoundation\Response;

class SetCurrentCompany
{
    public function handle(Request $request, Closure $next): Response
    {
        $companySlug = $request->route('company');

        if ($companySlug) {
            $company = $companySlug instanceof Company
                ? $companySlug
                : Company::where('slug', $companySlug)->first();

            if (!$company) {
                abort(404, 'Company not found.');
            }

            $admin = auth('admin')->user();
            if ($admin && !$admin->isSuperAdmin() && !$admin->belongsToCompany($company)) {
                abort(403, 'You do not have access to this company.');
            }

            session(['current_company_id' => $company->id]);
            app()->instance('current_company', $company);
            view()->share('currentCompany', $company);
        }

        return $next($request);
    }
}
