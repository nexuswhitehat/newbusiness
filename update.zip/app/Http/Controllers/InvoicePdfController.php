<?php

namespace App\Http\Controllers;

use App\Models\Invoice;
use App\Models\Company;
use Barryvdh\DomPDF\Facade\Pdf;

class InvoicePdfController extends Controller
{
    public function download(Company $company, Invoice $invoice)
    {
        $invoice->load(['customer', 'items.product', 'payments']);
        $currentCompany = Company::current();

        $pdf = Pdf::loadView('pdf.invoice', compact('invoice', 'currentCompany'))
            ->setPaper('a4');

        return $pdf->download("Invoice-{$invoice->invoice_no}.pdf");
    }

    public function print(Company $company, Invoice $invoice)
    {
        $invoice->load(['customer', 'items.product', 'payments']);
        $currentCompany = Company::current();

        return view('pdf.invoice', compact('invoice', 'currentCompany'));
    }
}
