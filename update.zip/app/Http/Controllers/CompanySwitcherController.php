<?php

namespace App\Http\Controllers;

use App\Models\Company;
use Illuminate\Http\Request;

class CompanySwitcherController extends Controller
{
    public function index()
    {
        $admin = auth('admin')->user();
        $companies = $admin->isSuperAdmin()
            ? Company::all()
            : $admin->companies;

        // If super admin and no companies exist at all, redirect to create
        if ($companies->isEmpty() && $admin->isSuperAdmin()) {
            return redirect()->route('company.create');
        }

        // If no companies for this user (non-super-admin)
        if ($companies->isEmpty()) {
            auth('admin')->logout();
            return redirect()->route('admin.login')
                ->with('error', 'No companies assigned to your account. Please contact the administrator.');
        }

        if ($companies->count() === 1) {
            return redirect()->route('dashboard', $companies->first()->slug);
        }

        return view('company-select', compact('companies'));
    }

    public function switch(Company $company)
    {
        $admin = auth('admin')->user();

        if (!$admin->isSuperAdmin() && !$admin->belongsToCompany($company)) {
            abort(403);
        }

        return redirect()->route('dashboard', $company->slug);
    }
}
