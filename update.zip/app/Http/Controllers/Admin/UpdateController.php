<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Services\Updater;

// This is update controller

class UpdateController extends Controller
{
    protected Updater $updater;

    public function __construct(Updater $updater)
    {
        $this->updater = $updater;
    }

    public function index(Request $request)
    {
        $jsonUrl = config('updater.json_url');
        $current = config('app.version') ?? null;
        $meta = null;
        $available = false;
        $error = null;

        if (! $jsonUrl) {
            $error = 'Update JSON URL not configured. Set UPDATER_JSON_URL in .env or config/updater.php';
        } else {
            try {
                $meta = $this->updater->fetchMetadata($jsonUrl);
                if ($meta && isset($meta['latest_version']) && $current) {
                    $available = version_compare($current, $meta['latest_version'], '<');
                }
            } catch (\Throwable $e) {
                Log::error('UpdateController: metadata fetch error', ['err' => $e->getMessage()]);
                $error = 'Failed to fetch update metadata.';
            }
        }

        return view('admin.update', compact('meta', 'available', 'current', 'error', 'jsonUrl'));
    }

    public function run(Request $request)
    {
        $jsonUrl = config('updater.json_url');
        if (! $jsonUrl) {
            return response()->json(['ok' => false, 'message' => 'Updater JSON URL not configured.'], 400);
        }

        // Run the artisan command in background and redirect output to a log file
        $logPath = storage_path('logs/update_'.time().'.log');
        $cmd = sprintf('nohup php artisan update:app "%s" > %s 2>&1 &', $jsonUrl, $logPath);
        try {
            $process = \Symfony\Component\Process\Process::fromShellCommandline($cmd, base_path());
            $process->run();
        } catch (\Throwable $e) {
            Log::error('UpdateController: failed to start update', ['err' => $e->getMessage()]);
            return response()->json(['ok' => false, 'message' => 'Failed to start update.'], 500);
        }

        return response()->json(['ok' => true, 'message' => 'Update started, logs: '.str_replace(base_path().DIRECTORY_SEPARATOR, '', $logPath)]);
    }
}
