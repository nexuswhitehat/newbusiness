<?php

namespace App\Services;

use Illuminate\Filesystem\Filesystem;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Symfony\Component\Process\Process;
use ZipArchive;

class Updater
{
    protected Filesystem $files;
    protected string $basePath;

    public function __construct(Filesystem $files)
    {
        $this->files = $files;
        $this->basePath = base_path();
    }

    /**
     * Fetch update metadata JSON from a URL.
     */
    public function fetchMetadata(string $jsonUrl): ?array
    {
        $resp = Http::get($jsonUrl);
        if (! $resp->successful()) {
            Log::error('Updater: failed fetching metadata', ['url' => $jsonUrl, 'status' => $resp->status()]);
            return null;
        }
        return $resp->json();
    }

    public function downloadZip(string $downloadUrl, string $targetPath): bool
    {
        try {
            $contents = Http::get($downloadUrl)->body();
            $this->files->put($targetPath, $contents);
            return true;
        } catch (\Throwable $e) {
            Log::error('Updater: download failed', ['err' => $e->getMessage()]);
            return false;
        }
    }

    public function verifyChecksum(string $path, string $checksum): bool
    {
        if (! $this->files->exists($path)) {
            return false;
        }
        $expected = preg_replace('/^sha256-/', '', $checksum);
        $hash = hash_file('sha256', $path);
        return hash_equals($expected, $hash);
    }

    public function backupCurrent(string $backupDir, array $excludes = ['vendor', 'node_modules']): ?string
    {
        $timestamp = now()->format('YmdHis');
        $zipPath = rtrim($backupDir, DIRECTORY_SEPARATOR)."/backup-{$timestamp}.zip";

        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::CREATE) !== true) {
            return null;
        }

        $iterator = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($this->basePath, \FilesystemIterator::SKIP_DOTS));
        foreach ($iterator as $file) {
            $rel = Str::replaceFirst($this->basePath.DIRECTORY_SEPARATOR, '', $file->getPathname());
            // skip backups directory and vendor/node_modules and runtime files
            foreach ($excludes as $ex) {
                if (Str::startsWith($rel, $ex.DIRECTORY_SEPARATOR) || $rel === $ex) {
                    continue 2;
                }
            }
            // skip storage/backups to avoid recursion
            if (Str::startsWith($rel, 'storage'.DIRECTORY_SEPARATOR.'backups')) {
                continue;
            }
            $zip->addFile($file->getPathname(), $rel);
        }

        $zip->close();
        return $zipPath;
    }

    public function applyUpdate(string $zipPath, array $excludes = ['vendor', 'node_modules']): bool
    {
        $tmpDir = storage_path('app/update_tmp_'.uniqid());
        $this->files->makeDirectory($tmpDir, 0755, true);

        $zip = new ZipArchive();
        if ($zip->open($zipPath) !== true) {
            return false;
        }
        $zip->extractTo($tmpDir);
        $zip->close();

        // Copy files from tmp to basePath, skipping excludes
        $iterator = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($tmpDir, \FilesystemIterator::SKIP_DOTS), \RecursiveIteratorIterator::SELF_FIRST);
        foreach ($iterator as $item) {
            $rel = Str::replaceFirst($tmpDir.DIRECTORY_SEPARATOR, '', $item->getPathname());
            foreach ($excludes as $ex) {
                if (Str::startsWith($rel, $ex.DIRECTORY_SEPARATOR) || $rel === $ex) {
                    continue 2;
                }
            }
            $target = $this->basePath.DIRECTORY_SEPARATOR.$rel;
            if ($item->isDir()) {
                if (! $this->files->exists($target)) {
                    $this->files->makeDirectory($target, 0755, true);
                }
            } else {
                $this->files->copy($item->getPathname(), $target);
            }
        }

        // cleanup tmp
        $this->files->deleteDirectory($tmpDir);
        return true;
    }

    public function runCommands(array $commands = ['composer install --no-interaction --prefer-dist', 'npm install', 'npm run build']): bool
    {
        foreach ($commands as $cmd) {
            $process = Process::fromShellCommandline($cmd, $this->basePath);
            $process->setTimeout(null);
            $process->run(function ($type, $buffer) {
                Log::info('Updater: command output', ['output' => trim($buffer)]);
            });
            if (! $process->isSuccessful()) {
                Log::error('Updater: command failed', ['cmd' => $cmd, 'exit' => $process->getExitCode(), 'error' => $process->getErrorOutput()]);
                return false;
            }
        }
        return true;
    }
}
