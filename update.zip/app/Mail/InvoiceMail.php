<?php

namespace App\Mail;

use App\Models\Invoice;
use App\Models\Company;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Attachment;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class InvoiceMail extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;

    public $invoice;
    public $company;

    public function __construct(Invoice $invoice, Company $company)
    {
        $this->invoice = $invoice;
        $this->company = $company;
    }

    public function envelope(): Envelope
    {
        return new Envelope(
            subject: "Invoice {$this->invoice->invoice_no} from {$this->company->name}",
        );
    }

    public function content(): Content
    {
        return new Content(
            view: 'emails.invoices.sent',
        );
    }

    public function attachments(): array
    {
        $pdf = Pdf::loadView('pdf.invoice', [
            'invoice' => $this->invoice,
            'currentCompany' => $this->company
        ])->setPaper('a4');

        return [
            Attachment::fromData(fn () => $pdf->output(), "Invoice-{$this->invoice->invoice_no}.pdf")
                    ->withMime('application/pdf'),
        ];
    }
}
