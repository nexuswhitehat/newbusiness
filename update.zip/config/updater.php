<?php

return [
    // Directory where backups (zip) will be stored
    'backup_dir' => env('UPDATER_BACKUP_DIR', storage_path('backups')),
    // Remote JSON manifest URL for updates
    'json_url' => env('UPDATER_JSON_URL', null),
];
